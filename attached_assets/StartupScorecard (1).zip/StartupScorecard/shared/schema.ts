import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  avatar: text("avatar"),
  isVerified: boolean("is_verified").default(false),
  isEmailVerified: boolean("is_email_verified").default(false),
  emailVerificationCode: text("email_verification_code"),
  emailVerificationExpires: timestamp("email_verification_expires"),
  isAdmin: boolean("is_admin").default(false),
  isPremium: boolean("is_premium").default(false),
  isModerator: boolean("is_moderator").default(false),
  isBanned: boolean("is_banned").default(false),
  banReason: text("ban_reason"),
  bannedAt: timestamp("banned_at"),
  bannedBy: integer("banned_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  avatar: true,
});

// Schema for email verification
export const emailVerificationSchema = z.object({
  email: z.string().email("Please enter a valid email."),
  code: z.string().min(6, "Verification code must be 6 digits.").max(6),
});

// Channel schema
export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  banner: text("banner"),
  userId: integer("user_id").notNull(),
  subscriberCount: integer("subscriber_count").default(0),
  isVerified: boolean("is_verified").default(false),
  isFeatured: boolean("is_featured").default(false),
  isDisabled: boolean("is_disabled").default(false),
  disableReason: text("disable_reason"),
  disabledAt: timestamp("disabled_at"),
  disabledBy: integer("disabled_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertChannelSchema = createInsertSchema(channels).pick({
  name: true,
  description: true,
  banner: true,
  userId: true,
});

// Video schema
export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  thumbnail: text("thumbnail"),
  videoPath: text("video_path").notNull(),
  duration: integer("duration").default(0),
  views: integer("views").default(0),
  likes: integer("likes").default(0),
  dislikes: integer("dislikes").default(0),
  channelId: integer("channel_id").notNull(),
  privacy: text("privacy").default("public"),
  isQuickie: boolean("is_quickie").default(false),
  isPremium: boolean("is_premium").default(false),
  tags: text("tags").array(),
  categories: text("categories").array(),
  // Moderation fields
  moderationStatus: text("moderation_status").default("pending"), // pending, approved, rejected
  moderationReason: text("moderation_reason"),
  moderatedAt: timestamp("moderated_at"),
  moderatedBy: integer("moderated_by"),
  isDisabled: boolean("is_disabled").default(false),
  disableReason: text("disable_reason"),
  hasContentWarning: boolean("has_content_warning").default(false),
  contentWarningText: text("content_warning_text"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertVideoSchema = createInsertSchema(videos).pick({
  title: true,
  description: true,
  thumbnail: true,
  videoPath: true,
  duration: true,
  channelId: true,
  privacy: true,
  isQuickie: true,
  isPremium: true,
  tags: true,
  categories: true,
});

// Comment schema
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  userId: integer("user_id").notNull(),
  videoId: integer("video_id").notNull(),
  // Moderation fields
  isHidden: boolean("is_hidden").default(false),
  hideReason: text("hide_reason"),
  moderatedAt: timestamp("moderated_at"),
  moderatedBy: integer("moderated_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  content: true,
  userId: true,
  videoId: true,
});

// Like schema
export const likes = pgTable("likes", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  videoId: integer("video_id").notNull(),
  isLike: boolean("is_like").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLikeSchema = createInsertSchema(likes).pick({
  userId: true,
  videoId: true,
  isLike: true,
});

// Subscription schema
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  channelId: integer("channel_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).pick({
  userId: true,
  channelId: true,
});

// Content reports for moderation
export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  reporterId: integer("reporter_id").notNull().references(() => users.id),
  contentType: text("content_type").notNull(), // video, comment, channel, user
  contentId: integer("content_id").notNull(),
  reason: text("reason").notNull(),
  details: text("details"),
  status: text("status").default("pending"), // pending, reviewed, dismissed
  reviewedAt: timestamp("reviewed_at"),
  reviewedBy: integer("reviewed_by").references(() => users.id),
  actionTaken: text("action_taken"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReportSchema = createInsertSchema(reports).pick({
  reporterId: true,
  contentType: true,
  contentId: true,
  reason: true,
  details: true,
});

// Moderation logs
export const moderationLogs = pgTable("moderation_logs", {
  id: serial("id").primaryKey(),
  moderatorId: integer("moderator_id").notNull().references(() => users.id),
  contentType: text("content_type").notNull(), // video, comment, channel, user
  contentId: integer("content_id").notNull(),
  action: text("action").notNull(), // approve, reject, hide, unhide, ban, unban, feature, unfeature
  reason: text("reason"),
  previousStatus: text("previous_status"),
  newStatus: text("new_status"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertModerationLogSchema = createInsertSchema(moderationLogs).pick({
  moderatorId: true,
  contentType: true,
  contentId: true,
  action: true,
  reason: true,
  previousStatus: true,
  newStatus: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Channel = typeof channels.$inferSelect;
export type InsertChannel = z.infer<typeof insertChannelSchema>;

export type Video = typeof videos.$inferSelect;
export type InsertVideo = z.infer<typeof insertVideoSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type Like = typeof likes.$inferSelect;
export type InsertLike = z.infer<typeof insertLikeSchema>;

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;

export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;

export type ModerationLog = typeof moderationLogs.$inferSelect;
export type InsertModerationLog = z.infer<typeof insertModerationLogSchema>;

// Video categories
export const VideoCategory = {
  TEEN: "teen",
  MILF: "milf",
  STEPMOM: "stepmom",
  EBONY: "ebony",
  BLACK: "black",
  ASIAN: "asian",
  INDIAN: "indian",
  LATINA: "latina",
  BLONDE: "blonde",
  BRUNETTE: "brunette",
  REDHEAD: "redhead",
  AMATEUR: "amateur",
  PROFESSIONAL: "professional",
  SOLO: "solo",
  LESBIAN: "lesbian",
  THREESOME: "threesome",
  TOYS: "toys",
  COSPLAY: "cosplay",
  POV: "pov",
  OTHER: "other",
} as const;

// Moderation constants
export const ModerationStatus = {
  PENDING: "pending",
  APPROVED: "approved",
  REJECTED: "rejected",
} as const;

export const ContentType = {
  VIDEO: "video",
  COMMENT: "comment",
  CHANNEL: "channel",
  USER: "user",
} as const;

export const ReportStatus = {
  PENDING: "pending",
  REVIEWED: "reviewed", 
  DISMISSED: "dismissed",
} as const;

export const ModerationAction = {
  APPROVE: "approve",
  REJECT: "reject",
  HIDE: "hide", 
  UNHIDE: "unhide",
  DISABLE: "disable",
  ENABLE: "enable",
  BAN: "ban",
  UNBAN: "unban",
  FEATURE: "feature",
  UNFEATURE: "unfeature",
  VERIFY: "verify",
  UNVERIFY: "unverify",
} as const;
