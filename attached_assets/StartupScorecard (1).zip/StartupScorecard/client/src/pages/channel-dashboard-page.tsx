import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Video, Channel } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { VideoCard } from "@/components/ui/video-card";
import { AbstractBg3 } from "@/assets/svg/abstract-bg-3";
import { 
  VideoIcon, 
  Eye, 
  ThumbsUp, 
  MessageSquare, 
  Activity, 
  TrendingUp, 
  CalendarDays, 
  Users, 
  PlusCircle, 
  Settings,
  Upload,
  Edit,
  Image
} from "lucide-react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

// Mock data for charts
const viewsData = [
  { name: "Jan", views: 4000 },
  { name: "Feb", views: 3000 },
  { name: "Mar", views: 5000 },
  { name: "Apr", views: 8000 },
  { name: "May", views: 7000 },
  { name: "Jun", views: 9000 },
  { name: "Jul", views: 11000 },
];

const COLORS = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)', 'var(--chart-5)'];

export default function ChannelDashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [timeframe, setTimeframe] = useState("month");
  const [isEditingChannel, setIsEditingChannel] = useState(false);
  const [channelName, setChannelName] = useState("");
  const [channelDescription, setChannelDescription] = useState("");
  const [bannerFile, setBannerFile] = useState<File | null>(null);
  const [bannerPreview, setBannerPreview] = useState<string | null>(null);
  
  // Fetch user's channel
  const { data: channel, isLoading: channelLoading } = useQuery<Channel>({
    queryKey: [`/api/channels/user/${user?.id}`],
    queryFn: async () => {
      try {
        const res = await fetch(`/api/channels/user/${user?.id}`);
        if (!res.ok) {
          if (res.status === 404) {
            // Redirect to dashboard if no channel
            navigate('/dashboard');
            return null;
          }
          throw new Error('Failed to fetch channel');
        }
        return res.json();
      } catch (error) {
        console.error('Error fetching channel:', error);
        return null;
      }
    },
    enabled: !!user,
  });
  
  // Set initial values once channel is loaded
  useState(() => {
    if (channel) {
      setChannelName(channel.name);
      setChannelDescription(channel.description || "");
      setBannerPreview(channel.banner || null);
    }
  });
  
  // Fetch user's videos
  const { data: userVideos = [] } = useQuery<Video[]>({
    queryKey: [`/api/channels/${channel?.id}/videos`],
    queryFn: async () => {
      const res = await fetch(`/api/channels/${channel?.id}/videos`);
      if (!res.ok) {
        throw new Error('Failed to fetch videos');
      }
      return res.json();
    },
    enabled: !!channel?.id,
  });
  
  // Update channel mutation
  const updateChannelMutation = useMutation({
    mutationFn: async (updatedChannel: { name: string; description: string; banner?: File }) => {
      const formData = new FormData();
      formData.append("name", updatedChannel.name);
      formData.append("description", updatedChannel.description);
      
      if (updatedChannel.banner) {
        formData.append("banner", updatedChannel.banner);
      }
      
      const response = await fetch(`/api/channels/${channel?.id}`, {
        method: "PATCH",
        body: formData,
        credentials: "include"
      });
      
      if (!response.ok) {
        throw new Error("Failed to update channel");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [`/api/channels/user/${user?.id}`] });
      setIsEditingChannel(false);
      toast({
        title: "Success",
        description: "Channel updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update channel",
        variant: "destructive",
      });
    }
  });
  
  // Calculate total stats
  const totalViews = userVideos.reduce((sum, video) => sum + (video.views || 0), 0);
  const totalLikes = userVideos.reduce((sum, video) => sum + (video.likes || 0), 0);
  const quickies = userVideos.filter(video => video.isQuickie).length;
  const normalVideos = userVideos.length - quickies;
  
  // Video type distribution for pie chart
  const videoTypeData = [
    { name: "Normal Videos", value: normalVideos },
    { name: "Quickies", value: quickies }
  ];
  
  // Format numbers for display
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    } else {
      return num;
    }
  };
  
  // Handle banner file selection
  const handleBannerChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Check file type
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please select an image file",
          variant: "destructive",
        });
        return;
      }
      
      setBannerFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setBannerPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Handle channel update submission
  const handleUpdateChannel = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!channelName.trim()) {
      toast({
        title: "Channel name required",
        description: "Please enter a name for your channel",
        variant: "destructive",
      });
      return;
    }
    
    const updatedChannel = {
      name: channelName,
      description: channelDescription,
    };
    
    if (bannerFile) {
      updateChannelMutation.mutate({ ...updatedChannel, banner: bannerFile });
    } else {
      updateChannelMutation.mutate(updatedChannel);
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="relative mb-8">
        <div className="absolute -top-20 right-0 w-full h-60 overflow-hidden opacity-10 pointer-events-none">
          <AbstractBg3 />
        </div>
        
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold">Channel Dashboard</h1>
              <p className="text-gray-600 dark:text-gray-400">
                Manage your channel and track performance
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <Select value={timeframe} onValueChange={setTimeframe}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Last 7 days</SelectItem>
                  <SelectItem value="month">Last 30 days</SelectItem>
                  <SelectItem value="year">Last year</SelectItem>
                  <SelectItem value="all">All time</SelectItem>
                </SelectContent>
              </Select>
              
              <Link href="/upload">
                <Button className="bg-primary hover:bg-accent text-white">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Upload New Video
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Channel Info */}
          {channel && !isEditingChannel ? (
            <div className="mt-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                <Avatar className="w-24 h-24 border-4 border-primary">
                  <AvatarImage src={channel.banner} alt={channel.name} />
                  <AvatarFallback className="text-2xl">{channel.name[0]}</AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <h2 className="text-2xl font-bold">{channel.name}</h2>
                      <p className="text-gray-600 dark:text-gray-400">{channel.description || "No description provided"}</p>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <Link href={`/channel/${channel.id}`}>
                        <Button variant="outline">
                          <Eye className="mr-2 h-4 w-4" />
                          View Channel
                        </Button>
                      </Link>
                      <Button 
                        variant="outline"
                        onClick={() => setIsEditingChannel(true)}
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        Edit Channel
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-8 mt-4">
                    <div className="flex items-center">
                      <Users className="text-primary mr-2 h-5 w-5" />
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Subscribers</p>
                        <p className="font-bold">{formatNumber(channel.subscriberCount || 0)}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <VideoIcon className="text-primary mr-2 h-5 w-5" />
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Videos</p>
                        <p className="font-bold">{userVideos.length}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <CalendarDays className="text-primary mr-2 h-5 w-5" />
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Joined</p>
                        <p className="font-bold">
                          {new Date(channel.createdAt).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : isEditingChannel ? (
            <div className="mt-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
              <h2 className="text-2xl font-bold mb-6">Edit Channel</h2>
              <form onSubmit={handleUpdateChannel} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="channelName">Channel Name</Label>
                  <Input
                    id="channelName"
                    value={channelName}
                    onChange={(e) => setChannelName(e.target.value)}
                    placeholder="Enter channel name"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="channelDescription">Description</Label>
                  <Textarea
                    id="channelDescription"
                    value={channelDescription}
                    onChange={(e) => setChannelDescription(e.target.value)}
                    placeholder="Enter channel description"
                    rows={3}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="banner">Channel Banner</Label>
                  <div className="border rounded-lg p-4">
                    {bannerPreview ? (
                      <div className="relative">
                        <img 
                          src={bannerPreview} 
                          alt="Banner Preview" 
                          className="w-full h-48 object-cover rounded mb-4"
                        />
                      </div>
                    ) : (
                      <div className="h-48 flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded mb-4">
                        <Image className="h-12 w-12 text-gray-400" />
                      </div>
                    )}
                    <div className="flex justify-center">
                      <Label 
                        htmlFor="bannerUpload" 
                        className="cursor-pointer py-2 px-4 bg-gray-200 dark:bg-gray-700 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors flex items-center gap-2"
                      >
                        <Upload className="h-4 w-4" />
                        Choose Banner Image
                      </Label>
                      <input
                        type="file"
                        id="bannerUpload"
                        onChange={handleBannerChange}
                        accept="image/*"
                        className="hidden"
                      />
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end gap-2">
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => setIsEditingChannel(false)}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    className="bg-primary hover:bg-accent text-white"
                    disabled={updateChannelMutation.isPending}
                  >
                    {updateChannelMutation.isPending ? "Saving..." : "Save Changes"}
                  </Button>
                </div>
              </form>
            </div>
          ) : (
            <div className="mt-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm text-center">
              <h2 className="text-xl font-bold mb-4">Channel Dashboard</h2>
              <p className="mb-6">Loading channel information...</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Stats and Analytics */}
      {channel && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Views</CardTitle>
                <Eye className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(totalViews)}</div>
                <p className="text-xs text-muted-foreground">
                  +{formatNumber(Math.floor(totalViews * 0.12))} from previous {timeframe}
                </p>
                <div className="h-[80px] mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={viewsData}
                      margin={{ top: 5, right: 0, left: 0, bottom: 5 }}
                    >
                      <defs>
                        <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <Area 
                        type="monotone" 
                        dataKey="views" 
                        stroke="var(--primary)" 
                        fillOpacity={1} 
                        fill="url(#colorViews)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Total Likes</CardTitle>
                <ThumbsUp className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{formatNumber(totalLikes)}</div>
                <p className="text-xs text-muted-foreground">
                  +{formatNumber(Math.floor(totalLikes * 0.08))} from previous {timeframe}
                </p>
                <div className="h-[80px] mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={viewsData.map(item => ({ name: item.name, likes: Math.floor(item.views * 0.15) }))}
                      margin={{ top: 5, right: 0, left: 0, bottom: 5 }}
                    >
                      <Line 
                        type="monotone" 
                        dataKey="likes" 
                        stroke="var(--primary)" 
                        strokeWidth={2} 
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">Video Types</CardTitle>
                <VideoIcon className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{userVideos.length} Videos</div>
                <p className="text-xs text-muted-foreground">
                  {normalVideos} normal videos, {quickies} quickies
                </p>
                <div className="h-[80px] mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={videoTypeData}
                        cx="50%"
                        cy="50%"
                        innerRadius={25}
                        outerRadius={40}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                      >
                        {videoTypeData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="videos" className="mt-8">
            <TabsList>
              <TabsTrigger value="videos">Your Videos</TabsTrigger>
              <TabsTrigger value="quickies">Your Quickies</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>
            
            <TabsContent value="videos">
              <div className="grid grid-cols-1 gap-4">
                {normalVideos > 0 ? (
                  <>
                    <div className="flex justify-between items-center my-4">
                      <h3 className="text-xl font-bold">Normal Videos ({normalVideos})</h3>
                      <Select defaultValue="newest">
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Sort by" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="newest">Newest first</SelectItem>
                          <SelectItem value="oldest">Oldest first</SelectItem>
                          <SelectItem value="views">Most views</SelectItem>
                          <SelectItem value="likes">Most likes</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                      {userVideos
                        .filter(video => !video.isQuickie)
                        .map(video => (
                          <VideoCard 
                            key={video.id} 
                            video={video} 
                            channel={channel}
                          />
                        ))}
                    </div>
                  </>
                ) : (
                  <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <VideoIcon className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-xl font-bold mb-2">No standard videos yet</h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-6">Upload your first video to get started</p>
                    <Link href="/upload">
                      <Button className="bg-primary hover:bg-accent text-white">
                        Upload Video
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="quickies">
              <div className="grid grid-cols-1 gap-4">
                {quickies > 0 ? (
                  <>
                    <div className="flex justify-between items-center my-4">
                      <h3 className="text-xl font-bold">Quickies ({quickies})</h3>
                      <Select defaultValue="newest">
                        <SelectTrigger className="w-[180px]">
                          <SelectValue placeholder="Sort by" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="newest">Newest first</SelectItem>
                          <SelectItem value="oldest">Oldest first</SelectItem>
                          <SelectItem value="views">Most views</SelectItem>
                          <SelectItem value="likes">Most likes</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                      {userVideos
                        .filter(video => video.isQuickie)
                        .map(video => (
                          <VideoCard 
                            key={video.id} 
                            video={video} 
                            channel={channel}
                            isQuickie={true}
                          />
                        ))}
                    </div>
                  </>
                ) : (
                  <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
                    <VideoIcon className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-xl font-bold mb-2">No quickies yet</h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-6">Upload your first quickie video to get started</p>
                    <Link href="/upload?tab=quickie">
                      <Button className="bg-primary hover:bg-accent text-white">
                        Upload Quickie
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="analytics">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Views Over Time</CardTitle>
                    <CardDescription>
                      Track your video performance over the {timeframe}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={viewsData}
                          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <defs>
                            <linearGradient id="colorViewsChart" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.8} />
                              <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <Area 
                            type="monotone" 
                            dataKey="views" 
                            stroke="var(--primary)" 
                            fillOpacity={1} 
                            fill="url(#colorViewsChart)" 
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Audience Growth</CardTitle>
                    <CardDescription>
                      Subscriber count over the {timeframe}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={viewsData.map(item => ({ name: item.name, subscribers: Math.floor(item.views * 0.025) }))}
                          margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Line 
                            type="monotone" 
                            dataKey="subscribers" 
                            stroke="var(--primary)" 
                            strokeWidth={2}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}