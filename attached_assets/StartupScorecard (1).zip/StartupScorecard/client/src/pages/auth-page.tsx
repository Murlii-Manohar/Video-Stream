import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSchema } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AbstractBg1 } from "@/assets/svg/abstract-bg-1";
import { EmailVerificationForm } from "@/components/ui/email-verification-form";
import { useToast } from "@/hooks/use-toast";

// Extend insertUserSchema for login/register validation
const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const registerSchema = insertUserSchema.extend({
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
  email: z.string().email("Please enter a valid email"),
  terms: z.boolean().refine(val => val === true, {
    message: "You must accept the terms and conditions",
  }),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [, navigate] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const [activeTab, setActiveTab] = useState<string>("login");
  const [showEmailVerification, setShowEmailVerification] = useState(false);
  const [verifiedEmail, setVerifiedEmail] = useState<string | null>(null);
  const { toast } = useToast();
  
  // If user is already logged in, redirect to home
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);
  
  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  // Register form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: verifiedEmail || "",
      password: "",
      confirmPassword: "",
      terms: false,
      avatar: `https://ui-avatars.com/api/?name=User&background=random`,
    },
  });
  
  // Update email field when verifiedEmail changes
  useEffect(() => {
    if (verifiedEmail) {
      registerForm.setValue("email", verifiedEmail);
    }
  }, [verifiedEmail, registerForm]);
  
  // Handle login form submission
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };
  
  // Handle register form submission
  const onRegisterSubmit = (data: RegisterFormValues) => {
    // If email is not verified, show verification dialog
    if (!verifiedEmail) {
      // Send the form data directly to email verification
      setShowEmailVerification(true);
      return;
    }
    
    // If email is already verified, proceed with registration
    const { confirmPassword, terms, ...registerData } = data;
    registerMutation.mutate(registerData);
  };
  
  // Handle email verification completion
  const handleVerificationComplete = (email: string) => {
    setVerifiedEmail(email);
    setShowEmailVerification(false);
    toast({
      title: "Email Verified",
      description: "Your email has been verified. You can now complete your registration.",
      duration: 5000,
    });
  };
  
  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left Content - Auth Forms */}
      <div className="w-full lg:w-1/2 p-8 flex flex-col justify-center">
        <div className="mb-8 text-center lg:text-left">
          <h1 className="text-3xl font-bold font-montserrat mb-2 text-primary">
            XPlay<span className="text-secondary dark:text-white">HD</span>
          </h1>
          <p className="text-gray-600 dark:text-gray-300">The premier adult video streaming platform</p>
        </div>
        
        {showEmailVerification && (
          <EmailVerificationForm 
            onVerificationComplete={handleVerificationComplete} 
            initialEmail={registerForm.getValues().email}
          />
        )}
        {!showEmailVerification && (
          <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab} className="w-full max-w-md mx-auto lg:mx-0">
            <TabsList className="grid grid-cols-2 w-full mb-6">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
          
            {/* Login Form */}
            <TabsContent value="login">
              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Welcome back</h2>
                <p className="text-gray-500 dark:text-gray-400">Enter your credentials to access your account</p>
                
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username or Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your username or email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Enter your password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="text-right">
                      <Button variant="link" className="text-primary p-0">
                        Forgot password?
                      </Button>
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-primary hover:bg-accent"
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? "Logging in..." : "Sign In"}
                    </Button>
                  </form>
                </Form>
                
                <div className="text-center mt-6">
                  <p>Don't have an account?{" "}
                    <Button variant="link" className="text-primary p-0" onClick={() => setActiveTab("register")}>
                      Create one
                    </Button>
                  </p>
                </div>
              </div>
            </TabsContent>
            
            {/* Register Form */}
            <TabsContent value="register">
              <div className="space-y-4">
                <h2 className="text-2xl font-bold">Create an account</h2>
                <p className="text-gray-500 dark:text-gray-400">Fill in your details to join XPlayHD</p>
                
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="Choose a username" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Enter your email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Create a password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Confirm your password" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="terms"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-2">
                          <FormControl>
                            <input
                              type="checkbox"
                              checked={field.value}
                              onChange={field.onChange}
                              className="h-4 w-4"
                            />
                          </FormControl>
                          <div>
                            <FormLabel className="text-sm text-gray-600 dark:text-gray-400">
                              I agree to the <a href="/terms" className="text-primary hover:underline">Terms of Service</a> and <a href="/privacy" className="text-primary hover:underline">Privacy Policy</a>
                            </FormLabel>
                            <FormMessage />
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full bg-primary hover:bg-accent"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? "Creating Account..." : "Create Account"}
                    </Button>
                  </form>
                </Form>
                
                <div className="text-center mt-6">
                  <p>Already have an account?{" "}
                    <Button variant="link" className="text-primary p-0" onClick={() => setActiveTab("login")}>
                      Sign in
                    </Button>
                  </p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </div>
      
      {/* Right Content - Hero Section */}
      <div className="hidden lg:flex lg:w-1/2 bg-gray-100 dark:bg-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-20">
          <AbstractBg1 />
        </div>
        <div className="relative z-10 flex flex-col items-center justify-center w-full p-12 text-center">
          <h2 className="text-4xl font-bold text-primary mb-6">Experience Adult Content Like Never Before</h2>
          <ul className="space-y-4 text-left max-w-md mx-auto">
            <li className="flex items-start">
              <svg className="h-6 w-6 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>High-quality HD and 4K videos with stunning playback quality</span>
            </li>
            <li className="flex items-start">
              <svg className="h-6 w-6 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Unlimited uploads and streaming with no bandwidth limits</span>
            </li>
            <li className="flex items-start">
              <svg className="h-6 w-6 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Create your own channel and build a following</span>
            </li>
            <li className="flex items-start">
              <svg className="h-6 w-6 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Personalized recommendations based on your viewing history</span>
            </li>
            <li className="flex items-start">
              <svg className="h-6 w-6 text-primary mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <span>Engage with content through likes, comments, and subscriptions</span>
            </li>
          </ul>
          <div className="mt-8 bg-white/10 backdrop-blur-sm p-6 rounded-lg">
            <h3 className="text-xl font-semibold mb-2">Join thousands of content creators and millions of viewers today</h3>
            <p className="text-gray-600 dark:text-gray-300">The #1 platform for adult content sharing and discovery</p>
          </div>
        </div>
      </div>
    </div>
  );
}