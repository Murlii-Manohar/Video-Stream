import { useQuery } from "@tanstack/react-query";
import { Video } from "@shared/schema";
import { VideoCard } from "@/components/ui/video-card";
import { Loader2 } from "lucide-react";

export default function PopularPage() {
  const { data: videos, isLoading, error } = useQuery<Video[]>({
    queryKey: ["/api/videos/popular"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-6rem)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <h2 className="text-2xl font-bold mb-4 dark:text-white">Error Loading Videos</h2>
        <p className="text-gray-600 dark:text-gray-300">{error.message}</p>
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <h2 className="text-2xl font-bold mb-4 dark:text-white">No Popular Videos Found</h2>
        <p className="text-gray-600 dark:text-gray-300">Check back later for popular content.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 dark:text-white">Popular Videos</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {videos.map((video) => (
          <VideoCard key={video.id} video={video} />
        ))}
      </div>
    </div>
  );
}