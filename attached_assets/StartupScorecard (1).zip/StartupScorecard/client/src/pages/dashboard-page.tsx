import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Video, Channel } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { CreateChannelModal } from "@/components/ui/create-channel-modal";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { VideoCard } from "@/components/ui/video-card";
import { AbstractBg3 } from "@/assets/svg/abstract-bg-3";
import { VideoIcon, Eye, ThumbsUp, MessageSquare, Activity, TrendingUp, CalendarDays, Users, PlusCircle, Settings } from "lucide-react";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

// Mock data for charts
const viewsData = [
  { name: "Jan", views: 4000 },
  { name: "Feb", views: 3000 },
  { name: "Mar", views: 5000 },
  { name: "Apr", views: 8000 },
  { name: "May", views: 7000 },
  { name: "Jun", views: 9000 },
  { name: "Jul", views: 11000 },
];

const categoryData = [
  { name: "Amateur", value: 45 },
  { name: "Professional", value: 25 },
  { name: "Couple", value: 15 },
  { name: "Solo", value: 10 },
  { name: "Other", value: 5 },
];

const COLORS = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)', 'var(--chart-5)'];

export default function DashboardPage() {
  const { user } = useAuth();
  const [timeframe, setTimeframe] = useState("month");
  const [createChannelOpen, setCreateChannelOpen] = useState(false);
  
  // Fetch user's channel
  const { data: channel } = useQuery<Channel>({
    queryKey: [`/api/channels/user/${user?.id}`],
    queryFn: async () => {
      try {
        const res = await fetch(`/api/channels/user/${user?.id}`);
        if (!res.ok) {
          throw new Error('Failed to fetch channel');
        }
        return res.json();
      } catch (error) {
        console.error('Error fetching channel:', error);
        return null;
      }
    },
    enabled: !!user,
  });
  
  // Fetch user's videos
  const { data: userVideos = [] } = useQuery<Video[]>({
    queryKey: [`/api/channels/${channel?.id}/videos`],
    queryFn: async () => {
      const res = await fetch(`/api/channels/${channel?.id}/videos`);
      if (!res.ok) {
        throw new Error('Failed to fetch videos');
      }
      return res.json();
    },
    enabled: !!channel?.id,
  });
  
  // Calculate total stats
  const totalViews = userVideos.reduce((sum, video) => sum + video.views, 0);
  const totalLikes = userVideos.reduce((sum, video) => sum + video.likes, 0);
  const totalComments = userVideos.length * 10; // Placeholder
  
  // Format numbers for display
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    } else {
      return num;
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="relative mb-8">
        <div className="absolute -top-20 right-0 w-full h-60 overflow-hidden opacity-10 pointer-events-none">
          <AbstractBg3 />
        </div>
        
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold">Creator Dashboard</h1>
              <p className="text-gray-600 dark:text-gray-400">
                Manage your content and track performance
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-2">
              <Select value={timeframe} onValueChange={setTimeframe}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="week">Last 7 days</SelectItem>
                  <SelectItem value="month">Last 30 days</SelectItem>
                  <SelectItem value="year">Last year</SelectItem>
                  <SelectItem value="all">All time</SelectItem>
                </SelectContent>
              </Select>
              
              <Link href="/upload">
                <Button className="bg-primary hover:bg-accent text-white">
                  <PlusCircle className="mr-2 h-4 w-4" />
                  Upload New Video
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Channel Info */}
          {channel ? (
            <div className="mt-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm">
              <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
                <Avatar className="w-24 h-24 border-4 border-primary">
                  <AvatarImage src={channel.banner} alt={channel.name} />
                  <AvatarFallback className="text-2xl">{channel.name[0]}</AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div>
                      <h2 className="text-2xl font-bold">{channel.name}</h2>
                      <p className="text-gray-600 dark:text-gray-400">{channel.description || "No description provided"}</p>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      <Link href={`/channel/${channel.id}`}>
                        <Button variant="outline">
                          <Eye className="mr-2 h-4 w-4" />
                          View Channel
                        </Button>
                      </Link>
                      <Button variant="outline">
                        <Settings className="mr-2 h-4 w-4" />
                        Channel Settings
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-8 mt-4">
                    <div className="flex items-center">
                      <Users className="text-primary mr-2 h-5 w-5" />
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Subscribers</p>
                        <p className="font-bold">{formatNumber(channel.subscriberCount || 0)}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <VideoIcon className="text-primary mr-2 h-5 w-5" />
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Videos</p>
                        <p className="font-bold">{userVideos.length}</p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <CalendarDays className="text-primary mr-2 h-5 w-5" />
                      <div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">Joined</p>
                        <p className="font-bold">
                          {new Date(channel.createdAt).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'short',
                            day: 'numeric',
                          })}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="mt-8 p-6 bg-white dark:bg-gray-800 rounded-lg shadow-sm text-center">
              <h2 className="text-xl font-bold mb-4">You don't have a channel yet</h2>
              <p className="mb-6">Create a channel to start uploading videos and building your audience</p>
              <Button 
                className="bg-primary hover:bg-accent text-white"
                onClick={() => setCreateChannelOpen(true)}
              >
                Create Channel
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {/* Stats and Analytics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
            <Eye className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(totalViews)}</div>
            <p className="text-xs text-muted-foreground">
              +{formatNumber(Math.floor(totalViews * 0.12))} from previous {timeframe}
            </p>
            <div className="h-[80px] mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart
                  data={viewsData}
                  margin={{ top: 5, right: 0, left: 0, bottom: 5 }}
                >
                  <defs>
                    <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Area 
                    type="monotone" 
                    dataKey="views" 
                    stroke="var(--primary)" 
                    fillOpacity={1} 
                    fill="url(#colorViews)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Likes</CardTitle>
            <ThumbsUp className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(totalLikes)}</div>
            <p className="text-xs text-muted-foreground">
              +{formatNumber(Math.floor(totalLikes * 0.08))} from previous {timeframe}
            </p>
            <div className="h-[80px] mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={viewsData.map(item => ({ name: item.name, likes: Math.floor(item.views * 0.15) }))}
                  margin={{ top: 5, right: 0, left: 0, bottom: 5 }}
                >
                  <Line 
                    type="monotone" 
                    dataKey="likes" 
                    stroke="var(--primary)" 
                    strokeWidth={2} 
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Comments</CardTitle>
            <MessageSquare className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatNumber(totalComments)}</div>
            <p className="text-xs text-muted-foreground">
              +{formatNumber(Math.floor(totalComments * 0.05))} from previous {timeframe}
            </p>
            <div className="h-[80px] mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={viewsData.map(item => ({ name: item.name, comments: Math.floor(item.views * 0.02) }))}
                  margin={{ top: 5, right: 0, left: 0, bottom: 5 }}
                >
                  <Bar dataKey="comments" fill="var(--primary)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="videos" className="mt-8">
        <TabsList>
          <TabsTrigger value="videos">Your Videos</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="audience">Audience</TabsTrigger>
        </TabsList>
        
        <TabsContent value="videos">
          <div className="grid grid-cols-1 gap-4">
            {userVideos.length > 0 ? (
              <>
                <div className="flex justify-between items-center my-4">
                  <h3 className="text-xl font-bold">Your Videos ({userVideos.length})</h3>
                  <Select defaultValue="newest">
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">Newest first</SelectItem>
                      <SelectItem value="oldest">Oldest first</SelectItem>
                      <SelectItem value="views">Most views</SelectItem>
                      <SelectItem value="likes">Most likes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {userVideos.map(video => (
                    <VideoCard 
                      key={video.id} 
                      video={video} 
                      channel={channel}
                    />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <VideoIcon className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-xl font-bold mb-2">No videos yet</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">Upload your first video to get started</p>
                <Link href="/upload">
                  <Button className="bg-primary hover:bg-accent text-white">
                    Upload Video
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="analytics">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Views Over Time</CardTitle>
                <CardDescription>
                  Track your video performance over the {timeframe}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={viewsData}
                      margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <defs>
                        <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.8} />
                          <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <Area 
                        type="monotone" 
                        dataKey="views" 
                        stroke="var(--primary)" 
                        fillOpacity={1} 
                        fill="url(#colorViews)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Category Breakdown</CardTitle>
                <CardDescription>
                  Distribution of views by video category
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {categoryData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
                <CardDescription>
                  Key metrics for your top-performing videos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-2">Video</th>
                        <th className="text-left py-3 px-2">Views</th>
                        <th className="text-left py-3 px-2">Likes</th>
                        <th className="text-left py-3 px-2">Comments</th>
                        <th className="text-left py-3 px-2">Watch Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {userVideos.slice(0, 5).map((video) => (
                        <tr key={video.id} className="border-b hover:bg-gray-50 dark:hover:bg-gray-800">
                          <td className="py-3 px-2">
                            <div className="flex items-center">
                              <div className="w-10 h-10 mr-2 bg-gray-200 dark:bg-gray-700 rounded overflow-hidden">
                                {video.thumbnail ? (
                                  <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
                                ) : (
                                  <div className="flex items-center justify-center h-full text-gray-500">
                                    <VideoIcon className="h-6 w-6" />
                                  </div>
                                )}
                              </div>
                              <div className="truncate max-w-[200px]">{video.title}</div>
                            </div>
                          </td>
                          <td className="py-3 px-2">{formatNumber(video.views)}</td>
                          <td className="py-3 px-2">{formatNumber(video.likes)}</td>
                          <td className="py-3 px-2">{formatNumber(Math.floor(video.views * 0.02))}</td>
                          <td className="py-3 px-2">{Math.floor(video.views * 0.5 / 60)} mins avg.</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="audience">
          <div className="grid grid-cols-1 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Audience Demographics</CardTitle>
                <CardDescription>
                  Information about your viewers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-lg font-semibold mb-4">Age Distribution</h4>
                    <div className="h-[250px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { age: "18-24", percentage: 35 },
                            { age: "25-34", percentage: 45 },
                            { age: "35-44", percentage: 15 },
                            { age: "45-54", percentage: 4 },
                            { age: "55+", percentage: 1 },
                          ]}
                          margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="age" />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="percentage" fill="var(--primary)" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-lg font-semibold mb-4">Geographic Distribution</h4>
                    <div className="h-[250px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          layout="vertical"
                          data={[
                            { country: "United States", percentage: 35 },
                            { country: "UK", percentage: 25 },
                            { country: "Canada", percentage: 15 },
                            { country: "Australia", percentage: 10 },
                            { country: "Germany", percentage: 8 },
                            { country: "Other", percentage: 7 },
                          ]}
                          margin={{ top: 5, right: 30, left: 40, bottom: 5 }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" />
                          <YAxis type="category" dataKey="country" />
                          <Tooltip />
                          <Bar dataKey="percentage" fill="var(--chart-2)" radius={[0, 4, 4, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Subscriber Growth</CardTitle>
                <CardDescription>
                  Track how your subscriber count has grown over time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={[
                        { month: "Jan", subscribers: 120 },
                        { month: "Feb", subscribers: 150 },
                        { month: "Mar", subscribers: 200 },
                        { month: "Apr", subscribers: 320 },
                        { month: "May", subscribers: 450 },
                        { month: "Jun", subscribers: 650 },
                        { month: "Jul", subscribers: channel?.subscriberCount || 800 },
                      ]}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="subscribers" 
                        stroke="var(--chart-1)" 
                        strokeWidth={2}
                        activeDot={{ r: 8 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Create Channel Modal */}
      <CreateChannelModal 
        open={createChannelOpen} 
        onOpenChange={setCreateChannelOpen}
        onSuccess={() => {
          // Refresh channel data after creating
          queryClient.invalidateQueries({ queryKey: [`/api/channels/user/${user?.id}`] });
        }}
      />
    </div>
  );
}
