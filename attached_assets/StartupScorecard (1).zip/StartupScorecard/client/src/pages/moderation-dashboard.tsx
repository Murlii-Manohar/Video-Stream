import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Redirect, Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";

import PendingVideos from "@/components/moderation/pending-videos";
import FlaggedComments from "@/components/moderation/flagged-comments";
import ReportsList from "@/components/moderation/reports-list";
import UsersList from "@/components/moderation/users-list";
import ChannelsList from "@/components/moderation/channels-list";
import ModerationLogs from "@/components/moderation/moderation-logs";

export default function ModerationDashboard() {
  const { user, isLoading } = useAuth();
  const [activeTab, setActiveTab] = useState("videos");
  const [, setLocation] = useLocation();

  // Redirect if not authenticated or not admin/moderator
  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user || (!user.isAdmin && !user.isModerator)) {
    return <Redirect to="/" />;
  }

  const handleTabChange = (value: string) => {
    setActiveTab(value);
  };

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Moderation Dashboard</h1>
          <p className="text-muted-foreground">
            Manage content, users, and reports
          </p>
        </div>
        <Button onClick={() => setLocation("/")}>Back to Site</Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Content Moderation</CardTitle>
          <CardDescription>
            Review and moderate videos, comments, users, channels, and reports
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={handleTabChange}>
            <TabsList className="mb-6 grid w-full grid-cols-6">
              <TabsTrigger value="videos">Videos</TabsTrigger>
              <TabsTrigger value="comments">Comments</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="users">Users</TabsTrigger>
              <TabsTrigger value="channels">Channels</TabsTrigger>
              <TabsTrigger value="logs">Logs</TabsTrigger>
            </TabsList>

            <TabsContent value="videos">
              <PendingVideos />
            </TabsContent>

            <TabsContent value="comments">
              <FlaggedComments />
            </TabsContent>

            <TabsContent value="reports">
              <ReportsList />
            </TabsContent>

            <TabsContent value="users">
              <UsersList />
            </TabsContent>

            <TabsContent value="channels">
              <ChannelsList />
            </TabsContent>

            <TabsContent value="logs">
              <ModerationLogs />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}