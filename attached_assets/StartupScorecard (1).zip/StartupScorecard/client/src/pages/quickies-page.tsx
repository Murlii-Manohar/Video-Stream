import { useQuery } from "@tanstack/react-query";
import { Video, Channel } from "@shared/schema";
import { VideoCard } from "@/components/ui/video-card";
import { Loader2 } from "lucide-react";

export default function QuickiesPage() {
  const { data: videos, isLoading, error } = useQuery<Video[]>({
    queryKey: ["/api/videos/quickies"],
  });

  // Get channels to display with videos
  const { data: channels } = useQuery<Channel[]>({
    queryKey: ["/api/channels"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-6rem)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <h2 className="text-2xl font-bold mb-4 dark:text-white">Error Loading Quickies</h2>
        <p className="text-gray-600 dark:text-gray-300">{error.message}</p>
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <h2 className="text-2xl font-bold mb-4 dark:text-white">No Quickies Found</h2>
        <p className="text-gray-600 dark:text-gray-300">Check back soon for short-form content.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <h1 className="text-3xl font-bold dark:text-white">
          Quickies 
          <span className="ml-2 text-sm bg-primary text-white px-2 py-1 rounded-full">HOT</span>
        </h1>
      </div>
      
      {/* Grid layout for quickies - using our custom quickies-grid class */}
      <div className="grid quickies-grid">
        {videos.map((video) => {
          // Find the channel for this video
          const videoChannel = channels?.find(c => c.id === video.channelId);
          
          return (
            <VideoCard 
              key={video.id} 
              video={video} 
              channel={videoChannel}
              isQuickie={true}
            />
          );
        })}
      </div>
    </div>
  );
}