import { useState, useRef, ChangeEvent } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Channel, VideoCategory } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { AbstractBg2 } from "@/assets/svg/abstract-bg-2";
import { Upload, X, FilePlus2, VideoIcon } from "lucide-react";

export default function UploadPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [thumbnailFile, setThumbnailFile] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [tags, setTags] = useState("");
  const [isQuickie, setIsQuickie] = useState(false);
  const [privacy, setPrivacy] = useState("public");
  
  // Check if user has a channel
  const { data: channel, isLoading: channelLoading } = useQuery<Channel | null>({
    queryKey: [`/api/channels/user/${user?.id}`],
    queryFn: async () => {
      try {
        const res = await fetch(`/api/channels/user/${user?.id}`);
        if (res.status === 404) {
          return null;
        }
        if (!res.ok) {
          throw new Error('Failed to fetch channel');
        }
        return res.json();
      } catch (error) {
        console.error('Error fetching channel:', error);
        return null;
      }
    },
    enabled: !!user,
  });
  
  // Handle video file selection
  const handleVideoChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Check file type
      if (!file.type.startsWith("video/")) {
        toast({
          title: "Invalid file type",
          description: "Please select a video file",
          variant: "destructive",
        });
        return;
      }
      
      // Check file size (max 500MB)
      if (file.size > 500 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Maximum file size is 500MB",
          variant: "destructive",
        });
        return;
      }
      
      setVideoFile(file);
      
      // Auto-fill title from filename
      if (!title) {
        const fileName = file.name.split('.').slice(0, -1).join('.');
        setTitle(fileName);
      }
    }
  };
  
  // Handle thumbnail file selection
  const handleThumbnailChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      
      // Check file type
      if (!file.type.startsWith("image/")) {
        toast({
          title: "Invalid file type",
          description: "Please select an image file",
          variant: "destructive",
        });
        return;
      }
      
      setThumbnailFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setThumbnailPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Trigger file input click
  const handleSelectFile = () => {
    fileInputRef.current?.click();
  };
  
  // Clear selected video file
  const clearVideoFile = () => {
    setVideoFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  // Create channel
  const createChannel = async () => {
    try {
      const response = await fetch("/api/channels", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: `${user?.username}'s Channel`,
          description: `The official channel of ${user?.username}`,
          userId: user?.id,
        }),
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error('Failed to create channel');
      }
      
      const newChannel = await response.json();
      toast({
        title: "Channel created",
        description: "Your channel has been created successfully",
      });
      
      return newChannel;
    } catch (error) {
      console.error('Error creating channel:', error);
      toast({
        title: "Channel creation failed",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
      throw error;
    }
  };
  
  // Get video duration
  const getVideoDuration = (file: File): Promise<number> => {
    return new Promise((resolve, reject) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      
      video.onloadedmetadata = () => {
        window.URL.revokeObjectURL(video.src);
        resolve(video.duration);
      };
      
      video.onerror = () => {
        reject(new Error("Failed to load video metadata"));
      };
      
      video.src = URL.createObjectURL(file);
    });
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!videoFile) {
      toast({
        title: "No video selected",
        description: "Please select a video file to upload",
        variant: "destructive",
      });
      return;
    }
    
    if (!title.trim()) {
      toast({
        title: "Title required",
        description: "Please enter a title for your video",
        variant: "destructive",
      });
      return;
    }
    
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      // Get video duration
      const duration = await getVideoDuration(videoFile);
      
      // Check if quickie duration is valid (max 2 minutes = 120 seconds)
      if (isQuickie && duration > 120) {
        toast({
          title: "Quickie video too long",
          description: "Quickie videos must be 2 minutes or shorter. Please trim your video or upload it as a regular video.",
          variant: "destructive",
        });
        setIsUploading(false);
        return;
      }
      
      // Create channel if user doesn't have one
      let userChannel = channel;
      if (!userChannel) {
        userChannel = await createChannel();
      }
      
      // Create form data with all video information
      const formData = new FormData();
      formData.append("video", videoFile);
      formData.append("title", title);
      formData.append("description", description || '');
      formData.append("category", category || '');
      formData.append("tags", tags || '');
      formData.append("isQuickie", isQuickie.toString());
      formData.append("isPremium", (privacy === "premium").toString());
      formData.append("duration", duration.toString());
      
      // Add thumbnail if available
      if (thumbnailFile) {
        formData.append("thumbnail", thumbnailFile);
      }
      
      // Create a simulated upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return 95;
          }
          return prev + 5;
        });
      }, 500);
      
      // Log the upload data (for debugging)
      console.log("Uploading video:", {
        title,
        isQuickie,
        duration: `${Math.floor(duration / 60)}:${Math.floor(duration % 60).toString().padStart(2, '0')}`,
        hasThumbnail: !!thumbnailFile,
        isPremium: privacy === "premium"
      });
      
      // Submit the form data to the API
      const response = await fetch('/api/videos', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      clearInterval(progressInterval);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Upload failed');
      }
      
      setUploadProgress(100);
      
      const uploadedVideo = await response.json();
      
      toast({
        title: "Upload successful",
        description: "Your video has been uploaded successfully",
      });
      
      // Navigate to the video page
      setTimeout(() => {
        navigate(`/video/${uploadedVideo.id}`);
      }, 1500);
      
    } catch (error) {
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An error occurred during upload",
        variant: "destructive",
      });
      console.error("Upload error details:", error);
      setIsUploading(false);
      setUploadProgress(0);
    }
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="relative">
        <div className="absolute -top-20 right-0 w-full h-60 overflow-hidden opacity-10 pointer-events-none">
          <AbstractBg2 />
        </div>
        
        <div className="relative z-10">
          <div className="mb-6">
            <h1 className="text-3xl font-bold">Upload Video</h1>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Share your content with the XPlayHD community
            </p>
          </div>
          
          <Tabs defaultValue="upload" className="mb-6">
            <TabsList>
              <TabsTrigger value="upload">Upload Video</TabsTrigger>
              <TabsTrigger value="quickie">Upload Quickie</TabsTrigger>
            </TabsList>
            <TabsContent value="upload">
              <Card>
                <CardHeader>
                  <CardTitle>Standard Video Upload</CardTitle>
                  <CardDescription>
                    Upload content in high quality with full details
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Video File Upload */}
                    <div className="space-y-2">
                      <Label htmlFor="video">Video File</Label>
                      {!videoFile ? (
                        <div 
                          className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                          onClick={handleSelectFile}
                        >
                          <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                          <p className="mb-2">Drag and drop your video file here</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">or</p>
                          <Button type="button" onClick={handleSelectFile}>
                            Select File
                          </Button>
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-4">
                            Max file size: 500MB. Supported formats: MP4, MOV, AVI
                          </p>
                        </div>
                      ) : (
                        <div className="border rounded-lg p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <VideoIcon className="h-8 w-8 text-primary" />
                              <div>
                                <p className="font-medium">{videoFile.name}</p>
                                <p className="text-sm text-gray-500">
                                  {(videoFile.size / (1024 * 1024)).toFixed(2)} MB
                                </p>
                              </div>
                            </div>
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="sm" 
                              onClick={clearVideoFile}
                              className="text-gray-500 hover:text-red-500"
                            >
                              <X className="h-5 w-5" />
                            </Button>
                          </div>
                        </div>
                      )}
                      <input
                        type="file"
                        id="video"
                        ref={fileInputRef}
                        onChange={handleVideoChange}
                        accept="video/*"
                        className="hidden"
                      />
                    </div>
                    
                    <div className="grid gap-4 md:grid-cols-2">
                      {/* Video Details */}
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="title">Title</Label>
                          <Input
                            id="title"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            placeholder="Enter video title"
                            required
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="description">Description</Label>
                          <Textarea
                            id="description"
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            placeholder="Enter video description"
                            rows={3}
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="category">Category</Label>
                          <Select value={category} onValueChange={setCategory}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a category" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value={VideoCategory.TEEN}>Teen</SelectItem>
                              <SelectItem value={VideoCategory.MILF}>MILF</SelectItem>
                              <SelectItem value={VideoCategory.STEPMOM}>Stepmom</SelectItem>
                              <SelectItem value={VideoCategory.EBONY}>Ebony</SelectItem>
                              <SelectItem value={VideoCategory.BLACK}>Black</SelectItem>
                              <SelectItem value={VideoCategory.ASIAN}>Asian</SelectItem>
                              <SelectItem value={VideoCategory.INDIAN}>Indian</SelectItem>
                              <SelectItem value={VideoCategory.LATINA}>Latina</SelectItem>
                              <SelectItem value={VideoCategory.BLONDE}>Blonde</SelectItem>
                              <SelectItem value={VideoCategory.BRUNETTE}>Brunette</SelectItem>
                              <SelectItem value={VideoCategory.REDHEAD}>Redhead</SelectItem>
                              <SelectItem value={VideoCategory.AMATEUR}>Amateur</SelectItem>
                              <SelectItem value={VideoCategory.PROFESSIONAL}>Professional</SelectItem>
                              <SelectItem value={VideoCategory.SOLO}>Solo</SelectItem>
                              <SelectItem value={VideoCategory.LESBIAN}>Lesbian</SelectItem>
                              <SelectItem value={VideoCategory.THREESOME}>Threesome</SelectItem>
                              <SelectItem value={VideoCategory.TOYS}>Toys</SelectItem>
                              <SelectItem value={VideoCategory.COSPLAY}>Cosplay</SelectItem>
                              <SelectItem value={VideoCategory.POV}>POV</SelectItem>
                              <SelectItem value={VideoCategory.OTHER}>Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="tags">Tags</Label>
                          <Input
                            id="tags"
                            value={tags}
                            onChange={(e) => setTags(e.target.value)}
                            placeholder="Enter tags (comma separated)"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="privacy">Privacy</Label>
                          <RadioGroup 
                            value={privacy} 
                            onValueChange={setPrivacy}
                            className="flex flex-col space-y-1"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="public" id="public" />
                              <Label htmlFor="public" className="cursor-pointer">Public</Label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="premium" id="premium" />
                              <Label htmlFor="premium" className="cursor-pointer">Premium Only</Label>
                            </div>
                          </RadioGroup>
                        </div>
                      </div>
                      
                      {/* Thumbnail */}
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="thumbnail">Thumbnail</Label>
                          <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-4 text-center">
                            {thumbnailPreview ? (
                              <div className="relative">
                                <img 
                                  src={thumbnailPreview} 
                                  alt="Thumbnail preview" 
                                  className="w-full h-32 object-cover rounded"
                                />
                                <Button
                                  type="button"
                                  variant="destructive"
                                  size="sm"
                                  className="absolute top-2 right-2"
                                  onClick={() => {
                                    setThumbnailFile(null);
                                    setThumbnailPreview(null);
                                  }}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ) : (
                              <>
                                <p className="mb-2">Upload a thumbnail image</p>
                                <Input
                                  type="file"
                                  id="thumbnail"
                                  onChange={handleThumbnailChange}
                                  accept="image/*"
                                  className="cursor-pointer"
                                />
                                <p className="text-xs text-gray-500 mt-2">
                                  Recommended size: 1280x720px
                                </p>
                              </>
                            )}
                          </div>
                        </div>
                        
                        {/* Upload Progress */}
                        {isUploading && (
                          <div className="space-y-2">
                            <Label>Upload Progress</Label>
                            <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                              <div 
                                className="bg-primary h-2.5 rounded-full" 
                                style={{ width: `${uploadProgress}%` }}
                              ></div>
                            </div>
                            <p className="text-sm text-center">{uploadProgress}%</p>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Submit Buttons */}
                    <div className="flex justify-end space-x-4">
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={() => navigate("/")}
                        disabled={isUploading}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="bg-primary hover:bg-accent"
                        disabled={!videoFile || isUploading}
                      >
                        {isUploading ? "Uploading..." : "Upload Video"}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="quickie">
              <Card>
                <CardHeader>
                  <CardTitle>Quickie Upload</CardTitle>
                  <CardDescription>
                    Upload short vertical clips for the Quickies section
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    {/* Same form as above but with isQuickie set to true and simplified fields */}
                    <div className="space-y-2">
                      <Label htmlFor="video">Video File</Label>
                      {!videoFile ? (
                        <div 
                          className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                          onClick={handleSelectFile}
                        >
                          <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                          <p className="mb-2">Drag and drop your video file here</p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">or</p>
                          <Button type="button" onClick={handleSelectFile}>
                            Select File
                          </Button>
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-4">
                            Max file size: 500MB. Supported formats: MP4, MOV, AVI
                          </p>
                          <p className="text-xs text-red-500 font-medium mt-2">
                            Note: Quickie videos must be 2 minutes or less in duration
                          </p>
                        </div>
                      ) : (
                        <div className="border rounded-lg p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <VideoIcon className="h-8 w-8 text-primary" />
                              <div>
                                <p className="font-medium">{videoFile.name}</p>
                                <p className="text-sm text-gray-500">
                                  {(videoFile.size / (1024 * 1024)).toFixed(2)} MB
                                </p>
                              </div>
                            </div>
                            <Button 
                              type="button" 
                              variant="ghost" 
                              size="sm" 
                              onClick={clearVideoFile}
                              className="text-gray-500 hover:text-red-500"
                            >
                              <X className="h-5 w-5" />
                            </Button>
                          </div>
                        </div>
                      )}
                      <input
                        type="file"
                        id="video"
                        ref={fileInputRef}
                        onChange={handleVideoChange}
                        accept="video/*"
                        className="hidden"
                      />
                    </div>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="title">Title</Label>
                        <Input
                          id="title"
                          value={title}
                          onChange={(e) => setTitle(e.target.value)}
                          placeholder="Enter quickie title"
                          required
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="category">Category</Label>
                        <Select value={category} onValueChange={setCategory}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                          <SelectContent>
                              <SelectItem value={VideoCategory.TEEN}>Teen</SelectItem>
                              <SelectItem value={VideoCategory.MILF}>MILF</SelectItem>
                              <SelectItem value={VideoCategory.STEPMOM}>Stepmom</SelectItem>
                              <SelectItem value={VideoCategory.EBONY}>Ebony</SelectItem>
                              <SelectItem value={VideoCategory.BLACK}>Black</SelectItem>
                              <SelectItem value={VideoCategory.ASIAN}>Asian</SelectItem>
                              <SelectItem value={VideoCategory.INDIAN}>Indian</SelectItem>
                              <SelectItem value={VideoCategory.LATINA}>Latina</SelectItem>
                              <SelectItem value={VideoCategory.BLONDE}>Blonde</SelectItem>
                              <SelectItem value={VideoCategory.BRUNETTE}>Brunette</SelectItem>
                              <SelectItem value={VideoCategory.REDHEAD}>Redhead</SelectItem>
                              <SelectItem value={VideoCategory.AMATEUR}>Amateur</SelectItem>
                              <SelectItem value={VideoCategory.PROFESSIONAL}>Professional</SelectItem>
                              <SelectItem value={VideoCategory.SOLO}>Solo</SelectItem>
                              <SelectItem value={VideoCategory.LESBIAN}>Lesbian</SelectItem>
                              <SelectItem value={VideoCategory.THREESOME}>Threesome</SelectItem>
                              <SelectItem value={VideoCategory.TOYS}>Toys</SelectItem>
                              <SelectItem value={VideoCategory.COSPLAY}>Cosplay</SelectItem>
                              <SelectItem value={VideoCategory.POV}>POV</SelectItem>
                              <SelectItem value={VideoCategory.OTHER}>Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="tags">Tags</Label>
                        <Input
                          id="tags"
                          value={tags}
                          onChange={(e) => setTags(e.target.value)}
                          placeholder="Enter tags (comma separated)"
                        />
                      </div>
                      
                      {/* Thumbnail Upload */}
                      <div className="space-y-2">
                        <Label htmlFor="thumbnail">Thumbnail</Label>
                        <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-4 text-center">
                          {thumbnailPreview ? (
                            <div className="relative">
                              <img 
                                src={thumbnailPreview} 
                                alt="Thumbnail preview" 
                                className="w-full h-32 object-cover rounded"
                              />
                              <Button
                                type="button"
                                variant="destructive"
                                size="sm"
                                className="absolute top-2 right-2"
                                onClick={() => {
                                  setThumbnailFile(null);
                                  setThumbnailPreview(null);
                                }}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          ) : (
                            <>
                              <p className="mb-2">Upload a thumbnail image</p>
                              <Input
                                type="file"
                                id="thumbnail-quickie"
                                onChange={handleThumbnailChange}
                                accept="image/*"
                                className="cursor-pointer"
                              />
                              <p className="text-xs text-gray-500 mt-2">
                                Recommended size: 720x1280px (portrait)
                              </p>
                            </>
                          )}
                        </div>
                      </div>
                      
                      {/* Upload Progress */}
                      {isUploading && (
                        <div className="space-y-2">
                          <Label>Upload Progress</Label>
                          <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                            <div 
                              className="bg-primary h-2.5 rounded-full" 
                              style={{ width: `${uploadProgress}%` }}
                            ></div>
                          </div>
                          <p className="text-sm text-center">{uploadProgress}%</p>
                        </div>
                      )}
                    </div>
                    
                    {/* Submit Buttons */}
                    <div className="flex justify-end space-x-4">
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={() => navigate("/")}
                        disabled={isUploading}
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="bg-primary hover:bg-accent"
                        disabled={!videoFile || isUploading}
                        onClick={() => setIsQuickie(true)}
                      >
                        {isUploading ? "Uploading..." : "Upload Quickie"}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}