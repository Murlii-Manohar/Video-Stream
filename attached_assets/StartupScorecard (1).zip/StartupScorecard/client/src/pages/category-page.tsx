import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Video } from "@shared/schema";
import { Loader2 } from "lucide-react";
import { VideoCard } from "@/components/ui/video-card";
import { useToast } from "@/hooks/use-toast";

// Helper function to format category name for display
function formatCategoryName(category: string): string {
  if (!category) return "";
  
  // Convert from slug-case or lowercase to Title Case
  // e.g., "teen" -> "Teen", "step-mom" -> "Step Mom"
  return category
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ');
}

export default function CategoryPage() {
  const { category } = useParams();
  const { toast } = useToast();
  const [formattedCategory, setFormattedCategory] = useState("");
  
  useEffect(() => {
    if (category) {
      setFormattedCategory(formatCategoryName(category));
    }
  }, [category]);
  
  // Fetch videos by category
  const { data: videos, isLoading, error } = useQuery<Video[]>({
    queryKey: ['/api/videos/category', category],
    queryFn: async () => {
      try {
        const res = await fetch(`/api/videos/category/${category}`);
        if (!res.ok) {
          throw new Error('Failed to fetch videos');
        }
        return res.json();
      } catch (error) {
        console.error('Error fetching videos:', error);
        throw error;
      }
    },
    enabled: !!category,
  });
  
  // Handle error display
  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: "Failed to load videos for this category",
        variant: "destructive",
      });
    }
  }, [error, toast]);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">{formattedCategory || 'Category'} Videos</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Discover the best {formattedCategory.toLowerCase()} content on XPlayHD
        </p>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : videos && videos.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <h3 className="text-xl font-medium mb-2">No videos found</h3>
          <p className="text-gray-600 dark:text-gray-400">
            We couldn't find any videos in the {formattedCategory.toLowerCase()} category.
          </p>
        </div>
      )}
    </div>
  );
}