import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Users, Video, Radio, BarChart3, Flag, Award } from "lucide-react";
import { Link, useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";

// Admin management components
import { UserManagement } from "@/components/admin/user-management";
import { VideoManagement } from "@/components/admin/video-management";
import { ChannelManagement } from "@/components/admin/channel-management";
import { CategoryManagement } from "@/components/admin/category-management";

interface AdminStats {
  totalUsers: number;
  premiumUsers: number;
  newUsersToday: number;
  activeUsersWeek: number;
  totalVideos: number;
  videosUploadedToday: number;
  totalViews: number;
  totalChannels: number;
  verifiedChannels: number;
  commentsToday: number;
  pendingReports: number;
}

// Internal component to handle admin content display 
function AdminContent() {
  const { toast } = useToast();
  const [loading, setLoading] = useState<boolean>(true);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [activeTab, setActiveTab] = useState<string>("overview");
  
  // Fetch stats only once when component mounts
  useEffect(() => {
    const fetchStats = async () => {
      try {
        setLoading(true);
        const response = await apiRequest("GET", "/api/admin/stats");
        if (!response.ok) {
          throw new Error("Failed to fetch admin statistics");
        }

        const data = await response.json();
        setStats(data);
      } catch (error) {
        console.error("Error fetching admin stats:", error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load admin statistics"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, [toast]);
  
  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage and monitor your platform</p>
      </div>

      <Tabs defaultValue="overview" onValueChange={setActiveTab} value={activeTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          {loading ? (
            <div className="flex items-center justify-center h-[50vh]">
              <Loader2 className="h-8 w-8 animate-spin text-border" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {stats && (
                <>
                  {/* Users Stats */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center text-xl">
                        <Users className="mr-2 h-5 w-5" /> User Statistics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Users</span>
                          <span className="font-medium">{stats.totalUsers.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Premium Users</span>
                          <span className="font-medium">{stats.premiumUsers.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">New Today</span>
                          <span className="font-medium">{stats.newUsersToday.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Active (7 days)</span>
                          <span className="font-medium">{stats.activeUsersWeek.toLocaleString()}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Video Stats */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center text-xl">
                        <Video className="mr-2 h-5 w-5" /> Video Statistics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Videos</span>
                          <span className="font-medium">{stats.totalVideos.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Uploaded Today</span>
                          <span className="font-medium">{stats.videosUploadedToday.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Views</span>
                          <span className="font-medium">{stats.totalViews.toLocaleString()}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Channel Stats */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center text-xl">
                        <Radio className="mr-2 h-5 w-5" /> Channel Statistics
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Total Channels</span>
                          <span className="font-medium">{stats.totalChannels.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Verified Channels</span>
                          <span className="font-medium">{stats.verifiedChannels.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Verification Rate</span>
                          <span className="font-medium">
                            {stats.totalChannels
                              ? Math.round((stats.verifiedChannels / stats.totalChannels) * 100)
                              : 0}%
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Engagement Stats */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center text-xl">
                        <BarChart3 className="mr-2 h-5 w-5" /> Engagement
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Comments Today</span>
                          <span className="font-medium">{stats.commentsToday.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Avg. Views Per Video</span>
                          <span className="font-medium">
                            {stats.totalVideos
                              ? Math.round(stats.totalViews / stats.totalVideos)
                              : 0}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Moderation Stats */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center text-xl">
                        <Flag className="mr-2 h-5 w-5" /> Moderation
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Pending Reports</span>
                          <span className="font-medium text-orange-500">{stats.pendingReports.toLocaleString()}</span>
                        </div>
                      </div>
                      <div className="mt-4">
                        <Link href="/moderation">
                          <Button variant="outline" className="w-full">
                            Go to Moderation Dashboard
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Premium Stats */}
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex items-center text-xl">
                        <Award className="mr-2 h-5 w-5" /> Premium Status
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Premium Users</span>
                          <span className="font-medium">{stats.premiumUsers.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Premium Rate</span>
                          <span className="font-medium">
                            {stats.totalUsers
                              ? Math.round((stats.premiumUsers / stats.totalUsers) * 100)
                              : 0}%
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>
          )}
        </TabsContent>

        <TabsContent value="users">
          <div className="space-y-8">
            <UserManagement />
          </div>
        </TabsContent>

        <TabsContent value="content">
          <div className="space-y-8">
            <Tabs defaultValue="videos" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="videos">Videos</TabsTrigger>
                <TabsTrigger value="channels">Channels</TabsTrigger>
                <TabsTrigger value="categories">Categories</TabsTrigger>
              </TabsList>
              
              <TabsContent value="videos">
                <VideoManagement />
              </TabsContent>
              
              <TabsContent value="channels">
                <ChannelManagement />
              </TabsContent>
              
              <TabsContent value="categories">
                <CategoryManagement />
              </TabsContent>
            </Tabs>
          </div>
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Reports Management</CardTitle>
              <CardDescription>
                Handle user reports and content issues
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-muted-foreground">Reports management will be implemented here.</p>
                <Link href="/moderation">
                  <Button variant="default">Go to Moderation Dashboard</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function AdminPanel() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Handle access denied
  useEffect(() => {
    if (!isLoading && (!user || !user.isAdmin)) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You do not have permission to access this page"
      });
      navigate("/");
    }
  }, [user, isLoading, toast, navigate]);

  // Show loading indicator while checking authentication or redirecting
  if (isLoading || !user || !user.isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }
  
  // User is authenticated and is an admin, render admin content
  return <AdminContent />;
}