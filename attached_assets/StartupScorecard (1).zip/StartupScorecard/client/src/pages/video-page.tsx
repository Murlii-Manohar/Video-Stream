import { useState, useEffect } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { VideoPlayer } from "@/components/ui/video-player";
import { VideoCard } from "@/components/ui/video-card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Video, Channel, Comment, User, ContentType } from "@shared/schema";
import { Loader2, ThumbsUp, ThumbsDown, Share2, Flag } from "lucide-react";

interface CommentWithUser extends Comment {
  user: {
    id: number;
    username: string;
    avatar: string;
  } | null;
}

export default function VideoPage() {
  const { id } = useParams<{ id: string }>();
  const videoId = parseInt(id);
  const { user } = useAuth();
  const { toast } = useToast();
  const [newComment, setNewComment] = useState("");
  const [isSubmittingComment, setIsSubmittingComment] = useState(false);
  const [userLiked, setUserLiked] = useState<boolean | null>(null);
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [reportType, setReportType] = useState("inappropriate");
  
  // Fetch video
  const { data: video, isLoading: videoLoading, error: videoError } = useQuery<Video>({
    queryKey: [`/api/videos/${videoId}`],
    queryFn: async () => {
      const res = await fetch(`/api/videos/${videoId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch video');
      }
      return res.json();
    },
    enabled: !isNaN(videoId),
  });
  
  // Fetch channel
  const { data: channel } = useQuery<Channel>({
    queryKey: ['/api/channels', video?.channelId],
    queryFn: async () => {
      const res = await fetch(`/api/channels/${video?.channelId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch channel');
      }
      return res.json();
    },
    enabled: !!video?.channelId,
  });
  
  // Fetch channel owner
  const { data: channelOwner } = useQuery<User>({
    queryKey: ['/api/users', channel?.userId],
    queryFn: async () => {
      const res = await fetch(`/api/users/${channel?.userId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch channel owner');
      }
      return res.json();
    },
    enabled: !!channel?.userId,
  });
  
  // Fetch comments
  const { data: comments = [], refetch: refetchComments } = useQuery<CommentWithUser[]>({
    queryKey: [`/api/videos/${videoId}/comments`],
    queryFn: async () => {
      const res = await fetch(`/api/videos/${videoId}/comments`);
      if (!res.ok) {
        throw new Error('Failed to fetch comments');
      }
      return res.json();
    },
    enabled: !isNaN(videoId),
  });
  
  // Fetch related videos
  const { data: relatedVideos = [] } = useQuery<Video[]>({
    queryKey: ['/api/videos/related', videoId],
    queryFn: async () => {
      // In a real app, we'd have a proper endpoint for related videos
      // Here we'll just fetch some trending videos
      const res = await fetch('/api/videos/trending?limit=5');
      if (!res.ok) {
        throw new Error('Failed to fetch related videos');
      }
      return res.json();
    },
    enabled: !isNaN(videoId),
  });
  
  // Check if user has liked this video
  useEffect(() => {
    if (!user || !video) return;
    
    const checkLikeStatus = async () => {
      try {
        const res = await fetch(`/api/videos/${videoId}/like/status`);
        if (res.ok) {
          const data = await res.json();
          // If the like exists, set the like status, otherwise set to null (no rating)
          setUserLiked(data.exists ? data.isLike : null);
        }
      } catch (error) {
        console.error("Error checking like status:", error);
      }
    };
    
    checkLikeStatus();
  }, [user, video, videoId]);
  
  // Post comment mutation
  const commentMutation = useMutation({
    mutationFn: async (comment: string) => {
      return await apiRequest("POST", `/api/videos/${videoId}/comments`, { content: comment });
    },
    onSuccess: () => {
      setNewComment("");
      refetchComments();
      toast({
        title: "Comment posted",
        description: "Your comment has been posted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to post comment",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Like video mutation
  const likeMutation = useMutation({
    mutationFn: async (isLike: boolean) => {
      return await apiRequest("POST", `/api/videos/${videoId}/like`, { isLike });
    },
    onSuccess: (_, variables) => {
      setUserLiked(variables);
      queryClient.invalidateQueries({ queryKey: [`/api/videos/${videoId}`] });
      toast({
        title: variables ? "Video liked" : "Video disliked",
        description: `You've ${variables ? 'liked' : 'disliked'} this video`,
      });
    },
    onError: (error) => {
      toast({
        title: "Action failed",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Remove like mutation
  const removeLikeMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", `/api/videos/${videoId}/like`);
    },
    onSuccess: () => {
      setUserLiked(null);
      queryClient.invalidateQueries({ queryKey: [`/api/videos/${videoId}`] });
      toast({
        title: "Rating removed",
        description: "Your rating has been removed",
      });
    },
    onError: (error) => {
      toast({
        title: "Action failed",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Report video mutation
  const reportMutation = useMutation({
    mutationFn: async (data: { reason: string; details?: string }) => {
      return await apiRequest("POST", "/api/reports", {
        contentType: ContentType.VIDEO,
        contentId: videoId,
        reason: data.reason,
        details: data.details
      });
    },
    onSuccess: () => {
      setIsReportDialogOpen(false);
      setReportReason("");
      setReportType("inappropriate");
      
      toast({
        title: "Report submitted",
        description: "Thank you for helping keep our platform safe. Our moderators will review your report.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to submit report",
        description: error.message || "An error occurred while submitting your report.",
        variant: "destructive",
      });
    },
  });
  
  // Handle comment submission
  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to comment",
        variant: "destructive",
      });
      return;
    }
    
    if (!newComment.trim()) {
      toast({
        title: "Empty comment",
        description: "Please enter a comment",
        variant: "destructive",
      });
      return;
    }
    
    commentMutation.mutate(newComment.trim());
  };
  
  // Handle like/dislike
  const handleRating = (isLike: boolean) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to rate videos",
        variant: "destructive",
      });
      return;
    }
    
    // If the user clicks the same button they already clicked, remove the rating
    if (userLiked === isLike) {
      removeLikeMutation.mutate();
    } else {
      likeMutation.mutate(isLike);
    }
  };
  
  // Handle subscription
  const handleSubscribe = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to subscribe to channels",
        variant: "destructive",
      });
      return;
    }
    
    if (!channel) return;
    
    // This would call an API subscription endpoint
    toast({
      title: "Subscription",
      description: `You've subscribed to ${channel.name}`,
    });
  };
  
  // Handle report submission
  const handleReport = () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to report content",
        variant: "destructive",
      });
      return;
    }
    
    setIsReportDialogOpen(true);
  };
  
  // Submit report
  const submitReport = () => {
    if (!reportReason.trim()) {
      toast({
        title: "Report reason required",
        description: "Please provide a reason for your report",
        variant: "destructive",
      });
      return;
    }
    
    reportMutation.mutate({
      reason: reportType,
      details: reportReason
    });
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Show loading state
  if (videoLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  // Show error state
  if (videoError || !video) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Video Not Found</h2>
        <p className="mb-6">The video you're looking for may have been removed or doesn't exist.</p>
        <Link href="/">
          <Button className="bg-primary hover:bg-accent text-white">
            Return to Home
          </Button>
        </Link>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Report Dialog */}
      <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Report Content</DialogTitle>
            <DialogDescription>
              Please let us know why you're reporting this video. This will help our moderation team take appropriate action.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Reason for report</h4>
              <Select 
                value={reportType} 
                onValueChange={setReportType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a reason" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="inappropriate">Inappropriate Content</SelectItem>
                  <SelectItem value="copyright">Copyright Violation</SelectItem>
                  <SelectItem value="misleading">Misleading Information</SelectItem>
                  <SelectItem value="violent">Violent or Harmful Content</SelectItem>
                  <SelectItem value="harassment">Harassment or Bullying</SelectItem>
                  <SelectItem value="spam">Spam or Misleading</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-medium">Additional details</h4>
              <Textarea 
                placeholder="Please provide more details about your report..."
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                rows={4}
              />
            </div>
          </div>
          <DialogFooter className="sm:justify-between">
            <Button 
              variant="outline" 
              onClick={() => setIsReportDialogOpen(false)}
              disabled={reportMutation.isPending}
            >
              Cancel
            </Button>
            <Button 
              onClick={submitReport}
              className="bg-primary hover:bg-accent text-white"
              disabled={reportMutation.isPending}
            >
              {reportMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : "Submit Report"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <div className="flex flex-col lg:flex-row gap-6">
        {/* Main Content */}
        <div className="lg:w-8/12">
          {/* Video Player */}
          <VideoPlayer 
            src={video.videoPath} 
            poster={video.thumbnail}
          />
          
          {/* Video Info */}
          <div className="mt-4">
            <h1 className="text-2xl font-bold">{video.title}</h1>
            <div className="flex flex-wrap items-center justify-between mt-2">
              <div className="text-sm text-gray-600 dark:text-gray-400">
                {video.views.toLocaleString()} views • {formatDate(video.createdAt)}
              </div>
              
              {/* Action Buttons */}
              <div className="flex space-x-2 mt-2 sm:mt-0">
                <Button 
                  variant="outline" 
                  size="sm"
                  className={userLiked === true ? "bg-primary/10 text-primary" : ""}
                  onClick={() => handleRating(true)}
                >
                  <ThumbsUp className="h-4 w-4 mr-1" />
                  {video.likes.toLocaleString()}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  className={userLiked === false ? "bg-primary/10 text-primary" : ""}
                  onClick={() => handleRating(false)}
                >
                  <ThumbsDown className="h-4 w-4 mr-1" />
                  {video.dislikes.toLocaleString()}
                </Button>
                <Button variant="outline" size="sm">
                  <Share2 className="h-4 w-4 mr-1" />
                  Share
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleReport}
                >
                  <Flag className="h-4 w-4 mr-1" />
                  Report
                </Button>
              </div>
            </div>
          </div>
          
          {/* Channel Info */}
          <div className="flex items-center justify-between mt-6 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
            <div className="flex items-center">
              <Link href={`/channel/${channel?.id}`}>
                <Avatar className="h-12 w-12 mr-3">
                  <AvatarImage src={channelOwner?.avatar || channel?.banner} alt={channel?.name} />
                  <AvatarFallback>{channel?.name?.[0]?.toUpperCase() || "C"}</AvatarFallback>
                </Avatar>
              </Link>
              <div>
                <Link href={`/channel/${channel?.id}`}>
                  <h3 className="font-bold hover:text-primary transition-colors duration-200">
                    {channel?.name || "Unknown Channel"}
                    {channelOwner?.isVerified && (
                      <span className="ml-1 text-blue-500">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </span>
                    )}
                  </h3>
                </Link>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {channel?.subscriberCount?.toLocaleString() || 0} subscribers
                </p>
              </div>
            </div>
            <Button 
              onClick={handleSubscribe}
              className="bg-primary hover:bg-accent text-white"
            >
              Subscribe
            </Button>
          </div>
          
          {/* Description */}
          <div className="mt-6 bg-gray-100 dark:bg-gray-800 rounded-lg p-4">
            <div className="text-sm whitespace-pre-line">
              {video.description || "No description provided."}
            </div>
            
            {/* Tags */}
            {video.tags && video.tags.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2">
                {video.tags.map((tag, index) => (
                  <span 
                    key={index} 
                    className="bg-gray-200 dark:bg-gray-700 text-xs px-2 py-1 rounded"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
          
          {/* Comments Section */}
          <div className="mt-8">
            <Tabs defaultValue="comments">
              <TabsList>
                <TabsTrigger value="comments">Comments ({comments.length})</TabsTrigger>
                <TabsTrigger value="related">Related</TabsTrigger>
              </TabsList>
              
              <TabsContent value="comments" className="mt-4">
                {/* Comment Form */}
                {user ? (
                  <form onSubmit={handleCommentSubmit} className="mb-6">
                    <div className="flex gap-4">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={user.avatar} alt={user.username} />
                        <AvatarFallback>{user.username[0].toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <Textarea
                          placeholder="Add a comment..."
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                          className="w-full mb-2"
                          rows={3}
                        />
                        <div className="flex justify-end">
                          <Button
                            type="submit"
                            className="bg-primary hover:bg-accent text-white"
                            disabled={isSubmittingComment || commentMutation.isPending}
                          >
                            {isSubmittingComment || commentMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Posting...
                              </>
                            ) : (
                              "Post Comment"
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </form>
                ) : (
                  <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4 mb-6 text-center">
                    <p className="mb-2">Sign in to comment on this video</p>
                    <Link href="/auth">
                      <Button className="bg-primary hover:bg-accent text-white">
                        Sign In
                      </Button>
                    </Link>
                  </div>
                )}
                
                {/* Comments List */}
                {comments.length > 0 ? (
                  <div className="space-y-6">
                    {comments.map((comment) => (
                      <div key={comment.id} className="flex gap-4">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={comment.user?.avatar} alt={comment.user?.username} />
                          <AvatarFallback>{comment.user?.username?.[0]?.toUpperCase() || "U"}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium">{comment.user?.username || "Unknown User"}</h4>
                            <span className="text-xs text-gray-500">
                              {formatDate(comment.createdAt)}
                            </span>
                          </div>
                          <p className="mt-1 text-sm">{comment.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <p>No comments yet. Be the first to comment!</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="related" className="mt-4 md:hidden">
                <div className="space-y-4">
                  {relatedVideos.filter(v => v.id !== video.id).slice(0, 4).map((relatedVideo) => (
                    <VideoCard 
                      key={relatedVideo.id} 
                      video={relatedVideo}
                    />
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        
        {/* Sidebar - Related Videos */}
        <div className="lg:w-4/12 hidden md:block">
          <h3 className="text-xl font-bold mb-4">Related Videos</h3>
          <div className="space-y-4">
            {relatedVideos.filter(v => v.id !== video.id).map((relatedVideo) => (
              <VideoCard 
                key={relatedVideo.id} 
                video={relatedVideo}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
