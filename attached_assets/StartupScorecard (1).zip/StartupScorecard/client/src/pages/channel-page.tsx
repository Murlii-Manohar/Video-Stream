import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Channel, Video, User } from "@shared/schema";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { VideoCard } from "@/components/ui/video-card";
import { Badge } from "@/components/ui/badge";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, Users, Calendar, Play, ThumbsUp, Clock, Video as VideoIcon } from "lucide-react";
import { AbstractBg4 } from "@/assets/svg/abstract-bg-4";

export default function ChannelPage() {
  const { id } = useParams<{ id: string }>();
  const channelId = parseInt(id);
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [subscriberCount, setSubscriberCount] = useState(0);
  
  // Fetch channel
  const { 
    data: channel, 
    isLoading: channelLoading, 
    error: channelError 
  } = useQuery<Channel>({
    queryKey: [`/api/channels/${channelId}`],
    queryFn: async () => {
      const res = await fetch(`/api/channels/${channelId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch channel');
      }
      return res.json();
    },
    enabled: !isNaN(channelId),
  });
  
  // Fetch channel owner
  const { data: channelOwner } = useQuery<User>({
    queryKey: ['/api/users', channel?.userId],
    queryFn: async () => {
      const res = await fetch(`/api/users/${channel?.userId}`);
      if (!res.ok) {
        throw new Error('Failed to fetch channel owner');
      }
      return res.json();
    },
    enabled: !!channel?.userId,
  });
  
  // Fetch channel videos
  const { 
    data: channelVideos = [], 
    isLoading: videosLoading 
  } = useQuery<Video[]>({
    queryKey: [`/api/channels/${channelId}/videos`],
    queryFn: async () => {
      const res = await fetch(`/api/channels/${channelId}/videos`);
      if (!res.ok) {
        throw new Error('Failed to fetch channel videos');
      }
      return res.json();
    },
    enabled: !isNaN(channelId),
  });
  
  // Check subscription status
  useQuery({
    queryKey: [`/api/channels/${channelId}/subscription-status`],
    queryFn: async () => {
      if (!user) return { isSubscribed: false };
      
      try {
        const res = await fetch(`/api/channels/${channelId}/subscription-status?userId=${user.id}`);
        if (!res.ok) {
          throw new Error('Failed to check subscription status');
        }
        const data = await res.json();
        setIsSubscribed(data.isSubscribed);
        return data;
      } catch (error) {
        console.error('Failed to check subscription status:', error);
        return { isSubscribed: false };
      }
    },
    enabled: !!user && !isNaN(channelId),
  });
  
  // Set subscriber count from channel data
  useState(() => {
    if (channel) {
      setSubscriberCount(channel.subscriberCount || 0);
    }
  });
  
  // Subscribe mutation
  const subscribeMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", `/api/channels/${channelId}/subscribe`);
    },
    onSuccess: (data) => {
      setIsSubscribed(true);
      setSubscriberCount(data.subscriberCount);
      toast({
        title: "Subscribed!",
        description: `You're now subscribed to ${channel?.name}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/subscriptions"] });
    },
    onError: (error) => {
      toast({
        title: "Subscription failed",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Unsubscribe mutation
  const unsubscribeMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", `/api/channels/${channelId}/subscribe`);
    },
    onSuccess: (data) => {
      setIsSubscribed(false);
      setSubscriberCount(data.subscriberCount);
      toast({
        title: "Unsubscribed",
        description: `You've unsubscribed from ${channel?.name}`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/user/subscriptions"] });
    },
    onError: (error) => {
      toast({
        title: "Unsubscription failed",
        description: error.message || "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Handle subscribe/unsubscribe
  const handleSubscription = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to subscribe to channels",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubscribing(true);
    
    try {
      if (isSubscribed) {
        await unsubscribeMutation.mutateAsync();
      } else {
        await subscribeMutation.mutateAsync();
      }
    } finally {
      setIsSubscribing(false);
    }
  };
  
  // Calculate channel stats
  const totalViews = channelVideos.reduce((sum, video) => sum + video.views, 0);
  const totalLikes = channelVideos.reduce((sum, video) => sum + video.likes, 0);
  
  // Format numbers for display
  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    } else {
      return num.toString();
    }
  };
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };
  
  // Loading state
  if (channelLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
      </div>
    );
  }
  
  // Error state
  if (channelError || !channel) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h2 className="text-2xl font-bold mb-4">Channel Not Found</h2>
        <p className="mb-6">The channel you're looking for may have been removed or doesn't exist.</p>
        <Link href="/">
          <Button className="bg-primary hover:bg-accent text-white">
            Return to Home
          </Button>
        </Link>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-6">
      {/* Banner area */}
      <div className="relative rounded-lg overflow-hidden bg-gray-800 h-40 md:h-56 lg:h-64 mb-6">
        {channel.banner ? (
          <img 
            src={channel.banner} 
            alt={`${channel.name} banner`} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="absolute inset-0 overflow-hidden opacity-40">
            <AbstractBg4 />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
      </div>
      
      {/* Channel info */}
      <div className="flex flex-col md:flex-row items-start md:items-center gap-6 mb-8">
        <Avatar className="w-24 h-24 border-4 border-background shadow-lg -mt-12 z-10">
          <AvatarImage 
            src={channelOwner?.avatar || channel.banner} 
            alt={channel.name} 
          />
          <AvatarFallback className="text-2xl bg-primary/20 text-primary">
            {channel.name.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        
        <div className="flex-1">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-3xl font-bold">{channel.name}</h1>
                {channelOwner?.isVerified && (
                  <Badge variant="secondary" className="bg-blue-500 text-white">
                    Verified
                  </Badge>
                )}
              </div>
              <p className="text-gray-600 dark:text-gray-400 mt-1">
                {formatNumber(subscriberCount)} subscribers
              </p>
            </div>
            
            <Button
              onClick={handleSubscription}
              disabled={isSubscribing}
              variant={isSubscribed ? "outline" : "default"}
              className={isSubscribed ? "border-primary text-primary hover:bg-primary/10" : "bg-primary hover:bg-accent"}
            >
              {isSubscribing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                isSubscribed ? "Subscribed" : "Subscribe"
              )}
            </Button>
          </div>
          
          <div className="flex flex-wrap gap-6 mt-4">
            <div className="flex items-center">
              <VideoIcon className="text-primary mr-2 h-5 w-5" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Videos</p>
                <p className="font-bold">{channelVideos.length}</p>
              </div>
            </div>
            <div className="flex items-center">
              <Play className="text-primary mr-2 h-5 w-5" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Views</p>
                <p className="font-bold">{formatNumber(totalViews)}</p>
              </div>
            </div>
            <div className="flex items-center">
              <ThumbsUp className="text-primary mr-2 h-5 w-5" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Likes</p>
                <p className="font-bold">{formatNumber(totalLikes)}</p>
              </div>
            </div>
            <div className="flex items-center">
              <Calendar className="text-primary mr-2 h-5 w-5" />
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Joined</p>
                <p className="font-bold">{formatDate(channel.createdAt)}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Channel description */}
      {channel.description && (
        <div className="bg-gray-100 dark:bg-gray-800 rounded-lg p-4 mb-8">
          <p className="whitespace-pre-line">{channel.description}</p>
        </div>
      )}
      
      {/* Channel content tabs */}
      <Tabs defaultValue="videos" className="mt-6">
        <TabsList>
          <TabsTrigger value="videos">Videos</TabsTrigger>
          <TabsTrigger value="quickies">Quickies</TabsTrigger>
          <TabsTrigger value="about">About</TabsTrigger>
        </TabsList>
        
        <TabsContent value="videos" className="pt-6">
          {videosLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : channelVideos.filter(v => !v.isQuickie).length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {channelVideos
                .filter(video => !video.isQuickie)
                .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                .map(video => (
                  <VideoCard 
                    key={video.id} 
                    video={video} 
                    channel={channel}
                    channelOwner={channelOwner}
                  />
                ))
              }
            </div>
          ) : (
            <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <VideoIcon className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">No videos yet</h3>
              <p className="text-gray-600 dark:text-gray-400">
                This channel hasn't uploaded any videos yet
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="quickies" className="pt-6">
          {videosLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : channelVideos.filter(v => v.isQuickie).length > 0 ? (
            <div className="flex overflow-x-auto space-x-4 pb-4 custom-scrollbar">
              {channelVideos
                .filter(video => video.isQuickie)
                .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                .map(video => (
                  <div key={video.id} className="flex-shrink-0 w-40">
                    <Link href={`/video/${video.id}`}>
                      <div className="relative rounded-lg overflow-hidden aspect-[9/16] bg-gray-800 mb-2 hover:shadow-md transition duration-300">
                        {video.thumbnail ? (
                          <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                            <span className="text-white text-xs opacity-70">No Thumbnail</span>
                          </div>
                        )}
                        {video.duration > 0 && (
                          <div className="video-duration">{`${Math.floor(video.duration / 60)}:${(video.duration % 60).toString().padStart(2, '0')}`}</div>
                        )}
                      </div>
                    </Link>
                    <Link href={`/video/${video.id}`}>
                      <h3 className="text-sm font-medium line-clamp-2 hover:text-primary transition-colors duration-300">
                        {video.title}
                      </h3>
                    </Link>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{formatNumber(video.views)} views</p>
                  </div>
                ))
              }
            </div>
          ) : (
            <div className="text-center py-16 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <Clock className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-xl font-bold mb-2">No quickies yet</h3>
              <p className="text-gray-600 dark:text-gray-400">
                This channel hasn't uploaded any quickies yet
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="about" className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-3">Description</h3>
                <p className="whitespace-pre-line">
                  {channel.description || "This channel has no description."}
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-3">Stats</h3>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-primary" />
                    <span>Joined {formatDate(channel.createdAt)}</span>
                  </li>
                  <li className="flex items-center">
                    <VideoIcon className="h-5 w-5 mr-2 text-primary" />
                    <span>{channelVideos.length} videos</span>
                  </li>
                  <li className="flex items-center">
                    <Play className="h-5 w-5 mr-2 text-primary" />
                    <span>{formatNumber(totalViews)} views</span>
                  </li>
                  <li className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-primary" />
                    <span>{formatNumber(subscriberCount)} subscribers</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4">Top Videos</h3>
              <div className="space-y-4">
                {channelVideos
                  .sort((a, b) => b.views - a.views)
                  .slice(0, 5)
                  .map(video => (
                    <Link key={video.id} href={`/video/${video.id}`}>
                      <div className="flex items-center gap-3 p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors">
                        <div className="w-20 h-12 bg-gray-200 dark:bg-gray-700 rounded overflow-hidden flex-shrink-0">
                          {video.thumbnail ? (
                            <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-500">
                              <VideoIcon className="h-6 w-6" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm line-clamp-2">{video.title}</h4>
                          <p className="text-xs text-gray-500 dark:text-gray-400">{formatNumber(video.views)} views</p>
                        </div>
                      </div>
                    </Link>
                  ))
                }
                
                {channelVideos.length === 0 && (
                  <p className="text-center text-gray-500 dark:text-gray-400 py-4">
                    No videos found
                  </p>
                )}
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
