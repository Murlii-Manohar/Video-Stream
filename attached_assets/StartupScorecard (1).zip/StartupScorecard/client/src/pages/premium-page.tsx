import { useQuery } from "@tanstack/react-query";
import { Video } from "@shared/schema";
import { VideoCard } from "@/components/ui/video-card";
import { Loader2, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

export default function PremiumPage() {
  const { user } = useAuth();
  const isPremium = user?.isPremium || false;
  
  const { data: videos, isLoading, error } = useQuery<Video[]>({
    queryKey: ["/api/videos/premium"],
    enabled: isPremium, // Only fetch premium videos if user is premium
  });

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Premium Content</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">Please sign in to access premium content.</p>
          <Link href="/auth">
            <Button className="w-full">Sign In</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (!isPremium) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 text-center">
          <Star className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Upgrade to Premium</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            Get access to exclusive content, ad-free viewing, and more with XPlayHD Premium.
          </p>
          <Button className="w-full">Upgrade Now</Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-6rem)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <h2 className="text-2xl font-bold mb-4 dark:text-white">Error Loading Premium Videos</h2>
        <p className="text-gray-600 dark:text-gray-300">{error.message}</p>
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <h2 className="text-2xl font-bold mb-4 dark:text-white">No Premium Videos Found</h2>
        <p className="text-gray-600 dark:text-gray-300">Check back soon for exclusive premium content.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-8">
        <Star className="h-8 w-8 text-yellow-500 mr-3" />
        <h1 className="text-3xl font-bold dark:text-white">Premium Videos</h1>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {videos.map((video) => (
          <VideoCard key={video.id} video={video} />
        ))}
      </div>
    </div>
  );
}