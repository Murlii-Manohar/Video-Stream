import { useQuery } from "@tanstack/react-query";
import { Video } from "@shared/schema";
import { VideoCard } from "@/components/ui/video-card";
import { Loader2, History, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useState } from "react";

export default function HistoryPage() {
  const { user } = useAuth();
  const [clearSuccess, setClearSuccess] = useState(false);
  
  const { data: videos, isLoading, error } = useQuery<Video[]>({
    queryKey: ["/api/user/history"],
    enabled: !!user, // Only fetch if user is logged in
  });

  const clearHistoryMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/user/history/clear");
      return res.json();
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user/history"], []);
      setClearSuccess(true);
      setTimeout(() => setClearSuccess(false), 3000);
    },
  });

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-lg shadow-lg p-8 text-center">
          <h2 className="text-2xl font-bold mb-4 dark:text-white">Watch History</h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">Please sign in to view your watch history.</p>
          <Link href="/auth">
            <Button className="w-full">Sign In</Button>
          </Link>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-6rem)]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <h2 className="text-2xl font-bold mb-4 dark:text-white">Error Loading History</h2>
        <p className="text-gray-600 dark:text-gray-300">{error.message}</p>
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-6rem)]">
        <History className="h-16 w-16 text-gray-400 mb-4" />
        <h2 className="text-2xl font-bold mb-4 dark:text-white">No Watch History</h2>
        <p className="text-gray-600 dark:text-gray-300 mb-6">Videos you watch will appear here.</p>
        <Link href="/">
          <Button>Discover Videos</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center">
          <History className="h-7 w-7 mr-3 text-primary" />
          <h1 className="text-3xl font-bold dark:text-white">Watch History</h1>
        </div>
        <Button 
          variant="outline" 
          onClick={() => clearHistoryMutation.mutate()}
          disabled={clearHistoryMutation.isPending}
        >
          <Trash2 className="h-4 w-4 mr-2" />
          Clear History
        </Button>
      </div>

      {clearSuccess && (
        <Alert className="mb-6">
          <AlertTitle>Success!</AlertTitle>
          <AlertDescription>
            Your watch history has been cleared.
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {videos.map((video) => (
          <VideoCard key={video.id} video={video} />
        ))}
      </div>
    </div>
  );
}