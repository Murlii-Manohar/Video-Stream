import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { VideoCard } from "@/components/ui/video-card";
import { ChannelCard } from "@/components/ui/channel-card";
import { CategoryCard } from "@/components/ui/category-card";
import { AgeVerificationModal } from "@/components/ui/age-verification-modal";
import { useAuth } from "@/hooks/use-auth";
import { Video, Channel } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export default function HomePage() {
  const { user, verifyAgeMutation } = useAuth();
  const { toast } = useToast();
  const [ageModalOpen, setAgeModalOpen] = useState(false);
  
  // Check if user needs age verification
  useEffect(() => {
    // Only show the modal if:
    // 1. User is logged in
    // 2. User is not verified
    // 3. We haven't already shown the modal (use localStorage)
    const hasSeenModal = localStorage.getItem('ageModalSeen') === 'true';
    
    if (user && !user.isVerified && !hasSeenModal) {
      setAgeModalOpen(true);
      localStorage.setItem('ageModalSeen', 'true');
    }
  }, [user]);
  
  // Fetch featured video
  const { data: featuredVideo } = useQuery<Video>({
    queryKey: ['/api/videos/featured'],
    queryFn: async () => {
      try {
        const res = await fetch('/api/videos/trending?limit=1');
        const data = await res.json();
        return data[0]; // Return the first trending video as featured
      } catch (error) {
        throw new Error('Failed to fetch featured video');
      }
    },
  });
  
  // Fetch quickies
  const { data: quickies = [] } = useQuery<Video[]>({
    queryKey: ['/api/videos/quickies'],
    queryFn: async () => {
      const res = await fetch('/api/videos/quickies?limit=5');
      if (!res.ok) {
        throw new Error('Failed to fetch quickies');
      }
      return res.json();
    },
  });
  
  // Fetch trending videos
  const { data: trendingVideos = [] } = useQuery<Video[]>({
    queryKey: ['/api/videos/trending'],
    queryFn: async () => {
      const res = await fetch('/api/videos/trending?limit=4');
      if (!res.ok) {
        throw new Error('Failed to fetch trending videos');
      }
      return res.json();
    },
  });
  
  // Fetch recommended channels
  const { data: recommendedChannels = [] } = useQuery<Channel[]>({
    queryKey: ['/api/channels'],
    queryFn: async () => {
      const res = await fetch('/api/channels?limit=6');
      if (!res.ok) {
        throw new Error('Failed to fetch recommended channels');
      }
      return res.json();
    },
  });
  
  // Handle age verification
  const handleAgeVerification = () => {
    if (user) {
      verifyAgeMutation.mutate();
    }
    setAgeModalOpen(false);
  };
  
  // Handle age verification rejection
  const handleAgeVerificationRejection = () => {
    toast({
      title: "Age Verification Required",
      description: "You must verify your age to access all content on XPlayHD",
      variant: "destructive",
    });
    setAgeModalOpen(false);
  };
  
  return (
    <div className="px-4 py-6">
      {/* Age Verification Notice - only show for non-verified users */}
      {user && !user.isVerified && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6 flex items-start justify-between">
          <div className="flex items-center">
            <AlertCircle className="mr-2 h-5 w-5" />
            <div>
              <p className="font-bold">Age Verification Required</p>
              <p className="text-sm">This website contains adult content and is only for users 18+. Verify your age to continue.</p>
            </div>
          </div>
          <Button 
            className="bg-red-700 text-white hover:bg-red-800 transition duration-300"
            onClick={() => setAgeModalOpen(true)}
          >
            Verify Now
          </Button>
        </div>
      )}
      
      {/* Home Featured Video */}
      <section className="mb-10">
        <h2 className="text-2xl font-bold font-montserrat mb-4">Featured Video</h2>
        {featuredVideo ? (
          <div className="video-container relative rounded-lg overflow-hidden bg-gray-800 aspect-video">
            {featuredVideo.thumbnail ? (
              <img 
                src={featuredVideo.thumbnail} 
                alt={featuredVideo.title} 
                className="w-full h-full object-cover" 
              />
            ) : (
              <div className="w-full h-full bg-gray-800 flex items-center justify-center">
                <span className="text-white text-xl opacity-70">No Thumbnail</span>
              </div>
            )}
            <div className="absolute inset-0 flex items-center justify-center">
              <Link href={`/video/${featuredVideo.id}`}>
                <Button 
                  className="bg-primary/80 hover:bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center transition duration-300"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </Button>
              </Link>
            </div>
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 text-white">
              <h3 className="text-xl font-bold mb-1">{featuredVideo.title}</h3>
              <p className="text-sm opacity-80">{(featuredVideo.views || 0).toLocaleString()} views</p>
            </div>
          </div>
        ) : (
          <div className="w-full aspect-video bg-gray-800 rounded-lg flex items-center justify-center">
            <p className="text-white">Loading featured video...</p>
          </div>
        )}
      </section>
      
      {/* Quickies Section */}
      <section className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold font-montserrat">
            Quickies 
            <span className="text-xs bg-primary text-white px-2 py-1 rounded-full ml-2">HOT</span>
          </h2>
          <Link href="/quickies">
            <Button variant="link" className="text-primary hover:underline">
              See All
            </Button>
          </Link>
        </div>
        <div className="flex overflow-x-auto space-x-4 pb-4 custom-scrollbar">
          {quickies.length > 0 ? (
            quickies.map(video => (
              <div key={video.id} className="flex-shrink-0 w-40">
                <VideoCard 
                  video={video} 
                  isQuickie={true}
                />
              </div>
            ))
          ) : (
            <div className="flex-1 py-8 text-center text-gray-500">
              <p>No quickies found</p>
            </div>
          )}
        </div>
      </section>
      
      {/* Trending Videos */}
      <section className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold font-montserrat">Trending Now</h2>
          <Button variant="link" className="text-primary hover:underline">
            See All
          </Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {trendingVideos.length > 0 ? (
            trendingVideos.map(video => (
              <VideoCard key={video.id} video={video} />
            ))
          ) : (
            <div className="col-span-full py-8 text-center text-gray-500">
              <p>No trending videos found</p>
            </div>
          )}
        </div>
      </section>
      
      {/* Recommended Channels */}
      <section className="mb-10">
        <h2 className="text-2xl font-bold font-montserrat mb-4">Recommended Channels</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {recommendedChannels.length > 0 ? (
            recommendedChannels.map(channel => (
              <ChannelCard key={channel.id} channel={channel} />
            ))
          ) : (
            <div className="col-span-full py-8 text-center text-gray-500">
              <p>No recommended channels found</p>
            </div>
          )}
        </div>
      </section>
      
      {/* Popular Categories */}
      <section className="mb-10">
        <h2 className="text-2xl font-bold font-montserrat mb-4">Popular Categories</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <CategoryCard 
            title="Amateur" 
            image="https://images.pexels.com/photos/3760619/pexels-photo-3760619.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
            link="/category/amateur"
          />
          <CategoryCard 
            title="Couple" 
            image="https://images.pexels.com/photos/6685183/pexels-photo-6685183.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
            link="/category/couple"
          />
          <CategoryCard 
            title="Professional" 
            image="https://images.pexels.com/photos/6153719/pexels-photo-6153719.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
            link="/category/professional"
          />
          <CategoryCard 
            title="Solo" 
            image="https://images.pexels.com/photos/6438740/pexels-photo-6438740.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
            link="/category/solo"
          />
          <CategoryCard 
            title="Lingerie" 
            image="https://images.pexels.com/photos/4058229/pexels-photo-4058229.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
            link="/category/lingerie"
          />
          <CategoryCard 
            title="Verified" 
            image="https://images.pexels.com/photos/6003086/pexels-photo-6003086.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
            link="/category/verified"
          />
        </div>
      </section>
      
      {/* Age Verification Modal */}
      <AgeVerificationModal
        open={ageModalOpen}
        onOpenChange={setAgeModalOpen}
        onAccept={handleAgeVerification}
        onReject={handleAgeVerificationRejection}
      />
    </div>
  );
}
