import { Link, useLocation } from "wouter";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { UploadModal } from "@/components/ui/upload-modal";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Search, Upload, Menu, ChevronDown, User, LayoutDashboard, Settings, LogOut,
  Home, Star, Clock, Award, History, Heart, Bookmark
} from "lucide-react";

export function Header() {
  const [, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileSearchVisible, setMobileSearchVisible] = useState(false);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  
  // Handle logout
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Handle search submission
  const handleSearch = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const searchQuery = new FormData(form).get("search") as string;
    
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
      // Close mobile search on submit
      setMobileSearchVisible(false);
    }
  };
  
  return (
    <header className="bg-white dark:bg-secondary shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center">
          <Link href="/" className="text-2xl font-bold font-montserrat text-primary">
            XPlay<span className="text-secondary dark:text-white">HD</span>
          </Link>
        </div>
        
        {/* Mobile Search Toggle */}
        {mobileSearchVisible ? (
          <form onSubmit={handleSearch} className="flex-1 mx-2 md:hidden">
            <div className="relative w-full">
              <Input
                type="search"
                name="search"
                placeholder="Search videos..."
                className="w-full pr-8"
                autoFocus
              />
              <Button 
                type="submit"
                variant="ghost"
                size="icon"
                className="absolute right-0 top-0 h-full"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </form>
        ) : null}
        
        {/* Desktop Search */}
        <form onSubmit={handleSearch} className="hidden md:flex flex-1 mx-10">
          <div className="relative w-full max-w-xl mx-auto">
            <Input
              type="search"
              name="search"
              placeholder="Search videos..."
              className="w-full pr-8"
            />
            <Button 
              type="submit"
              variant="ghost"
              size="icon"
              className="absolute right-0 top-0 h-full"
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </form>
        
        {/* Navigation Links */}
        <div className="flex items-center space-x-4">
          {/* Mobile Search Button */}
          {!mobileSearchVisible && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden"
              onClick={() => setMobileSearchVisible(true)}
            >
              <Search className="h-5 w-5" />
            </Button>
          )}
          
          {/* Upload Button */}
          {user && (
            <Button
              variant="ghost"
              size="icon"
              className="hidden md:flex"
              onClick={() => setUploadModalOpen(true)}
              title="Upload Video"
            >
              <Upload className="h-5 w-5" />
            </Button>
          )}
          
          {/* Theme Toggle */}
          <ThemeToggle />
          
          {/* User Menu */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <div className="flex items-center space-x-1 cursor-pointer">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user.avatar} alt={user.username} />
                    <AvatarFallback>{user.username.charAt(0).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <ChevronDown className="h-4 w-4 text-secondary dark:text-lightBg" />
                </div>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="font-medium">{user.username}</p>
                    <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem onClick={() => navigate("/channel")}>
                    <User className="mr-2 h-4 w-4" />
                    <span>Your Channel</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/dashboard")}>
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    <span>Dashboard</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/settings")}>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sign Out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button 
              className="hidden md:block bg-primary hover:bg-accent text-white"
              onClick={() => navigate("/auth")}
            >
              Sign In
            </Button>
          )}
          
          {/* Mobile Menu Button */}
          <Sheet>
            <SheetTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="md:hidden"
              >
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[380px]">
              <SheetHeader className="mb-5">
                <SheetTitle>
                  <Link href="/" className="text-2xl font-bold font-montserrat text-primary">
                    XPlay<span className="text-secondary dark:text-white">HD</span>
                  </Link>
                </SheetTitle>
              </SheetHeader>
              
              <div className="flex flex-col space-y-4">
                {/* Menu Items */}
                <div className="space-y-3">
                  <h3 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground mb-2">Menu</h3>
                  
                  <SheetClose asChild>
                    <Link href="/" className="flex items-center space-x-3 hover:bg-accent hover:text-accent-foreground rounded-md px-3 py-2 transition duration-200">
                      <Home className="h-5 w-5" />
                      <span>Trending</span>
                    </Link>
                  </SheetClose>
                  
                  <SheetClose asChild>
                    <Link href="/popular" className="flex items-center space-x-3 hover:bg-accent hover:text-accent-foreground rounded-md px-3 py-2 transition duration-200">
                      <Star className="h-5 w-5" />
                      <span>Popular</span>
                    </Link>
                  </SheetClose>
                  
                  <SheetClose asChild>
                    <Link href="/recent" className="flex items-center space-x-3 hover:bg-accent hover:text-accent-foreground rounded-md px-3 py-2 transition duration-200">
                      <Clock className="h-5 w-5" />
                      <span>Recent</span>
                    </Link>
                  </SheetClose>
                  
                  <SheetClose asChild>
                    <Link href="/premium" className="flex items-center space-x-3 hover:bg-accent hover:text-accent-foreground rounded-md px-3 py-2 transition duration-200">
                      <Award className="h-5 w-5" />
                      <span>Premium</span>
                    </Link>
                  </SheetClose>
                  
                  <SheetClose asChild>
                    <Link href="/quickies" className="flex items-center space-x-3 hover:bg-accent hover:text-accent-foreground rounded-md px-3 py-2 transition duration-200">
                      <span className="rounded-full bg-red-500 text-white text-xs px-1.5 py-0.5">
                        Q
                      </span>
                      <span>Quickies</span>
                      <span className="ml-2 text-xs bg-primary text-white px-1.5 py-0.5 rounded-full">HOT</span>
                    </Link>
                  </SheetClose>
                </div>
                
                {/* Your Content (only show if logged in) */}
                {user && (
                  <div className="space-y-3">
                    <h3 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground mb-2">Your Content</h3>
                    
                    <SheetClose asChild>
                      <Link href="/history" className="flex items-center space-x-3 hover:bg-accent hover:text-accent-foreground rounded-md px-3 py-2 transition duration-200">
                        <History className="h-5 w-5" />
                        <span>History</span>
                      </Link>
                    </SheetClose>
                    
                    <SheetClose asChild>
                      <Link href="/liked" className="flex items-center space-x-3 hover:bg-accent hover:text-accent-foreground rounded-md px-3 py-2 transition duration-200">
                        <Heart className="h-5 w-5" />
                        <span>Liked Videos</span>
                      </Link>
                    </SheetClose>
                    
                    <SheetClose asChild>
                      <Link href="/saved" className="flex items-center space-x-3 hover:bg-accent hover:text-accent-foreground rounded-md px-3 py-2 transition duration-200">
                        <Bookmark className="h-5 w-5" />
                        <span>Saved</span>
                      </Link>
                    </SheetClose>
                  </div>
                )}
                
                {/* Sign In Button (only show if not logged in) */}
                {!user && (
                  <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                    <p className="text-sm mb-4 dark:text-white">Sign in to like videos, comment, and subscribe.</p>
                    <SheetClose asChild>
                      <Link href="/auth">
                        <Button className="w-full bg-primary hover:bg-accent text-white">
                          Sign In
                        </Button>
                      </Link>
                    </SheetClose>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
      
      <UploadModal
        open={uploadModalOpen}
        onOpenChange={setUploadModalOpen}
      />
    </header>
  );
}
