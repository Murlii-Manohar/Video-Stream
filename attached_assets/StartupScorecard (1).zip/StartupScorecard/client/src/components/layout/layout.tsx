import { ReactNode } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { Footer } from "@/components/layout/footer";
import { useLocation } from "wouter";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  
  // Skip layout for auth page
  if (location === "/auth") {
    return <>{children}</>;
  }
  
  return (
    <div className="min-h-screen flex flex-col transition-colors duration-300 bg-lightBg dark:bg-darkBg text-secondary dark:text-lightBg">
      <Header />
      <div className="flex flex-col md:flex-row flex-1">
        <Sidebar />
        <main className="flex-1">
          {children}
        </main>
      </div>
      <Footer />
    </div>
  );
}

export default Layout;
