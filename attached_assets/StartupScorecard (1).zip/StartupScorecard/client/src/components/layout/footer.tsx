import { Link } from "wouter";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTwitter, faInstagram, faTelegram, faDiscord } from '@fortawesome/free-brands-svg-icons';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function Footer() {
  return (
    <footer className="bg-secondary text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold font-montserrat mb-4">XPlay<span className="text-primary">HD</span></h3>
            <p className="text-gray-300 text-sm">The premier adult video streaming platform. All models are 18 years or older.</p>
          </div>
          <div>
            <h4 className="font-bold mb-4">Information</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><Link href="/about"><a className="hover:text-primary">About Us</a></Link></li>
              <li><Link href="/terms"><a className="hover:text-primary">Terms of Service</a></Link></li>
              <li><Link href="/privacy"><a className="hover:text-primary">Privacy Policy</a></Link></li>
              <li><Link href="/dmca"><a className="hover:text-primary">DMCA</a></Link></li>
              <li><Link href="/2257"><a className="hover:text-primary">2257 Statement</a></Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Help & Support</h4>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><Link href="/faq"><a className="hover:text-primary">FAQ</a></Link></li>
              <li><Link href="/contact"><a className="hover:text-primary">Contact Us</a></Link></li>
              <li><Link href="/content-removal"><a className="hover:text-primary">Content Removal</a></Link></li>
              <li><Link href="/advertise"><a className="hover:text-primary">Advertise With Us</a></Link></li>
              <li><Link href="/become-model"><a className="hover:text-primary">Become a Model</a></Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4">Stay Connected</h4>
            <div className="flex space-x-4 mb-4">
              <a href="#" className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center hover:bg-primary transition duration-300">
                <FontAwesomeIcon icon={faTwitter} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center hover:bg-primary transition duration-300">
                <FontAwesomeIcon icon={faInstagram} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center hover:bg-primary transition duration-300">
                <FontAwesomeIcon icon={faTelegram} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center hover:bg-primary transition duration-300">
                <FontAwesomeIcon icon={faDiscord} />
              </a>
            </div>
            <p className="text-gray-300 text-sm">Subscribe to our newsletter for updates</p>
            <form className="mt-2 flex">
              <Input
                type="email"
                placeholder="Your email"
                className="px-4 py-2 text-sm bg-gray-700 text-white rounded-l-lg focus:outline-none focus:ring-1 focus:ring-primary border-0"
              />
              <Button
                type="submit"
                className="bg-primary hover:bg-accent text-white px-4 py-2 text-sm rounded-r-lg transition duration-300"
              >
                Subscribe
              </Button>
            </form>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-400">
          <p>© {new Date().getFullYear()} XPlayHD. All rights reserved. All models were 18 years of age or older at the time of depiction.</p>
          <div className="mt-4 flex justify-center space-x-4">
            <div className="h-8 bg-gray-700 rounded px-2 py-1 flex items-center justify-center">RTA Label</div>
            <div className="h-8 bg-gray-700 rounded px-2 py-1 flex items-center justify-center">18+ Label</div>
            <div className="h-8 bg-gray-700 rounded px-2 py-1 flex items-center justify-center">ASACP Label</div>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
