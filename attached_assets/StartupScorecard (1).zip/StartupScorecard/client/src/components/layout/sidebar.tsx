import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Channel } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Flame, Star, Clock, Award, History, Heart, Bookmark, Upload, ShieldAlert, Shield } from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  
  // Get user's subscriptions
  const { data: subscriptions = [] } = useQuery<Channel[]>({
    queryKey: ['/api/user/subscriptions'],
    enabled: !!user,
  });
  
  // Handle window resize for mobile detection
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  // Mobile categories
  if (isMobile) {
    return (
      <div className="md:hidden overflow-x-auto whitespace-nowrap px-4 py-3 flex space-x-3 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-secondary">
        <Link href="/">
          <span className={`px-3 py-1 ${location === '/' ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700'} rounded-full text-sm font-medium cursor-pointer`}>All</span>
        </Link>
        <Link href="/quickies">
          <span className={`px-3 py-1 ${location === '/quickies' ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700'} rounded-full text-sm font-medium cursor-pointer flex items-center`}>
            Quickies <span className="ml-1 text-xs bg-red-500 text-white px-1 py-0.5 rounded-full">HOT</span>
          </span>
        </Link>
        <Link href="/category/amateur">
          <span className={`px-3 py-1 ${location === '/category/amateur' ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700'} rounded-full text-sm font-medium cursor-pointer`}>Amateur</span>
        </Link>
        <Link href="/category/professional">
          <span className={`px-3 py-1 ${location === '/category/professional' ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700'} rounded-full text-sm font-medium cursor-pointer`}>Professional</span>
        </Link>
        <Link href="/category/teen">
          <span className={`px-3 py-1 ${location === '/category/teen' ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700'} rounded-full text-sm font-medium cursor-pointer`}>Teen</span>
        </Link>
        <Link href="/category/milf">
          <span className={`px-3 py-1 ${location === '/category/milf' ? 'bg-primary text-white' : 'bg-gray-200 dark:bg-gray-700'} rounded-full text-sm font-medium cursor-pointer`}>MILF</span>
        </Link>
        <Link href="/channels">
          <span className="px-3 py-1 bg-gray-200 dark:bg-gray-700 rounded-full text-sm font-medium cursor-pointer">Channels</span>
        </Link>
      </div>
    );
  }
  
  // Desktop sidebar
  return (
    <aside className="bg-sidebar dark:bg-sidebar w-64 min-h-screen sticky top-16 h-[calc(100vh-4rem)] shadow-md hidden md:block z-40 transition-all">
      <ScrollArea className="py-4 h-full custom-scrollbar">
        {/* Categories */}
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <h3 className="font-semibold text-lg mb-2 dark:text-white">Categories</h3>
          <ul className="space-y-2">
            <li>
              <Link href="/">
                <span className={`flex items-center cursor-pointer ${location === '/' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  <Flame className="mr-3 h-5 w-5" />
                  Trending
                </span>
              </Link>
            </li>
            <li>
              <Link href="/popular">
                <span className={`flex items-center cursor-pointer ${location === '/popular' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  <Star className="mr-3 h-5 w-5" />
                  Popular
                </span>
              </Link>
            </li>
            <li>
              <Link href="/recent">
                <span className={`flex items-center cursor-pointer ${location === '/recent' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  <Clock className="mr-3 h-5 w-5" />
                  Recent
                </span>
              </Link>
            </li>
            <li>
              <Link href="/premium">
                <span className={`flex items-center cursor-pointer ${location === '/premium' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  <Award className="mr-3 h-5 w-5" />
                  Premium
                </span>
              </Link>
            </li>
            <li>
              <Link href="/quickies">
                <span className={`flex items-center cursor-pointer ${location === '/quickies' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  <span className="rounded-full bg-red-500 text-white text-xs px-1.5 py-0.5 mr-3">
                    Q
                  </span>
                  Quickies
                  <span className="ml-2 text-xs bg-primary text-white px-1.5 py-0.5 rounded-full">HOT</span>
                </span>
              </Link>
            </li>
            <li>
              <Link href="/category/amateur">
                <span className={`flex items-center cursor-pointer ${location === '/category/amateur' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  Amateur
                </span>
              </Link>
            </li>
            <li>
              <Link href="/category/professional">
                <span className={`flex items-center cursor-pointer ${location === '/category/professional' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  Professional
                </span>
              </Link>
            </li>
            <li>
              <Link href="/category/teen">
                <span className={`flex items-center cursor-pointer ${location === '/category/teen' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  Teen
                </span>
              </Link>
            </li>
            <li>
              <Link href="/category/milf">
                <span className={`flex items-center cursor-pointer ${location === '/category/milf' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                  MILF
                </span>
              </Link>
            </li>
          </ul>
        </div>
        
        {/* Your Content (only show if logged in) */}
        {user && (
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-lg mb-2 dark:text-white">Your Content</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/history">
                  <span className={`flex items-center cursor-pointer ${location === '/history' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                    <History className="mr-3 h-5 w-5" />
                    History
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/liked">
                  <span className={`flex items-center cursor-pointer ${location === '/liked' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                    <Heart className="mr-3 h-5 w-5" />
                    Liked Videos
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/saved">
                  <span className={`flex items-center cursor-pointer ${location === '/saved' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                    <Bookmark className="mr-3 h-5 w-5" />
                    Saved
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/dashboard">
                  <span className={`flex items-center cursor-pointer ${location === '/dashboard' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                    <Upload className="mr-3 h-5 w-5" />
                    Creator Dashboard
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/channel-dashboard">
                  <span className={`flex items-center cursor-pointer ${location === '/channel-dashboard' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                    <Star className="mr-3 h-5 w-5" />
                    Channel Dashboard
                  </span>
                </Link>
              </li>
            </ul>
          </div>
        )}
        
        {/* Admin Section (only show for admin users) */}
        {user && user.isAdmin && (
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-lg mb-2 dark:text-white">Administration</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/admin">
                  <span className={`flex items-center cursor-pointer ${location === '/admin' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                    <Shield className="mr-3 h-5 w-5" />
                    Admin Dashboard
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/moderation">
                  <span className={`flex items-center cursor-pointer ${location === '/moderation' ? 'text-primary font-medium' : 'hover:text-primary dark:text-white dark:hover:text-primary'}`}>
                    <ShieldAlert className="mr-3 h-5 w-5" />
                    Moderation Panel
                  </span>
                </Link>
              </li>
            </ul>
          </div>
        )}
        
        {/* Subscriptions (only show if logged in) */}
        {user && subscriptions.length > 0 && (
          <div className="px-6 py-4">
            <h3 className="font-semibold text-lg mb-2 dark:text-white">Subscriptions</h3>
            <ul className="space-y-3">
              {subscriptions.map(channel => (
                <li key={channel.id}>
                  <Link href={`/channel/${channel.id}`}>
                    <span className="flex items-center cursor-pointer hover:text-primary dark:text-white dark:hover:text-primary">
                      <Avatar className="h-6 w-6 mr-3">
                        <AvatarImage src={channel.banner} alt={channel.name} />
                        <AvatarFallback>{channel.name.charAt(0).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <span className="truncate">{channel.name}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
        
        {/* Sign In Button (only show if not logged in) */}
        {!user && (
          <div className="px-6 py-4 border-t border-gray-200 dark:border-gray-700">
            <p className="text-sm mb-4 dark:text-white">Sign in to like videos, comment, and subscribe.</p>
            <Link href="/auth">
              <Button className="w-full bg-primary hover:bg-accent text-white">
                Sign In
              </Button>
            </Link>
          </div>
        )}
      </ScrollArea>
    </aside>
  );
}
