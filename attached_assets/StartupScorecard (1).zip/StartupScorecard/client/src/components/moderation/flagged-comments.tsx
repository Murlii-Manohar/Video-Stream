import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { Comment } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, EyeOff, Eye, AlertTriangle } from "lucide-react";

export default function FlaggedComments() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedComment, setSelectedComment] = useState<Comment | null>(null);
  const [actionReason, setActionReason] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [moderationAction, setModerationAction] = useState<"hide" | "unhide">("hide");

  // Fetch flagged comments
  const {
    data: comments,
    isLoading,
    error,
  } = useQuery<Comment[]>({
    queryKey: ['/api/moderation/comments'],
    queryFn: getQueryFn(),
  });

  // Comment moderation mutation
  const moderationMutation = useMutation({
    mutationFn: async ({ commentId, action, reason }: { commentId: number, action: "hide" | "unhide", reason?: string }) => {
      const response = await apiRequest('POST', `/api/moderation/comments/${commentId}`, {
        action,
        reason
      });
      return await response.json();
    },
    onSuccess: () => {
      // Invalidate comments cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/comments'] });
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/logs'] });
      
      // Clear state and close dialog
      setSelectedComment(null);
      setActionReason("");
      setIsDialogOpen(false);
      
      toast({
        title: "Comment moderated",
        description: `Comment has been ${moderationAction === 'hide' ? 'hidden' : 'unhidden'} successfully.`,
        variant: moderationAction === 'hide' ? "destructive" : "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to moderate comment",
        description: error.message || "An error occurred while moderating the comment.",
        variant: "destructive",
      });
    }
  });

  // Open the moderation dialog
  const openModerationDialog = (comment: Comment, action: "hide" | "unhide") => {
    setSelectedComment(comment);
    setModerationAction(action);
    setIsDialogOpen(true);
  };

  // Submit moderation
  const handleModeration = () => {
    if (!selectedComment) return;
    
    moderationMutation.mutate({
      commentId: selectedComment.id,
      action: moderationAction,
      reason: actionReason
    });
  };

  // Format date string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-500">
        Error loading comments: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }

  return (
    <div>
      <div className="mb-4">
        <h2 className="text-xl font-bold">Flagged Comments</h2>
        <p className="text-muted-foreground">Review and moderate comments that have been flagged by users</p>
      </div>

      {comments && comments.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center">
            <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500 mb-4" />
            <p className="text-lg">No flagged comments found.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Comment</TableHead>
                <TableHead>User</TableHead>
                <TableHead>Video</TableHead>
                <TableHead>Posted</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {comments?.map((comment) => (
                <TableRow key={comment.id}>
                  <TableCell className="max-w-[300px]">
                    <p className="line-clamp-2">{comment.content}</p>
                  </TableCell>
                  <TableCell>{comment.userId}</TableCell>
                  <TableCell>{comment.videoId}</TableCell>
                  <TableCell>{formatDate(comment.createdAt)}</TableCell>
                  <TableCell>
                    {comment.isHidden ? (
                      <Badge variant="outline" className="bg-red-100 text-red-800">Hidden</Badge>
                    ) : (
                      <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Flagged</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(`/video/${comment.videoId}`, '_blank')}
                      >
                        View Video
                      </Button>
                      
                      {comment.isHidden ? (
                        <Button
                          size="sm"
                          variant="default"
                          onClick={() => openModerationDialog(comment, "unhide")}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          Unhide
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => openModerationDialog(comment, "hide")}
                        >
                          <EyeOff className="h-4 w-4 mr-1" />
                          Hide
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {moderationAction === "hide" ? 'Hide' : 'Unhide'} Comment
            </DialogTitle>
            <DialogDescription>
              {moderationAction === "hide"
                ? 'The comment will be hidden from users but kept in the database.'
                : 'The comment will be made visible to users again.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedComment && (
              <div className="flex flex-col space-y-1.5">
                <p><strong>Comment:</strong> {selectedComment.content}</p>
                <p><strong>Posted by:</strong> User ID {selectedComment.userId}</p>
                <p><strong>Video:</strong> ID {selectedComment.videoId}</p>
                <p><strong>Date:</strong> {formatDate(selectedComment.createdAt)}</p>
              </div>
            )}
            {moderationAction === "hide" && (
              <div className="space-y-2">
                <label htmlFor="reason" className="text-sm font-medium">
                  Reason for hiding:
                </label>
                <Textarea
                  id="reason"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  placeholder="Please provide a reason for hiding this comment"
                  rows={4}
                  required
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleModeration}
              disabled={moderationMutation.isPending || (moderationAction === "hide" && !actionReason)}
              variant={moderationAction === "hide" ? 'destructive' : 'default'}
            >
              {moderationMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {moderationAction === "hide" ? 'Hide Comment' : 'Unhide Comment'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}