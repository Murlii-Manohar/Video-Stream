import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { Report, ReportStatus, ContentType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, AlertTriangle, CheckCircle2, XCircle } from "lucide-react";

export default function ReportsList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<string>("pending");
  const [contentTypeFilter, setContentTypeFilter] = useState<string>("");
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);
  const [actionTaken, setActionTaken] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [resolutionStatus, setResolutionStatus] = useState(ReportStatus.REVIEWED);

  // Fetch reports based on filters
  const {
    data: reports,
    isLoading,
    error,
  } = useQuery<Report[]>({
    queryKey: ['/api/moderation/reports', { status: statusFilter, contentType: contentTypeFilter }],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Report resolution mutation
  const resolutionMutation = useMutation({
    mutationFn: async ({ reportId, status, actionTaken }: { reportId: number, status: string, actionTaken: string }) => {
      const response = await apiRequest('POST', `/api/moderation/reports/${reportId}`, {
        status,
        actionTaken
      });
      return await response.json();
    },
    onSuccess: () => {
      // Invalidate reports cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/reports'] });
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/logs'] });
      
      // Clear state and close dialog
      setSelectedReport(null);
      setActionTaken("");
      setIsDialogOpen(false);
      
      toast({
        title: "Report resolved",
        description: `Report has been marked as ${resolutionStatus.toLowerCase()}.`,
        variant: "default",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to resolve report",
        description: error.message || "An error occurred while resolving the report.",
        variant: "destructive",
      });
    }
  });

  // Handle status filter change
  const handleStatusFilterChange = (value: string) => {
    setStatusFilter(value);
  };

  // Handle content type filter change
  const handleContentTypeFilterChange = (value: string) => {
    setContentTypeFilter(value);
  };

  // Open the resolution dialog
  const openResolutionDialog = (report: Report, status: string) => {
    setSelectedReport(report);
    setResolutionStatus(status);
    setIsDialogOpen(true);
  };

  // Submit resolution
  const handleResolution = () => {
    if (!selectedReport) return;
    
    resolutionMutation.mutate({
      reportId: selectedReport.id,
      status: resolutionStatus,
      actionTaken
    });
  };

  // Format date string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  // Get content type label
  const getContentTypeLabel = (type: string) => {
    switch (type) {
      case ContentType.VIDEO:
        return "Video";
      case ContentType.COMMENT:
        return "Comment";
      case ContentType.USER:
        return "User";
      case ContentType.CHANNEL:
        return "Channel";
      default:
        return type;
    }
  };

  // Status badge component
  const StatusBadge = ({ status }: { status: string }) => {
    switch (status) {
      case ReportStatus.REVIEWED:
        return <Badge variant="outline" className="bg-green-100 text-green-800">Reviewed</Badge>;
      case ReportStatus.DISMISSED:
        return <Badge variant="outline" className="bg-red-100 text-red-800">Dismissed</Badge>;
      case ReportStatus.PENDING:
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-500">
        Error loading reports: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between mb-4">
        <h2 className="text-xl font-bold">Content Reports</h2>
        <div className="flex space-x-2">
          <Select
            value={contentTypeFilter}
            onValueChange={handleContentTypeFilterChange}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Content Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Types</SelectItem>
              <SelectItem value={ContentType.VIDEO}>Videos</SelectItem>
              <SelectItem value={ContentType.COMMENT}>Comments</SelectItem>
              <SelectItem value={ContentType.USER}>Users</SelectItem>
              <SelectItem value={ContentType.CHANNEL}>Channels</SelectItem>
            </SelectContent>
          </Select>
          
          <Select
            value={statusFilter}
            onValueChange={handleStatusFilterChange}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="">All Status</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {reports && reports.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center">
            <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500 mb-4" />
            <p className="text-lg">No reports found matching the current filters.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Report Type</TableHead>
                <TableHead>Content ID</TableHead>
                <TableHead>Reported By</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reports?.map((report) => (
                <TableRow key={report.id}>
                  <TableCell>{getContentTypeLabel(report.contentType)}</TableCell>
                  <TableCell>{report.contentId}</TableCell>
                  <TableCell>User {report.reporterId}</TableCell>
                  <TableCell className="max-w-[200px]">
                    <p className="truncate">{report.reason}</p>
                  </TableCell>
                  <TableCell>{formatDate(report.createdAt)}</TableCell>
                  <TableCell>
                    <StatusBadge status={report.status} />
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          // Navigate to content based on type
                          let url = "/";
                          switch (report.contentType) {
                            case ContentType.VIDEO:
                              url = `/video/${report.contentId}`;
                              break;
                            case ContentType.CHANNEL:
                              url = `/channel/${report.contentId}`;
                              break;
                            case ContentType.USER:
                              // No direct URL for users
                              break;
                            case ContentType.COMMENT:
                              // Will need to navigate to the video
                              url = `/video/${report.contentId}`; // This should be videoId, not commentId
                              break;
                          }
                          window.open(url, '_blank');
                        }}
                      >
                        View
                      </Button>
                      
                      {report.status === ReportStatus.PENDING && (
                        <>
                          <Button
                            size="sm"
                            variant="default"
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => openResolutionDialog(report, ReportStatus.REVIEWED)}
                          >
                            <CheckCircle2 className="h-4 w-4 mr-1" />
                            Review
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => openResolutionDialog(report, ReportStatus.DISMISSED)}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {resolutionStatus === ReportStatus.REVIEWED ? 'Review' : 'Dismiss'} Report
            </DialogTitle>
            <DialogDescription>
              {resolutionStatus === ReportStatus.REVIEWED
                ? 'Mark this report as reviewed after taking appropriate action.'
                : 'Mark this report as dismissed if no action is needed.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedReport && (
              <div className="flex flex-col space-y-1.5">
                <p><strong>Report Type:</strong> {getContentTypeLabel(selectedReport.contentType)}</p>
                <p><strong>Content ID:</strong> {selectedReport.contentId}</p>
                <p><strong>Reported By:</strong> User {selectedReport.reporterId}</p>
                <p><strong>Reason:</strong> {selectedReport.reason}</p>
                <p><strong>Date:</strong> {formatDate(selectedReport.createdAt)}</p>
              </div>
            )}
            <div className="space-y-2">
              <label htmlFor="actionTaken" className="text-sm font-medium">
                Action Taken:
              </label>
              <Textarea
                id="actionTaken"
                value={actionTaken}
                onChange={(e) => setActionTaken(e.target.value)}
                placeholder={resolutionStatus === ReportStatus.REVIEWED
                  ? 'Describe the action you took to review this report'
                  : 'Explain why this report was dismissed (optional)'}
                rows={4}
                required={resolutionStatus === ReportStatus.REVIEWED}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleResolution}
              disabled={resolutionMutation.isPending || (resolutionStatus === ReportStatus.REVIEWED && !actionTaken)}
              variant={resolutionStatus === ReportStatus.REVIEWED ? 'default' : 'secondary'}
              className={resolutionStatus === ReportStatus.REVIEWED ? 'bg-green-600 hover:bg-green-700' : ''}
            >
              {resolutionMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {resolutionStatus === ReportStatus.REVIEWED ? 'Mark as Reviewed' : 'Mark as Dismissed'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}