import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, Ban, AlertTriangle } from "lucide-react";

export default function UsersList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [actionReason, setActionReason] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [moderationAction, setModerationAction] = useState<"ban" | "unban">("ban");

  // Fetch users (empty for now - in a real implementation we would use a getAllUsers endpoint)
  const {
    data: users,
    isLoading,
    error,
  } = useQuery<User[]>({
    queryKey: ['/api/moderation/users'],
    queryFn: getQueryFn(),
  });

  // User moderation mutation
  const moderationMutation = useMutation({
    mutationFn: async ({ userId, action, reason }: { userId: number, action: "ban" | "unban", reason?: string }) => {
      const response = await apiRequest('POST', `/api/moderation/users/${userId}`, {
        action,
        reason
      });
      return await response.json();
    },
    onSuccess: () => {
      // Invalidate users cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/logs'] });
      
      // Clear state and close dialog
      setSelectedUser(null);
      setActionReason("");
      setIsDialogOpen(false);
      
      toast({
        title: `User ${moderationAction === 'ban' ? 'banned' : 'unbanned'}`,
        description: `User has been ${moderationAction === 'ban' ? 'banned' : 'unbanned'} successfully.`,
        variant: moderationAction === 'ban' ? "destructive" : "default",
      });
    },
    onError: (error) => {
      toast({
        title: `Failed to ${moderationAction} user`,
        description: error.message || `An error occurred while ${moderationAction}ning the user.`,
        variant: "destructive",
      });
    }
  });

  // Open the moderation dialog
  const openModerationDialog = (user: User, action: "ban" | "unban") => {
    setSelectedUser(user);
    setModerationAction(action);
    setIsDialogOpen(true);
  };

  // Submit moderation
  const handleModeration = () => {
    if (!selectedUser) return;
    
    moderationMutation.mutate({
      userId: selectedUser.id,
      action: moderationAction,
      reason: actionReason
    });
  };

  // Format date string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-500">
        Error loading users: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }

  // For this implementation, we'll show a placeholder message since the users API isn't fully implemented
  return (
    <div>
      <div className="mb-4">
        <h2 className="text-xl font-bold">User Management</h2>
        <p className="text-muted-foreground">Manage user accounts and permissions</p>
      </div>

      <Card>
        <CardContent className="py-10 text-center">
          <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500 mb-4" />
          <p className="text-lg">
            User management functionality is still in development.
          </p>
          <p className="text-muted-foreground mt-2">
            This page will allow administrators to view, ban, and manage user accounts.
          </p>
        </CardContent>
      </Card>

      {/* Dialog for user moderation */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {moderationAction === "ban" ? 'Ban' : 'Unban'} User
            </DialogTitle>
            <DialogDescription>
              {moderationAction === "ban"
                ? 'The user will be banned from using the platform.'
                : 'The user will be allowed to use the platform again.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedUser && (
              <div className="flex flex-col space-y-1.5">
                <p><strong>Username:</strong> {selectedUser.username}</p>
                <p><strong>Email:</strong> {selectedUser.email}</p>
                <p><strong>Joined:</strong> {formatDate(selectedUser.createdAt)}</p>
              </div>
            )}
            {moderationAction === "ban" && (
              <div className="space-y-2">
                <label htmlFor="reason" className="text-sm font-medium">
                  Reason for banning:
                </label>
                <Textarea
                  id="reason"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  placeholder="Please provide a reason for banning this user"
                  rows={4}
                  required
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleModeration}
              disabled={moderationMutation.isPending || (moderationAction === "ban" && !actionReason)}
              variant={moderationAction === "ban" ? 'destructive' : 'default'}
            >
              {moderationMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {moderationAction === "ban" ? 'Ban User' : 'Unban User'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}