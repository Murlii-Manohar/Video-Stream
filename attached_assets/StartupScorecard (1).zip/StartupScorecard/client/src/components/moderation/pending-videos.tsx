import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { Video, ModerationStatus } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, XCircle, AlertTriangle } from "lucide-react";

export default function PendingVideos() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<string>("pending");
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [moderationReason, setModerationReason] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [moderationAction, setModerationAction] = useState<string>("");

  // Fetch videos based on filter
  const {
    data: videos,
    isLoading,
    error,
  } = useQuery<Video[]>({
    queryKey: ['/api/moderation/videos', { status: statusFilter }],
    queryFn: getQueryFn(),
  });

  // Moderation mutation
  const moderationMutation = useMutation({
    mutationFn: async ({ videoId, status, reason }: { videoId: number, status: string, reason: string }) => {
      const response = await apiRequest('POST', `/api/moderation/videos/${videoId}`, {
        status,
        reason
      });
      return await response.json();
    },
    onSuccess: () => {
      // Invalidate videos cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/videos'] });
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/logs'] });
      
      // Clear state and close dialog
      setSelectedVideo(null);
      setModerationReason("");
      setIsDialogOpen(false);
      
      toast({
        title: "Video moderated",
        description: `Video has been ${moderationAction === ModerationStatus.APPROVED ? 'approved' : 'rejected'} successfully.`,
        variant: moderationAction === ModerationStatus.APPROVED ? "default" : "destructive",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to moderate video",
        description: error.message || "An error occurred while moderating the video.",
        variant: "destructive",
      });
    }
  });

  // Handle status filter change
  const handleStatusFilterChange = (value: string) => {
    setStatusFilter(value);
  };

  // Open the moderation dialog
  const openModerationDialog = (video: Video, action: string) => {
    setSelectedVideo(video);
    setModerationAction(action);
    setIsDialogOpen(true);
  };

  // Submit moderation
  const handleModeration = () => {
    if (!selectedVideo) return;
    
    moderationMutation.mutate({
      videoId: selectedVideo.id,
      status: moderationAction,
      reason: moderationReason
    });
  };

  // Format date string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  // Status badge component
  const StatusBadge = ({ status }: { status: string }) => {
    switch (status) {
      case ModerationStatus.APPROVED:
        return <Badge variant="outline" className="bg-green-100 text-green-800">Approved</Badge>;
      case ModerationStatus.REJECTED:
        return <Badge variant="outline" className="bg-red-100 text-red-800">Rejected</Badge>;
      case ModerationStatus.PENDING:
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-500">
        Error loading videos: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between mb-4">
        <h2 className="text-xl font-bold">Video Moderation</h2>
        <Select
          value={statusFilter}
          onValueChange={handleStatusFilterChange}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="pending">Pending Review</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
            <SelectItem value="all">All Videos</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {videos && videos.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center">
            <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500 mb-4" />
            <p className="text-lg">No videos found matching the current filter.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Channel</TableHead>
                <TableHead>Uploaded</TableHead>
                <TableHead className="w-28">Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {videos?.map((video) => (
                <TableRow key={video.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      {video.thumbnail && (
                        <img
                          src={`/uploads/${video.thumbnail}`}
                          alt={video.title}
                          className="w-16 h-9 object-cover mr-3 rounded"
                        />
                      )}
                      <div>
                        <p className="truncate max-w-[200px]">{video.title}</p>
                        <p className="text-xs text-muted-foreground">
                          {video.isQuickie ? 'Quickie' : 'Regular'}
                          {video.isPremium && ' • Premium'}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>{video.channelName}</TableCell>
                  <TableCell>{formatDate(video.createdAt)}</TableCell>
                  <TableCell>
                    <StatusBadge status={video.moderationStatus || ModerationStatus.PENDING} />
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(`/video/${video.id}`, '_blank')}
                      >
                        View
                      </Button>
                      
                      {(!video.moderationStatus || video.moderationStatus === ModerationStatus.PENDING) && (
                        <>
                          <Button
                            size="sm"
                            variant="default"
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => openModerationDialog(video, ModerationStatus.APPROVED)}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => openModerationDialog(video, ModerationStatus.REJECTED)}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {moderationAction === ModerationStatus.APPROVED ? 'Approve' : 'Reject'} Video
            </DialogTitle>
            <DialogDescription>
              {moderationAction === ModerationStatus.APPROVED
                ? 'The video will be approved and made publicly available.'
                : 'The video will be rejected and not visible to users.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedVideo && (
              <div className="flex flex-col space-y-1.5">
                <p><strong>Title:</strong> {selectedVideo.title}</p>
                <p><strong>Channel:</strong> {selectedVideo.channelName}</p>
                <p><strong>Uploaded:</strong> {formatDate(selectedVideo.createdAt)}</p>
              </div>
            )}
            <div className="space-y-2">
              <label htmlFor="reason" className="text-sm font-medium">
                Moderation Reason:
              </label>
              <Textarea
                id="reason"
                value={moderationReason}
                onChange={(e) => setModerationReason(e.target.value)}
                placeholder={moderationAction === ModerationStatus.APPROVED
                  ? 'Optional reason for approval'
                  : 'Please provide a reason for rejection'}
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleModeration}
              disabled={moderationMutation.isPending}
              variant={moderationAction === ModerationStatus.APPROVED ? 'default' : 'destructive'}
            >
              {moderationMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {moderationAction === ModerationStatus.APPROVED ? 'Approve Video' : 'Reject Video'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}