import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import { ModerationLog, ContentType } from "@shared/schema";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, AlertTriangle, History } from "lucide-react";

export default function ModerationLogs() {
  const [contentTypeFilter, setContentTypeFilter] = useState<string>("");
  const [moderatorFilter, setModeratorFilter] = useState<string>("");

  // Fetch moderation logs based on filters
  const {
    data: logs,
    isLoading,
    error,
  } = useQuery<ModerationLog[]>({
    queryKey: ['/api/moderation/logs', { contentType: contentTypeFilter, moderatorId: moderatorFilter }],
    queryFn: getQueryFn(),
  });
  
  // Format date string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  // Get content type label
  const getContentTypeLabel = (type: string) => {
    switch (type) {
      case ContentType.VIDEO:
        return "Video";
      case ContentType.COMMENT:
        return "Comment";
      case ContentType.USER:
        return "User";
      case ContentType.CHANNEL:
        return "Channel";
      case "report":
        return "Report";
      default:
        return type;
    }
  };

  // Handle content type filter change
  const handleContentTypeFilterChange = (value: string) => {
    setContentTypeFilter(value);
  };

  // Handle moderator filter change - simple string implementation for now
  const handleModeratorFilterChange = (value: string) => {
    setModeratorFilter(value);
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-500">
        Error loading moderation logs: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between mb-4">
        <h2 className="text-xl font-bold">Moderation Logs</h2>
        <div className="flex space-x-2">
          <Select
            value={contentTypeFilter}
            onValueChange={handleContentTypeFilterChange}
          >
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Content Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Types</SelectItem>
              <SelectItem value={ContentType.VIDEO}>Videos</SelectItem>
              <SelectItem value={ContentType.COMMENT}>Comments</SelectItem>
              <SelectItem value={ContentType.USER}>Users</SelectItem>
              <SelectItem value={ContentType.CHANNEL}>Channels</SelectItem>
              <SelectItem value="report">Reports</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {logs && logs.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center">
            <History className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-lg">No moderation logs found.</p>
            <p className="text-muted-foreground mt-2">
              Moderation actions performed by moderators and admins will appear here.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Action</TableHead>
                <TableHead>Content Type</TableHead>
                <TableHead>Content ID</TableHead>
                <TableHead>Moderator</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs?.map((log) => (
                <TableRow key={log.id}>
                  <TableCell>
                    <Badge
                      variant="outline"
                      className={
                        log.action.includes("approve") || log.action.includes("enable") || log.action.includes("unhide") || log.action.includes("unban") || log.action.includes("verify")
                          ? "bg-green-100 text-green-800"
                          : log.action.includes("reject") || log.action.includes("disable") || log.action.includes("hide") || log.action.includes("ban") || log.action.includes("unverify")
                          ? "bg-red-100 text-red-800"
                          : "bg-blue-100 text-blue-800"
                      }
                    >
                      {log.action}
                    </Badge>
                  </TableCell>
                  <TableCell>{getContentTypeLabel(log.contentType)}</TableCell>
                  <TableCell>{log.contentId}</TableCell>
                  <TableCell>User {log.moderatorId}</TableCell>
                  <TableCell className="max-w-[300px]">
                    <p className="truncate">{log.reason || "No reason provided"}</p>
                  </TableCell>
                  <TableCell>{formatDate(log.createdAt)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}