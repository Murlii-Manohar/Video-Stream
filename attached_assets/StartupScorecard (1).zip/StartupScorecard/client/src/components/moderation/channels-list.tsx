import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import { Channel } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, AlertTriangle, LockIcon, UnlockIcon } from "lucide-react";

export default function ChannelsList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [actionReason, setActionReason] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [moderationAction, setModerationAction] = useState<"verify" | "unverify" | "disable" | "enable">("verify");

  // Fetch channels
  const {
    data: channels,
    isLoading,
    error,
  } = useQuery<Channel[]>({
    queryKey: ['/api/channels'],
    queryFn: getQueryFn(),
  });

  // Channel moderation mutation
  const moderationMutation = useMutation({
    mutationFn: async ({ 
      channelId, 
      action, 
      reason 
    }: { 
      channelId: number, 
      action: "verify" | "unverify" | "disable" | "enable", 
      reason?: string 
    }) => {
      const response = await apiRequest('POST', `/api/moderation/channels/${channelId}`, {
        action,
        reason
      });
      return await response.json();
    },
    onSuccess: () => {
      // Invalidate channels cache to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/channels'] });
      queryClient.invalidateQueries({ queryKey: ['/api/moderation/logs'] });
      
      // Clear state and close dialog
      setSelectedChannel(null);
      setActionReason("");
      setIsDialogOpen(false);
      
      const actionText = {
        verify: 'verified',
        unverify: 'unverified',
        disable: 'disabled',
        enable: 'enabled'
      }[moderationAction];
      
      toast({
        title: `Channel ${actionText}`,
        description: `Channel has been ${actionText} successfully.`,
        variant: moderationAction === 'disable' ? "destructive" : "default",
      });
    },
    onError: (error) => {
      toast({
        title: `Failed to ${moderationAction} channel`,
        description: error.message || `An error occurred while ${moderationAction}ing the channel.`,
        variant: "destructive",
      });
    }
  });

  // Open the moderation dialog
  const openModerationDialog = (channel: Channel, action: "verify" | "unverify" | "disable" | "enable") => {
    setSelectedChannel(channel);
    setModerationAction(action);
    setIsDialogOpen(true);
  };

  // Submit moderation
  const handleModeration = () => {
    if (!selectedChannel) return;
    
    moderationMutation.mutate({
      channelId: selectedChannel.id,
      action: moderationAction,
      reason: actionReason
    });
  };

  // Format date string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8 text-red-500">
        Error loading channels: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }

  return (
    <div>
      <div className="mb-4">
        <h2 className="text-xl font-bold">Channel Management</h2>
        <p className="text-muted-foreground">Verify, disable, or manage content creator channels</p>
      </div>

      {channels && channels.length === 0 ? (
        <Card>
          <CardContent className="py-10 text-center">
            <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500 mb-4" />
            <p className="text-lg">No channels found.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Channel</TableHead>
                <TableHead>Created by</TableHead>
                <TableHead>Subscribers</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {channels?.map((channel) => (
                <TableRow key={channel.id}>
                  <TableCell>
                    <div className="flex items-center">
                      {channel.banner ? (
                        <img
                          src={`/uploads/${channel.banner}`}
                          alt={channel.name}
                          className="w-10 h-10 object-cover mr-3 rounded-full"
                        />
                      ) : (
                        <div className="w-10 h-10 bg-secondary rounded-full mr-3 flex items-center justify-center">
                          {channel.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <p className="font-medium">{channel.name}</p>
                        <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                          {channel.description || 'No description'}
                        </p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>User {channel.userId}</TableCell>
                  <TableCell>{channel.subscriberCount.toLocaleString()}</TableCell>
                  <TableCell>{formatDate(channel.createdAt)}</TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      {channel.isVerified && (
                        <Badge variant="outline" className="bg-blue-100 text-blue-800">Verified</Badge>
                      )}
                      {channel.isDisabled && (
                        <Badge variant="outline" className="bg-red-100 text-red-800">Disabled</Badge>
                      )}
                      {!channel.isVerified && !channel.isDisabled && (
                        <Badge variant="outline" className="bg-gray-100">Regular</Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => window.open(`/channel/${channel.id}`, '_blank')}
                      >
                        View
                      </Button>
                      
                      {channel.isVerified ? (
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => openModerationDialog(channel, "unverify")}
                        >
                          Unverify
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="default"
                          className="bg-blue-600 hover:bg-blue-700"
                          onClick={() => openModerationDialog(channel, "verify")}
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Verify
                        </Button>
                      )}
                      
                      {channel.isDisabled ? (
                        <Button
                          size="sm"
                          variant="default"
                          onClick={() => openModerationDialog(channel, "enable")}
                        >
                          <UnlockIcon className="h-4 w-4 mr-1" />
                          Enable
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => openModerationDialog(channel, "disable")}
                        >
                          <LockIcon className="h-4 w-4 mr-1" />
                          Disable
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {moderationAction === "verify" ? 'Verify' : 
               moderationAction === "unverify" ? 'Unverify' :
               moderationAction === "disable" ? 'Disable' : 'Enable'} Channel
            </DialogTitle>
            <DialogDescription>
              {moderationAction === "verify" 
                ? 'Verifying a channel marks it as official or trustworthy.' 
                : moderationAction === "unverify" 
                ? 'Remove the verified status from this channel.'
                : moderationAction === "disable"
                ? 'Disabling a channel prevents it from uploading new content.'
                : 'Re-enable this channel to allow content uploads.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {selectedChannel && (
              <div className="flex flex-col space-y-1.5">
                <p><strong>Channel:</strong> {selectedChannel.name}</p>
                <p><strong>Owner:</strong> User {selectedChannel.userId}</p>
                <p><strong>Subscribers:</strong> {selectedChannel.subscriberCount.toLocaleString()}</p>
                <p><strong>Created:</strong> {formatDate(selectedChannel.createdAt)}</p>
              </div>
            )}
            {moderationAction === "disable" && (
              <div className="space-y-2">
                <label htmlFor="reason" className="text-sm font-medium">
                  Reason for disabling:
                </label>
                <Textarea
                  id="reason"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  placeholder="Please provide a reason for disabling this channel"
                  rows={4}
                  required
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleModeration}
              disabled={moderationMutation.isPending || (moderationAction === "disable" && !actionReason)}
              variant={moderationAction === "disable" ? 'destructive' : 
                     moderationAction === "verify" ? 'default' : 'secondary'}
              className={moderationAction === "verify" ? 'bg-blue-600 hover:bg-blue-700' : ''}
            >
              {moderationMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              {moderationAction === "verify" ? 'Verify Channel' : 
               moderationAction === "unverify" ? 'Unverify Channel' :
               moderationAction === "disable" ? 'Disable Channel' : 'Enable Channel'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}