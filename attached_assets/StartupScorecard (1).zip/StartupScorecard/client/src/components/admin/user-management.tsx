import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Ban, Search, ShieldCheck, ShieldAlert } from "lucide-react";
import { format } from 'date-fns';
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";

export function UserManagement() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [banReason, setBanReason] = useState("");
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [isBanDialogOpen, setIsBanDialogOpen] = useState(false);
  
  // Fetch users for admin
  const { data: users, isLoading, error } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
    queryFn: async () => {
      const res = await fetch('/api/admin/users');
      if (!res.ok) {
        throw new Error('Failed to fetch users');
      }
      return res.json();
    },
  });
  
  // Ban user mutation
  const banUserMutation = useMutation({
    mutationFn: async ({ userId, reason }: { userId: number; reason: string }) => {
      const res = await apiRequest('POST', `/api/admin/users/${userId}/ban`, { reason });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "User banned",
        description: "The user has been banned from the platform",
      });
      setIsBanDialogOpen(false);
      setBanReason("");
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
    },
    onError: (error) => {
      toast({
        title: "Error banning user",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Unban user mutation
  const unbanUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const res = await apiRequest('POST', `/api/admin/users/${userId}/unban`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "User unbanned",
        description: "The user has been unbanned and can now use the platform",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
    },
    onError: (error) => {
      toast({
        title: "Error unbanning user",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Toggle admin status mutation
  const toggleAdminMutation = useMutation({
    mutationFn: async ({ userId, makeAdmin }: { userId: number; makeAdmin: boolean }) => {
      const endpoint = makeAdmin ? 
        `/api/admin/users/${userId}/make-admin` : 
        `/api/admin/users/${userId}/remove-admin`;
      const res = await apiRequest('POST', endpoint);
      return res.json();
    },
    onSuccess: (_, variables) => {
      toast({
        title: variables.makeAdmin ? "Admin rights granted" : "Admin rights removed",
        description: variables.makeAdmin ?
          "The user has been granted admin privileges" :
          "The user's admin privileges have been removed",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
    },
    onError: (error) => {
      toast({
        title: "Error updating admin status",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  const handleBanUser = (userId: number) => {
    setSelectedUserId(userId);
    setIsBanDialogOpen(true);
  };
  
  const submitBan = () => {
    if (!selectedUserId) return;
    
    if (!banReason.trim()) {
      toast({
        title: "Reason required",
        description: "Please provide a reason for banning this user",
        variant: "destructive",
      });
      return;
    }
    
    banUserMutation.mutate({ userId: selectedUserId, reason: banReason });
  };
  
  const handleUnbanUser = (userId: number) => {
    if (confirm("Are you sure you want to unban this user?")) {
      unbanUserMutation.mutate(userId);
    }
  };
  
  const handleToggleAdmin = (userId: number, isCurrentlyAdmin: boolean) => {
    const action = isCurrentlyAdmin ? "remove admin rights from" : "grant admin rights to";
    
    if (confirm(`Are you sure you want to ${action} this user?`)) {
      toggleAdminMutation.mutate({ 
        userId, 
        makeAdmin: !isCurrentlyAdmin 
      });
    }
  };
  
  // Filter users based on search term
  const filteredUsers = users?.filter(user => 
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];
  
  if (isLoading) {
    return <div className="text-center py-4">Loading users...</div>;
  }
  
  if (error) {
    return (
      <div className="text-center py-4 text-red-500">
        Error loading users: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }
  
  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>User Management</CardTitle>
          <CardDescription>Manage user accounts and access control</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Search */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                placeholder="Search users by username or email"
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          {/* Users Table */}
          <Table>
            <TableCaption>Total of {filteredUsers.length} users</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Username</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Registered</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center h-24 text-gray-500">
                    No users found
                  </TableCell>
                </TableRow>
              ) : (
                filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">
                      {user.username}
                    </TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>
                      <Badge 
                        variant={user.isBanned ? "destructive" : "default"}
                        className={!user.isBanned ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300" : ""}
                      >
                        {user.isBanned ? "Banned" : "Active"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {user.isAdmin ? (
                        <Badge className="bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-900 dark:text-purple-300 dark:border-purple-800">
                          Admin
                        </Badge>
                      ) : (
                        <Badge variant="outline">
                          User
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      {user.createdAt ? format(new Date(user.createdAt), 'MMM d, yyyy') : 'Unknown'}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleToggleAdmin(user.id, !!user.isAdmin)}
                          className={user.isAdmin ? "text-red-500 border-red-200" : "text-purple-500 border-purple-200"}
                        >
                          {user.isAdmin ? (
                            <>
                              <ShieldAlert className="h-4 w-4 mr-1" />
                              Remove Admin
                            </>
                          ) : (
                            <>
                              <ShieldCheck className="h-4 w-4 mr-1" />
                              Make Admin
                            </>
                          )}
                        </Button>
                        
                        {user.isBanned ? (
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-green-500 border-green-200"
                            onClick={() => handleUnbanUser(user.id)}
                          >
                            Unban
                          </Button>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            className="text-red-500 border-red-200"
                            onClick={() => handleBanUser(user.id)}
                          >
                            <Ban className="h-4 w-4 mr-1" />
                            Ban
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Ban User Dialog */}
      <Dialog open={isBanDialogOpen} onOpenChange={setIsBanDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ban User</DialogTitle>
            <DialogDescription>
              Please provide a reason for banning this user. This will prevent them from accessing the platform.
            </DialogDescription>
          </DialogHeader>
          
          <div className="my-4">
            <Textarea
              placeholder="Enter reason for ban (required)"
              value={banReason}
              onChange={(e) => setBanReason(e.target.value)}
              rows={4}
            />
          </div>
          
          <DialogFooter>
            <Button 
              variant="ghost" 
              onClick={() => setIsBanDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={submitBan}
              disabled={!banReason.trim() || banUserMutation.isPending}
            >
              Ban User
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}