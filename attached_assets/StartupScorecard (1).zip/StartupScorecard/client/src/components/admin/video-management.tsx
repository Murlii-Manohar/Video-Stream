import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Video } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Trash, Search, Eye } from "lucide-react";
import { format } from 'date-fns';
import { Badge } from "@/components/ui/badge";
import { useLocation } from 'wouter';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function VideoManagement() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [moderationFilter, setModerationFilter] = useState<string>("all");
  const [, navigate] = useLocation();
  
  // Fetch videos for admin
  const { data: videos, isLoading, error } = useQuery<Video[]>({
    queryKey: ['/api/admin/videos'],
    queryFn: async () => {
      const res = await fetch('/api/admin/videos');
      if (!res.ok) {
        throw new Error('Failed to fetch videos');
      }
      return res.json();
    },
  });
  
  // Delete video
  const deleteVideoMutation = useMutation({
    mutationFn: async (videoId: number) => {
      const res = await apiRequest('DELETE', `/api/admin/videos/${videoId}`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Video deleted",
        description: "The video has been permanently deleted",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/videos'] });
    },
    onError: (error) => {
      toast({
        title: "Error deleting video",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  const handleDeleteVideo = (videoId: number, title: string) => {
    if (confirm(`Are you sure you want to permanently delete the video "${title}"? This action cannot be undone.`)) {
      deleteVideoMutation.mutate(videoId);
    }
  };
  
  const handleViewVideo = (videoId: number) => {
    navigate(`/video/${videoId}`);
  };
  
  // Filter videos based on search term and moderation status
  const filteredVideos = videos?.filter(video => {
    // Filter by search term
    const matchesSearch = 
      video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      video.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Filter by moderation status
    const matchesModeration = 
      moderationFilter === "all" ||
      (moderationFilter === "pending" && (!video.moderationStatus || video.moderationStatus === "pending")) ||
      (moderationFilter === "approved" && video.moderationStatus === "approved") ||
      (moderationFilter === "rejected" && video.moderationStatus === "rejected");
    
    return matchesSearch && matchesModeration;
  }) || [];
  
  if (isLoading) {
    return <div className="text-center py-4">Loading videos...</div>;
  }
  
  if (error) {
    return (
      <div className="text-center py-4 text-red-500">
        Error loading videos: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Video Management</CardTitle>
        <CardDescription>Manage videos across the platform</CardDescription>
      </CardHeader>
      <CardContent>
        {/* Search and Filters */}
        <div className="mb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Search videos by title or description"
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Select value={moderationFilter} onValueChange={setModerationFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Moderation Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectLabel>Moderation Status</SelectLabel>
                  <SelectItem value="all">All Videos</SelectItem>
                  <SelectItem value="pending">Pending Review</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Videos Table */}
        <Table>
          <TableCaption>Total of {filteredVideos.length} videos</TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Channel</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Uploaded</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredVideos.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center h-24 text-gray-500">
                  No videos found
                </TableCell>
              </TableRow>
            ) : (
              filteredVideos.map((video) => (
                <TableRow key={video.id}>
                  <TableCell className="font-medium">
                    {video.title}
                    {video.isPremium && (
                      <Badge variant="outline" className="ml-2 border-amber-200 bg-amber-100 text-amber-700 dark:border-amber-800 dark:bg-amber-900 dark:text-amber-300">
                        Premium
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>Channel ID: {video.channelId}</TableCell>
                  <TableCell>
                    {video.isQuickie ? (
                      <Badge variant="outline" className="border-blue-200 bg-blue-100 text-blue-700 dark:border-blue-800 dark:bg-blue-900 dark:text-blue-300">
                        Quickie
                      </Badge>
                    ) : (
                      <Badge variant="outline">Standard</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant={
                        video.moderationStatus === "rejected" ? "destructive" : 
                        "default"
                      }
                      className={
                        video.moderationStatus === "approved" ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300" : ""
                      }
                    >
                      {video.moderationStatus?.charAt(0).toUpperCase() + video.moderationStatus?.slice(1) || "Pending"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {video.createdAt ? format(new Date(video.createdAt), 'MMM d, yyyy') : 'Unknown'}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewVideo(video.id)}
                        title="View video"
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500"
                        onClick={() => handleDeleteVideo(video.id, video.title)}
                        title="Delete video"
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}