import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Channel } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Trash, Search, ExternalLink } from "lucide-react";
import { format } from 'date-fns';
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export function ChannelManagement() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  
  // Fetch channels for admin
  const { data: channels, isLoading, error } = useQuery<Channel[]>({
    queryKey: ['/api/admin/channels'],
    queryFn: async () => {
      const res = await fetch('/api/admin/channels');
      if (!res.ok) {
        throw new Error('Failed to fetch channels');
      }
      return res.json();
    },
  });
  
  // Delete channel
  const deleteChannelMutation = useMutation({
    mutationFn: async (channelId: number) => {
      const res = await apiRequest('DELETE', `/api/admin/channels/${channelId}`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Channel deleted",
        description: "The channel and all its videos have been permanently deleted",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/channels'] });
    },
    onError: (error) => {
      toast({
        title: "Error deleting channel",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Verify channel
  const verifyChannelMutation = useMutation({
    mutationFn: async ({ channelId, verified }: { channelId: number; verified: boolean }) => {
      const endpoint = verified ? 
        `/api/admin/channels/${channelId}/verify` : 
        `/api/admin/channels/${channelId}/unverify`;
      const res = await apiRequest('POST', endpoint);
      return res.json();
    },
    onSuccess: (_, variables) => {
      toast({
        title: variables.verified ? "Channel verified" : "Channel verification removed",
        description: variables.verified ? 
          "The channel has been verified" : 
          "The channel is no longer verified",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/channels'] });
    },
    onError: (error) => {
      toast({
        title: "Error updating channel",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  const handleDeleteChannel = (channelId: number, name: string) => {
    if (confirm(`Are you sure you want to permanently delete the channel "${name}"? This will also delete all videos associated with this channel. This action cannot be undone.`)) {
      deleteChannelMutation.mutate(channelId);
    }
  };
  
  const handleToggleVerification = (channelId: number, currentlyVerified: boolean) => {
    const action = currentlyVerified ? "unverify" : "verify";
    const confirmMessage = currentlyVerified ?
      "Are you sure you want to remove verification from this channel?" :
      "Are you sure you want to verify this channel?";
      
    if (confirm(confirmMessage)) {
      verifyChannelMutation.mutate({ 
        channelId, 
        verified: !currentlyVerified 
      });
    }
  };
  
  // Filter channels based on search term
  const filteredChannels = channels?.filter(channel => 
    channel.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    channel.description?.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];
  
  if (isLoading) {
    return <div className="text-center py-4">Loading channels...</div>;
  }
  
  if (error) {
    return (
      <div className="text-center py-4 text-red-500">
        Error loading channels: {error instanceof Error ? error.message : "Unknown error"}
      </div>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Channel Management</CardTitle>
        <CardDescription>Manage creator channels across the platform</CardDescription>
      </CardHeader>
      <CardContent>
        {/* Search */}
        <div className="mb-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-gray-500" />
            <Input
              placeholder="Search channels by name or description"
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        
        {/* Channels Table */}
        <Table>
          <TableCaption>Total of {filteredChannels.length} channels</TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredChannels.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center h-24 text-gray-500">
                  No channels found
                </TableCell>
              </TableRow>
            ) : (
              filteredChannels.map((channel) => (
                <TableRow key={channel.id}>
                  <TableCell className="font-medium">
                    {channel.name}
                    {channel.isVerified && (
                      <Badge variant="outline" className="ml-2 bg-blue-50 border-blue-200 text-blue-600 dark:bg-blue-900 dark:border-blue-800 dark:text-blue-300">
                        Verified
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>User ID: {channel.userId}</TableCell>
                  <TableCell>
                    <Badge 
                      variant={channel.isDisabled ? "destructive" : "default"}
                      className={!channel.isDisabled ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300" : ""}
                    >
                      {channel.isDisabled ? "Disabled" : "Active"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {channel.createdAt ? format(new Date(channel.createdAt), 'MMM d, yyyy') : 'Unknown'}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleToggleVerification(channel.id, !!channel.isVerified)}
                        className={channel.isVerified ? "text-red-500 border-red-200" : "text-green-500 border-green-200"}
                      >
                        {channel.isVerified ? "Unverify" : "Verify"}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-500"
                        onClick={() => handleDeleteChannel(channel.id, channel.name)}
                        title="Delete channel"
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}