import { Link } from "wouter";
import { Video, Channel, User } from "@shared/schema";

interface VideoCardProps {
  video: Video;
  channel?: Channel;
  channelOwner?: User;
  isQuickie?: boolean;
}

export function VideoCard({ video, channel, channelOwner, isQuickie }: VideoCardProps) {
  // Format view count
  const formatViews = (views: number | null) => {
    const viewCount = views || 0;
    if (viewCount >= 1000000) {
      return `${(viewCount / 1000000).toFixed(1)}M`;
    } else if (viewCount >= 1000) {
      return `${(viewCount / 1000).toFixed(1)}K`;
    } else {
      return viewCount.toString();
    }
  };
  
  // Format time ago
  const timeAgo = (date: Date | string | null) => {
    if (!date) return "recently";
    
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    const seconds = Math.floor((new Date().getTime() - dateObj.getTime()) / 1000);
    let interval = Math.floor(seconds / 31536000);
    
    if (interval >= 1) {
      return `${interval} year${interval === 1 ? '' : 's'} ago`;
    }
    interval = Math.floor(seconds / 2592000);
    if (interval >= 1) {
      return `${interval} month${interval === 1 ? '' : 's'} ago`;
    }
    interval = Math.floor(seconds / 86400);
    if (interval >= 1) {
      return `${interval} day${interval === 1 ? '' : 's'} ago`;
    }
    interval = Math.floor(seconds / 3600);
    if (interval >= 1) {
      return `${interval} hour${interval === 1 ? '' : 's'} ago`;
    }
    interval = Math.floor(seconds / 60);
    if (interval >= 1) {
      return `${interval} minute${interval === 1 ? '' : 's'} ago`;
    }
    return `${Math.floor(seconds)} second${seconds === 1 ? '' : 's'} ago`;
  };
  
  // Format duration
  const formatDuration = (seconds: number | null) => {
    if (!seconds) return "0:00";
    
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
      return `${mins}:${secs.toString().padStart(2, '0')}`;
    }
  };

  const channelAvatar = channelOwner?.avatar || channel?.banner || 'https://ui-avatars.com/api/?name=Channel&background=random';
  const channelName = channel?.name || 'Unknown Channel';
  const isVerified = channelOwner?.isVerified || false;
  
  // Different aspect ratio and styling for Quickies
  const aspectRatio = isQuickie || video.isQuickie ? "aspect-[9/16]" : "aspect-video";
  
  return (
    <div className={`video-card group ${isQuickie || video.isQuickie ? 'quickie-card' : ''}`}>
      <Link href={`/video/${video.id}`}>
        <div className={`relative rounded-lg overflow-hidden ${aspectRatio} bg-gray-800 mb-3 group-hover:shadow-lg transition duration-300`}>
          {video.thumbnail ? (
            <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gray-800 flex items-center justify-center">
              <span className="text-white text-xs opacity-70">No Thumbnail</span>
            </div>
          )}
          {video.duration && video.duration > 0 && (
            <div className="video-duration">{formatDuration(video.duration)}</div>
          )}
          {(isQuickie || video.isQuickie) && (
            <div className="quickie-badge">
              Q
            </div>
          )}
          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/30 transition duration-300">
            <button className="bg-primary/80 hover:bg-primary text-white w-12 h-12 rounded-full flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </button>
          </div>
        </div>
      </Link>
      
      {/* For standard videos, show full info. For Quickies, show minimal info */}
      {!(isQuickie || video.isQuickie) ? (
        <div className="flex">
          <Link href={`/channel/${video.channelId}`}>
            <div className="flex-shrink-0 mr-3">
              <div className="w-10 h-10 rounded-full bg-gray-300 dark:bg-gray-700 overflow-hidden">
                <img src={channelAvatar} alt={channelName} className="w-full h-full object-cover" />
              </div>
            </div>
          </Link>
          <div>
            <Link href={`/video/${video.id}`}>
              <h3 className="font-medium line-clamp-2 group-hover:text-primary transition duration-300">
                {video.title}
              </h3>
            </Link>
            <Link href={`/channel/${video.channelId}`}>
              <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                {channelName}
                {isVerified && (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                )}
              </p>
            </Link>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {formatViews(video.views)} views • {timeAgo(video.createdAt)}
            </p>
          </div>
        </div>
      ) : (
        <div className="mt-1">
          <Link href={`/video/${video.id}`}>
            <h3 className="text-sm font-medium line-clamp-1 group-hover:text-primary transition duration-300">
              {video.title}
            </h3>
          </Link>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {formatViews(video.views)} views
          </p>
        </div>
      )}
    </div>
  );
}
