import { useState, useRef, useEffect } from "react";
import { Play, Pause, Volume2, VolumeX, Maximize, SkipBack, SkipForward } from "lucide-react";
import { Slider } from "@/components/ui/slider";

interface VideoPlayerProps {
  src: string;
  poster?: string;
  onEnded?: () => void;
  autoPlay?: boolean;
}

export function VideoPlayer({ src, poster, onEnded, autoPlay = false }: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(autoPlay);
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(0.7);
  const [isMuted, setIsMuted] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isBuffering, setIsBuffering] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Initialize video
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    
    const updateDuration = () => {
      setDuration(video.duration);
    };
    
    const handleWaiting = () => {
      setIsBuffering(true);
    };
    
    const handleCanPlay = () => {
      setIsBuffering(false);
    };
    
    video.addEventListener("loadedmetadata", updateDuration);
    video.addEventListener("waiting", handleWaiting);
    video.addEventListener("canplay", handleCanPlay);
    
    return () => {
      video.removeEventListener("loadedmetadata", updateDuration);
      video.removeEventListener("waiting", handleWaiting);
      video.removeEventListener("canplay", handleCanPlay);
    };
  }, [src]);
  
  // Handle progress updates
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    
    const updateProgress = () => {
      setCurrentTime(video.currentTime);
      setProgress((video.currentTime / video.duration) * 100);
    };
    
    video.addEventListener("timeupdate", updateProgress);
    
    return () => {
      video.removeEventListener("timeupdate", updateProgress);
    };
  }, []);
  
  // Handle auto-hiding controls
  useEffect(() => {
    const handleMovement = () => {
      setShowControls(true);
      
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
      
      controlsTimeoutRef.current = setTimeout(() => {
        if (isPlaying) {
          setShowControls(false);
        }
      }, 3000);
    };
    
    const playerElement = playerRef.current;
    if (playerElement) {
      playerElement.addEventListener("mousemove", handleMovement);
      playerElement.addEventListener("touchstart", handleMovement);
    }
    
    return () => {
      if (playerElement) {
        playerElement.removeEventListener("mousemove", handleMovement);
        playerElement.removeEventListener("touchstart", handleMovement);
      }
      
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [isPlaying]);
  
  // Format time (e.g., 1:23)
  const formatTime = (timeInSeconds: number) => {
    const minutes = Math.floor(timeInSeconds / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Toggle play/pause
  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    
    if (isPlaying) {
      video.pause();
    } else {
      video.play();
    }
    
    setIsPlaying(!isPlaying);
  };
  
  // Handle seeking
  const handleSeek = (value: number[]) => {
    const video = videoRef.current;
    if (!video) return;
    
    const newTime = (value[0] / 100) * video.duration;
    video.currentTime = newTime;
    setProgress(value[0]);
    setCurrentTime(newTime);
  };
  
  // Handle volume change
  const handleVolumeChange = (value: number[]) => {
    const video = videoRef.current;
    if (!video) return;
    
    const newVolume = value[0] / 100;
    video.volume = newVolume;
    setVolume(newVolume);
    
    if (newVolume === 0) {
      setIsMuted(true);
    } else if (isMuted) {
      setIsMuted(false);
    }
  };
  
  // Toggle mute
  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    
    video.muted = !isMuted;
    setIsMuted(!isMuted);
  };
  
  // Toggle fullscreen
  const toggleFullscreen = () => {
    const player = playerRef.current;
    if (!player) return;
    
    if (!document.fullscreenElement) {
      player.requestFullscreen()
        .then(() => setIsFullscreen(true))
        .catch(err => console.error('Fullscreen error:', err));
    } else {
      document.exitFullscreen()
        .then(() => setIsFullscreen(false))
        .catch(err => console.error('Exit fullscreen error:', err));
    }
  };
  
  // Skip forward/backward
  const skipTime = (seconds: number) => {
    const video = videoRef.current;
    if (!video) return;
    
    const newTime = Math.min(Math.max(video.currentTime + seconds, 0), video.duration);
    video.currentTime = newTime;
    setCurrentTime(newTime);
  };

  return (
    <div 
      ref={playerRef}
      className="video-container relative rounded-lg overflow-hidden bg-black aspect-video"
      onMouseEnter={() => setShowControls(true)}
      onMouseLeave={() => isPlaying && setShowControls(false)}
    >
      <video
        ref={videoRef}
        src={src}
        poster={poster}
        className="w-full h-full object-contain"
        onClick={togglePlay}
        onEnded={() => {
          setIsPlaying(false);
          if (onEnded) onEnded();
        }}
        autoPlay={autoPlay}
      />
      
      {/* Play/Pause center button (shows when paused) */}
      {!isPlaying && (
        <div className="absolute inset-0 flex items-center justify-center">
          <button 
            className="bg-primary/80 hover:bg-primary text-white w-16 h-16 rounded-full flex items-center justify-center transition duration-300"
            onClick={togglePlay}
          >
            <Play className="h-8 w-8 ml-1" />
          </button>
        </div>
      )}
      
      {/* Buffering indicator */}
      {isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20">
          <div className="animate-spin rounded-full h-10 w-10 border-4 border-primary border-t-transparent"></div>
        </div>
      )}
      
      {/* Controls overlay */}
      <div 
        className={`video-player-controls ${showControls ? 'opacity-100' : 'opacity-0'}`}
        onClick={e => e.stopPropagation()} /* Prevent clicks from toggling play */
      >
        {/* Progress bar */}
        <div className="w-full mb-2">
          <Slider
            value={[progress]}
            min={0}
            max={100}
            step={0.1}
            onValueChange={handleSeek}
            className="h-1.5"
          />
        </div>
        
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center">
            {/* Play/Pause */}
            <button className="text-white p-1.5" onClick={togglePlay}>
              {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            </button>
            
            {/* Skip backward */}
            <button className="text-white p-1.5" onClick={() => skipTime(-10)}>
              <SkipBack className="h-5 w-5" />
            </button>
            
            {/* Skip forward */}
            <button className="text-white p-1.5" onClick={() => skipTime(10)}>
              <SkipForward className="h-5 w-5" />
            </button>
            
            {/* Time display */}
            <span className="text-white text-sm mx-2">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          </div>
          
          <div className="flex items-center">
            {/* Volume */}
            <div className="hidden sm:flex items-center">
              <button className="text-white p-1.5" onClick={toggleMute}>
                {isMuted || volume === 0 ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
              </button>
              <div className="w-20 mx-2">
                <Slider
                  value={[isMuted ? 0 : volume * 100]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={handleVolumeChange}
                  className="h-1.5"
                />
              </div>
            </div>
            
            {/* Fullscreen */}
            <button className="text-white p-1.5" onClick={toggleFullscreen}>
              <Maximize className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
