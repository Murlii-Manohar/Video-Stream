import React, { useState } from "react";
import { VideoCategory } from "@shared/schema";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";

interface SingleCategorySelectorProps {
  value: string;
  onValueChange: (value: string) => void;
  placeholder?: string;
}

export function SingleCategorySelector({
  value,
  onValueChange,
  placeholder = "Select a category"
}: SingleCategorySelectorProps) {
  // Get all categories from VideoCategory object
  const categories = Object.values(VideoCategory);
  
  // Format category for display (e.g., "teen" -> "Teen")
  const formatCategory = (category: string): string => {
    return category.charAt(0).toUpperCase() + category.slice(1).toLowerCase();
  };
  
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {categories.map((category) => (
          <SelectItem key={category} value={category}>
            {formatCategory(category)}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

interface MultiCategorySelectorProps {
  values: string[];
  onChange: (values: string[]) => void;
  placeholder?: string;
  max?: number;
}

export function MultiCategorySelector({
  values = [],
  onChange,
  placeholder = "Select categories",
  max = 5
}: MultiCategorySelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const categories = Object.values(VideoCategory);

  // Format category for display
  const formatCategory = (category: string): string => {
    return category.charAt(0).toUpperCase() + category.slice(1).toLowerCase();
  };

  const handleToggleCategory = (category: string) => {
    if (values.includes(category)) {
      // Remove category if already selected
      onChange(values.filter(v => v !== category));
    } else if (values.length < max) {
      // Add category if under max limit
      onChange([...values, category]);
    }
  };

  const handleRemoveCategory = (category: string) => {
    onChange(values.filter(v => v !== category));
  };

  return (
    <div className="relative">
      <div 
        className="flex flex-wrap gap-1 min-h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2 cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        {values.length === 0 && (
          <span className="text-muted-foreground">{placeholder}</span>
        )}
        
        {values.map((category) => (
          <Badge key={category} variant="secondary" className="flex items-center space-x-1">
            <span>{formatCategory(category)}</span>
            <X 
              className="h-3 w-3 cursor-pointer hover:text-destructive" 
              onClick={(e) => {
                e.stopPropagation();
                handleRemoveCategory(category);
              }}
            />
          </Badge>
        ))}
      </div>
      
      {isOpen && (
        <div className="absolute z-50 w-full mt-1 rounded-md border bg-popover shadow-md max-h-60 overflow-auto">
          <div className="p-1">
            {categories.map((category) => (
              <div 
                key={category} 
                className="relative flex cursor-pointer select-none items-center rounded-sm py-1.5 px-2 text-sm outline-none hover:bg-accent hover:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50"
                onClick={() => handleToggleCategory(category)}
              >
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    checked={values.includes(category)}
                    id={`category-${category}`}
                    onCheckedChange={() => handleToggleCategory(category)}
                  />
                  <label 
                    htmlFor={`category-${category}`}
                    className="cursor-pointer"
                  >
                    {formatCategory(category)}
                  </label>
                </div>
              </div>
            ))}
          </div>
          
          {/* Max categories info */}
          <div className="border-t px-2 py-1.5 text-xs text-muted-foreground">
            {values.length}/{max} categories selected
          </div>
        </div>
      )}
      
      {/* Backdrop for closing the dropdown */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40" 
          onClick={() => setIsOpen(false)} 
        />
      )}
    </div>
  );
}

// Export default as alias for backward compatibility
export const CategorySelector = SingleCategorySelector;