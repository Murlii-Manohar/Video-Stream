import { Link } from "wouter";
import { Video } from "@shared/schema";

interface QuickieCardProps {
  video: Video;
}

export function QuickieCard({ video }: QuickieCardProps) {
  // Format view count
  const formatViews = (views: number) => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M`;
    } else if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K`;
    } else {
      return views.toString();
    }
  };
  
  // Format duration
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <div className="flex-shrink-0 w-56">
      <Link href={`/video/${video.id}`}>
        <div className="relative rounded-lg overflow-hidden aspect-[9/16] bg-gray-800 mb-2 hover:shadow-md transition duration-300 group">
          {video.thumbnail ? (
            <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gray-800 flex items-center justify-center">
              <span className="text-white text-xs opacity-70">No Thumbnail</span>
            </div>
          )}
          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="absolute top-2 right-2 bg-primary text-white px-1.5 py-0.5 rounded-full text-xs">Quickie</div>
          {video.duration > 0 && (
            <div className="video-duration">{formatDuration(video.duration)}</div>
          )}
        </div>
      </Link>
      <Link href={`/video/${video.id}`}>
        <h3 className="text-sm font-medium line-clamp-2 hover:text-primary transition-colors duration-300 dark:text-white">
          {video.title}
        </h3>
      </Link>
      <p className="text-xs text-gray-500 dark:text-gray-400">{formatViews(video.views)} views</p>
    </div>
  );
}
