import { Link } from "wouter";
import { Channel } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";

interface ChannelCardProps {
  channel: Channel;
}

export function ChannelCard({ channel }: ChannelCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [subscriberCount, setSubscriberCount] = useState(channel.subscriberCount);
  const [isSubscribed, setIsSubscribed] = useState(false);
  
  // Format subscriber count
  const formatSubscribers = (count: number) => {
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    } else if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    } else {
      return count.toString();
    }
  };
  
  // Check if user is subscribed to this channel
  const checkSubscriptionStatus = async () => {
    if (!user) return;
    
    try {
      const res = await fetch(`/api/channels/${channel.id}/subscription-status?userId=${user.id}`);
      if (res.ok) {
        const data = await res.json();
        setIsSubscribed(data.isSubscribed);
      }
    } catch (error) {
      console.error("Failed to check subscription status:", error);
    }
  };
  
  // Handle subscribe/unsubscribe
  const handleSubscription = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to subscribe to channels",
        variant: "destructive",
      });
      return;
    }
    
    setIsSubscribing(true);
    
    try {
      if (isSubscribed) {
        // Unsubscribe
        const res = await apiRequest("DELETE", `/api/channels/${channel.id}/subscribe`);
        const data = await res.json();
        
        setIsSubscribed(false);
        setSubscriberCount(data.subscriberCount);
        
        toast({
          title: "Unsubscribed",
          description: `You've unsubscribed from ${channel.name}`,
        });
      } else {
        // Subscribe
        const res = await apiRequest("POST", `/api/channels/${channel.id}/subscribe`);
        const data = await res.json();
        
        setIsSubscribed(true);
        setSubscriberCount(data.subscriberCount);
        
        toast({
          title: "Subscribed!",
          description: `You're now subscribed to ${channel.name}`,
        });
      }
      
      // Invalidate user subscriptions query
      queryClient.invalidateQueries({ queryKey: ['/api/user/subscriptions'] });
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update subscription",
        variant: "destructive",
      });
    } finally {
      setIsSubscribing(false);
    }
  };
  
  return (
    <div className="text-center">
      <Link href={`/channel/${channel.id}`}>
        <div className="w-20 h-20 mx-auto rounded-full bg-gray-300 dark:bg-gray-700 overflow-hidden mb-2 ring-2 ring-primary hover:shadow-lg transition duration-300">
          {channel.banner ? (
            <img src={channel.banner} alt={channel.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-primary/20 flex items-center justify-center">
              <span className="font-bold text-xl text-primary">
                {channel.name.charAt(0).toUpperCase()}
              </span>
            </div>
          )}
        </div>
      </Link>
      <Link href={`/channel/${channel.id}`}>
        <h3 className="font-medium hover:text-primary transition-colors duration-300">{channel.name}</h3>
      </Link>
      <p className="text-xs text-gray-500 dark:text-gray-400">{formatSubscribers(subscriberCount)} subs</p>
      <Button
        variant={isSubscribed ? "outline" : "default"}
        size="sm"
        className={`mt-2 w-full ${isSubscribed ? 'border-primary text-primary hover:bg-primary/10' : 'bg-primary hover:bg-accent'}`}
        onClick={handleSubscription}
        disabled={isSubscribing}
      >
        {isSubscribing ? (
          <span className="flex items-center">
            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Processing
          </span>
        ) : isSubscribed ? "Subscribed" : "Subscribe"}
      </Button>
    </div>
  );
}
