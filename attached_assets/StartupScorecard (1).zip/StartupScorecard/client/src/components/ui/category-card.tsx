import { Link } from "wouter";

interface CategoryCardProps {
  title: string;
  image: string;
  link: string;
}

export function CategoryCard({ title, image, link }: CategoryCardProps) {
  return (
    <Link href={link}>
      <div className="category-card relative rounded-lg overflow-hidden aspect-video bg-gray-800 hover:shadow-lg transition duration-300 cursor-pointer">
        <img src={image} alt={title} className="w-full h-full object-cover opacity-80" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end">
          <p className="text-white font-medium p-3">{title}</p>
        </div>
      </div>
    </Link>
  );
}
