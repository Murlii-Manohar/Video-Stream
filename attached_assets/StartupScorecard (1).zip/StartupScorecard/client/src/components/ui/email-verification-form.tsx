import React, { useState, useEffect } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

// Form validation schemas
const emailSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
});

const verificationSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  code: z.string().length(6, "Verification code must be 6 digits"),
});

type EmailFormValues = z.infer<typeof emailSchema>;
type VerificationFormValues = z.infer<typeof verificationSchema>;

interface EmailVerificationFormProps {
  onVerificationComplete: (email: string) => void;
  initialEmail?: string;
}

export function EmailVerificationForm({ onVerificationComplete, initialEmail = "" }: EmailVerificationFormProps) {
  const [otpSent, setOtpSent] = useState<boolean>(false);
  const [verificationEmail, setVerificationEmail] = useState<string>(initialEmail);
  const [isRequestingCode, setIsRequestingCode] = useState(false);
  const [isVerifyingCode, setIsVerifyingCode] = useState(false);
  const [countdown, setCountdown] = useState<number>(0);
  const [open, setOpen] = useState<boolean>(true);
  const { toast } = useToast();

  // Effect for countdown timer
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    
    if (countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
    }
    
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [countdown]);

  // Form for verification code entry
  const verificationForm = useForm<VerificationFormValues>({
    resolver: zodResolver(verificationSchema),
    defaultValues: {
      email: verificationEmail,
      code: "",
    },
  });

  // Update default value when initial email changes
  useEffect(() => {
    if (initialEmail) {
      setVerificationEmail(initialEmail);
      verificationForm.setValue("email", initialEmail);
    }
  }, [initialEmail, verificationForm]);

  // Send verification code
  const sendVerificationCode = async () => {
    setIsRequestingCode(true);
    try {
      const response = await apiRequest("POST", "/api/send-verification-code", { email: verificationEmail });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to send verification code");
      }
      
      // Mark OTP as sent
      setOtpSent(true);
      
      // Start the countdown timer for 60 seconds (1 minute)
      setCountdown(60);
      
      toast({
        title: "Verification code sent",
        description: "A verification code has been sent to your email address. Please check your inbox.",
        duration: 5000,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send verification code",
        variant: "destructive",
      });
    } finally {
      setIsRequestingCode(false);
    }
  };

  // Handle verification code submission
  const onVerificationSubmit = async (data: VerificationFormValues) => {
    setIsVerifyingCode(true);
    try {
      const response = await apiRequest("POST", "/api/verify-email-code", data);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to verify code");
      }
      
      toast({
        title: "Success",
        description: "Your email has been verified. Your account is being created.",
      });
      
      // Notify parent component that verification is complete
      onVerificationComplete(data.email);
      
      // Close the dialog
      setOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to verify code",
        variant: "destructive",
      });
    } finally {
      setIsVerifyingCode(false);
    }
  };

  // Handle resending verification code
  const handleResendCode = async () => {
    await sendVerificationCode();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Verify Your Email</DialogTitle>
          <DialogDescription>
            This verification is required to create your account.
          </DialogDescription>
        </DialogHeader>
        
        <Card className="w-full border-0 shadow-none">
          <CardHeader className="px-0 pt-0">
            <p className="text-sm text-muted-foreground">
              We need to verify your email address: <span className="font-medium">{verificationEmail}</span>
            </p>
          </CardHeader>
          <CardContent className="px-0">
            {!otpSent ? (
              <div className="flex flex-col gap-4">
                <p className="text-sm">
                  Click the button below to send a verification code to your email address.
                </p>
                <Button 
                  onClick={sendVerificationCode} 
                  disabled={isRequestingCode}
                  className="w-full"
                >
                  {isRequestingCode ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    "Send OTP"
                  )}
                </Button>
              </div>
            ) : (
              <Form {...verificationForm}>
                <form onSubmit={verificationForm.handleSubmit(onVerificationSubmit)} className="space-y-4">
                  <FormField
                    control={verificationForm.control}
                    name="code"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Verification Code</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="123456" 
                            {...field} 
                            maxLength={6}
                            minLength={6}
                            className="text-center tracking-widest text-lg font-medium"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full" disabled={isVerifyingCode}>
                    {isVerifyingCode ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify"
                    )}
                  </Button>
                </form>
              </Form>
            )}
          </CardContent>
          
          {otpSent && (
            <CardFooter className="flex flex-col gap-2 px-0">
              <div className="text-sm text-center text-muted-foreground">
                Didn't receive the code?
              </div>
              <div className="flex justify-center items-center gap-2">
                {countdown > 0 ? (
                  <div className="text-sm text-muted-foreground">
                    Resend code in {countdown} seconds
                  </div>
                ) : (
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={handleResendCode}
                    disabled={isRequestingCode || countdown > 0}
                  >
                    {isRequestingCode ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Resending...
                      </>
                    ) : (
                      "Resend Code"
                    )}
                  </Button>
                )}
              </div>
            </CardFooter>
          )}
        </Card>
      </DialogContent>
    </Dialog>
  );
}