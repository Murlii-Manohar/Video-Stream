import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";

interface AgeVerificationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAccept: () => void;
  onReject: () => void;
}

export function AgeVerificationModal({
  open,
  onOpenChange,
  onAccept,
  onReject
}: AgeVerificationModalProps) {
  const { user, verifyAgeMutation } = useAuth();
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  
  // Handle accept button click
  const handleAccept = () => {
    if (user) {
      verifyAgeMutation.mutate();
    }
    onAccept();
    onOpenChange(false);
  };
  
  // Handle reject button click
  const handleReject = () => {
    onReject();
    onOpenChange(false);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">Age Verification</DialogTitle>
          <DialogDescription className="text-center">
            This website contains adult content and is only intended for adults aged 18 or over.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <p className="text-center">
            By entering, you confirm that you are at least 18 years old or the age of majority in your location, whichever is greater.
          </p>
          
          <div className="flex items-start space-x-2 mt-4">
            <input
              type="checkbox"
              id="terms"
              className="mt-1"
              checked={agreedToTerms}
              onChange={(e) => setAgreedToTerms(e.target.checked)}
            />
            <label htmlFor="terms" className="text-sm">
              I certify that I am at least 18 years old and agree to the Terms of Service and Privacy Policy.
            </label>
          </div>
        </div>
        
        <DialogFooter className="flex flex-col sm:flex-row sm:justify-center sm:space-x-4">
          <Button
            variant="outline"
            onClick={handleReject}
            className="mb-2 sm:mb-0"
          >
            Exit
          </Button>
          <Button
            onClick={handleAccept}
            disabled={!agreedToTerms}
            className="bg-primary hover:bg-accent"
          >
            I am 18 or older
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
