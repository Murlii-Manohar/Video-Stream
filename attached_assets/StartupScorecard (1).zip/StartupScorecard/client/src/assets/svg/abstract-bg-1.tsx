import React from "react";

export const AbstractBg1: React.FC = () => {
  return (
    <svg
      viewBox="0 0 1000 1000"
      xmlns="http://www.w3.org/2000/svg"
      className="w-full h-full object-cover"
    >
      <defs>
        <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="currentColor" stopOpacity="0.1" />
          <stop offset="100%" stopColor="currentColor" stopOpacity="0.05" />
        </linearGradient>
      </defs>
      <path
        d="M0,0 L1000,0 L1000,1000 L0,1000 Z"
        fill="url(#grad1)"
      />
      <g fill="currentColor" opacity="0.1">
        <circle cx="150" cy="150" r="100" />
        <circle cx="850" cy="150" r="80" />
        <circle cx="150" cy="850" r="120" />
        <circle cx="850" cy="850" r="70" />
      </g>
      <path
        d="M0,500 C250,400 350,650 500,500 C650,350 750,550 1000,500 L1000,1000 L0,1000 Z"
        fill="currentColor"
        opacity="0.07"
      />
      <path
        d="M0,700 C200,650 300,800 500,700 C700,600 800,750 1000,700 L1000,1000 L0,1000 Z"
        fill="currentColor"
        opacity="0.05"
      />
      <g stroke="currentColor" strokeWidth="2" opacity="0.1" fill="none">
        <path d="M100,100 L900,900" />
        <path d="M900,100 L100,900" />
        <path d="M500,0 L500,1000" />
        <path d="M0,500 L1000,500" />
      </g>
    </svg>
  );
};

export default AbstractBg1;
