import React from "react";

export const AbstractBg2: React.FC = () => {
  return (
    <svg
      viewBox="0 0 1000 1000"
      xmlns="http://www.w3.org/2000/svg"
      className="w-full h-full object-cover"
    >
      <defs>
        <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.1" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0.05" />
        </linearGradient>
        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path
            d="M 40 0 L 0 0 0 40"
            fill="none"
            stroke="currentColor"
            strokeWidth="1"
            opacity="0.1"
          />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#grad2)" />
      <rect width="100%" height="100%" fill="url(#grid)" />
      
      {/* Abstract curved lines */}
      <path
        d="M-100,300 C200,100 300,800 600,600 C900,400 900,100 1100,300"
        fill="none"
        stroke="var(--primary)"
        strokeWidth="3"
        opacity="0.2"
      />
      <path
        d="M-100,500 C100,300 400,900 700,700 C1000,500 900,200 1100,400"
        fill="none"
        stroke="var(--primary)"
        strokeWidth="3"
        opacity="0.15"
      />
      
      {/* Scattered dots */}
      <g fill="var(--primary)" opacity="0.2">
        <circle cx="150" cy="150" r="5" />
        <circle cx="150" cy="250" r="5" />
        <circle cx="250" cy="150" r="5" />
        <circle cx="450" cy="350" r="5" />
        <circle cx="550" cy="150" r="5" />
        <circle cx="650" cy="350" r="5" />
        <circle cx="750" cy="550" r="5" />
        <circle cx="850" cy="150" r="5" />
        <circle cx="150" cy="450" r="5" />
        <circle cx="350" cy="650" r="5" />
        <circle cx="550" cy="750" r="5" />
        <circle cx="750" cy="350" r="5" />
        <circle cx="850" cy="650" r="5" />
        <circle cx="350" cy="850" r="5" />
        <circle cx="650" cy="850" r="5" />
        <circle cx="850" cy="450" r="5" />
      </g>
      
      {/* Larger circles */}
      <circle cx="200" cy="200" r="100" fill="var(--primary)" opacity="0.05" />
      <circle cx="800" cy="800" r="150" fill="var(--primary)" opacity="0.05" />
      <circle cx="700" cy="200" r="80" fill="var(--primary)" opacity="0.05" />
      <circle cx="200" cy="700" r="120" fill="var(--primary)" opacity="0.05" />
    </svg>
  );
};

export default AbstractBg2;
