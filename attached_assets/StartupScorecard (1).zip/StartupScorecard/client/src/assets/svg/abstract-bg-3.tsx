import React from "react";

export const AbstractBg3: React.FC = () => {
  return (
    <svg
      viewBox="0 0 1000 1000"
      xmlns="http://www.w3.org/2000/svg"
      className="w-full h-full object-cover"
    >
      <defs>
        <linearGradient id="grad3" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--chart-1)" stopOpacity="0.1" />
          <stop offset="50%" stopColor="var(--chart-3)" stopOpacity="0.05" />
          <stop offset="100%" stopColor="var(--chart-5)" stopOpacity="0.1" />
        </linearGradient>
      </defs>
      <rect width="100%" height="100%" fill="url(#grad3)" />
      
      {/* Dashboard-like grid pattern */}
      <g stroke="currentColor" strokeWidth="1" opacity="0.1">
        <line x1="0" y1="200" x2="1000" y2="200" />
        <line x1="0" y1="400" x2="1000" y2="400" />
        <line x1="0" y1="600" x2="1000" y2="600" />
        <line x1="0" y1="800" x2="1000" y2="800" />
        <line x1="200" y1="0" x2="200" y2="1000" />
        <line x1="400" y1="0" x2="400" y2="1000" />
        <line x1="600" y1="0" x2="600" y2="1000" />
        <line x1="800" y1="0" x2="800" y2="1000" />
      </g>
      
      {/* Abstract dashboard chart elements */}
      {/* Bar chart */}
      <g transform="translate(100, 700)" opacity="0.2">
        <rect x="0" y="0" width="30" height="100" fill="var(--chart-1)" rx="4" />
        <rect x="40" y="-50" width="30" height="150" fill="var(--chart-1)" rx="4" />
        <rect x="80" y="-100" width="30" height="200" fill="var(--chart-1)" rx="4" />
        <rect x="120" y="-30" width="30" height="130" fill="var(--chart-1)" rx="4" />
        <rect x="160" y="-80" width="30" height="180" fill="var(--chart-1)" rx="4" />
      </g>
      
      {/* Line chart */}
      <path 
        d="M300,600 C350,500 400,550 450,450 C500,350 550,400 600,300 C650,250 700,350 750,250" 
        stroke="var(--chart-2)" 
        strokeWidth="3" 
        fill="none" 
        opacity="0.2" 
      />
      
      {/* Area chart */}
      <path 
        d="M300,800 C350,700 400,750 450,650 C500,550 550,600 600,500 C650,450 700,550 750,450 L750,800 Z" 
        fill="var(--chart-3)" 
        opacity="0.1" 
      />
      
      {/* Pie chart */}
      <g transform="translate(800, 300)">
        <circle cx="0" cy="0" r="100" fill="none" stroke="currentColor" strokeWidth="1" opacity="0.1" />
        <path 
          d="M0,0 L100,0 A100,100 0 0,1 70.7,70.7 Z" 
          fill="var(--chart-4)" 
          opacity="0.2" 
        />
        <path 
          d="M0,0 L70.7,70.7 A100,100 0 0,1 0,100 Z" 
          fill="var(--chart-2)" 
          opacity="0.2" 
        />
        <path 
          d="M0,0 L0,100 A100,100 0 0,1 -70.7,70.7 Z" 
          fill="var(--chart-5)" 
          opacity="0.2" 
        />
        <path 
          d="M0,0 L-70.7,70.7 A100,100 0 0,1 -100,0 Z" 
          fill="var(--chart-3)" 
          opacity="0.2" 
        />
        <path 
          d="M0,0 L-100,0 A100,100 0 0,1 -70.7,-70.7 Z" 
          fill="var(--chart-1)" 
          opacity="0.2" 
        />
        <path 
          d="M0,0 L-70.7,-70.7 A100,100 0 0,1 0,-100 Z" 
          fill="var(--chart-4)" 
          opacity="0.2" 
        />
        <path 
          d="M0,0 L0,-100 A100,100 0 0,1 100,0 Z" 
          fill="var(--chart-5)" 
          opacity="0.2" 
        />
      </g>
      
      {/* Abstract decorative elements */}
      <circle cx="150" cy="150" r="30" fill="var(--chart-1)" opacity="0.1" />
      <circle cx="850" cy="850" r="50" fill="var(--chart-5)" opacity="0.1" />
      <path 
        d="M50,450 L150,450 L150,550 L50,550 Z" 
        stroke="var(--chart-3)" 
        strokeWidth="2" 
        fill="none" 
        opacity="0.2" 
      />
      <path 
        d="M850,150 L950,150 L950,250 L850,250 Z" 
        stroke="var(--chart-2)" 
        strokeWidth="2" 
        fill="none" 
        opacity="0.2" 
      />
    </svg>
  );
};

export default AbstractBg3;
