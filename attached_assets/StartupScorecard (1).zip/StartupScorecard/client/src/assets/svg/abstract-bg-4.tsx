import React from "react";

export const AbstractBg4: React.FC = () => {
  return (
    <svg
      viewBox="0 0 1000 1000"
      xmlns="http://www.w3.org/2000/svg"
      className="w-full h-full object-cover"
    >
      <defs>
        <linearGradient id="grad4" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.2" />
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0.2" />
        </linearGradient>
        <radialGradient id="radial1" cx="30%" cy="30%" r="50%" fx="30%" fy="30%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.3" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="radial2" cx="70%" cy="70%" r="50%" fx="70%" fy="70%">
          <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.3" />
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0" />
        </radialGradient>
      </defs>
      
      {/* Background */}
      <rect width="100%" height="100%" fill="url(#grad4)" />
      
      {/* Radial gradient overlays */}
      <rect width="100%" height="100%" fill="url(#radial1)" />
      <rect width="100%" height="100%" fill="url(#radial2)" />
      
      {/* Abstract wave patterns */}
      <path
        d="M0,300 C100,250 200,350 300,300 C400,250 500,350 600,300 C700,250 800,350 900,300 C1000,250 1100,350 1200,300 L1200,1000 L0,1000 Z"
        fill="var(--primary)"
        opacity="0.1"
      />
      <path
        d="M0,400 C100,350 200,450 300,400 C400,350 500,450 600,400 C700,350 800,450 900,400 C1000,350 1100,450 1200,400 L1200,1000 L0,1000 Z"
        fill="var(--accent)"
        opacity="0.1"
      />
      <path
        d="M0,500 C100,450 200,550 300,500 C400,450 500,550 600,500 C700,450 800,550 900,500 C1000,450 1100,550 1200,500 L1200,1000 L0,1000 Z"
        fill="var(--primary)"
        opacity="0.1"
      />
      
      {/* Decorative geometric elements */}
      <g opacity="0.2">
        <circle cx="200" cy="200" r="50" fill="var(--primary)" />
        <circle cx="800" cy="300" r="30" fill="var(--accent)" />
        <circle cx="300" cy="700" r="40" fill="var(--accent)" />
        <circle cx="700" cy="600" r="60" fill="var(--primary)" />
      </g>
      
      {/* Pattern elements */}
      <g fill="none" stroke="currentColor" strokeWidth="1" opacity="0.1">
        {/* Horizontal lines */}
        <line x1="0" y1="100" x2="1000" y2="100" />
        <line x1="0" y1="200" x2="1000" y2="200" />
        <line x1="0" y1="300" x2="1000" y2="300" />
        <line x1="0" y1="400" x2="1000" y2="400" />
        <line x1="0" y1="500" x2="1000" y2="500" />
        <line x1="0" y1="600" x2="1000" y2="600" />
        <line x1="0" y1="700" x2="1000" y2="700" />
        <line x1="0" y1="800" x2="1000" y2="800" />
        <line x1="0" y1="900" x2="1000" y2="900" />
        
        {/* Vertical lines */}
        <line x1="100" y1="0" x2="100" y2="1000" />
        <line x1="200" y1="0" x2="200" y2="1000" />
        <line x1="300" y1="0" x2="300" y2="1000" />
        <line x1="400" y1="0" x2="400" y2="1000" />
        <line x1="500" y1="0" x2="500" y2="1000" />
        <line x1="600" y1="0" x2="600" y2="1000" />
        <line x1="700" y1="0" x2="700" y2="1000" />
        <line x1="800" y1="0" x2="800" y2="1000" />
        <line x1="900" y1="0" x2="900" y2="1000" />
      </g>
      
      {/* Abstract design elements */}
      <path
        d="M-100,100 C200,-100 300,400 600,300 C900,200 900,-100 1100,100"
        fill="none"
        stroke="var(--primary)"
        strokeWidth="3"
        opacity="0.1"
      />
      <path
        d="M-100,300 C100,100 400,600 700,500 C1000,400 900,100 1100,300"
        fill="none"
        stroke="var(--accent)"
        strokeWidth="3"
        opacity="0.1"
      />
    </svg>
  );
};

export default AbstractBg4;
