import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import VideoPage from "@/pages/video-page";
import UploadPage from "@/pages/upload-page.new";
import DashboardPage from "@/pages/dashboard-page";
import ChannelPage from "@/pages/channel-page";
import ChannelDashboardPage from "@/pages/channel-dashboard-page";
import PopularPage from "@/pages/popular-page";
import RecentPage from "@/pages/recent-page";
import PremiumPage from "@/pages/premium-page";
import HistoryPage from "@/pages/history-page";
import QuickiesPage from "@/pages/quickies-page";
import CategoryPage from "@/pages/category-page";
import ModerationDashboard from "@/pages/moderation-dashboard";
import AdminPanel from "@/pages/admin-panel";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "./hooks/use-auth";
import { ThemeProvider } from "./hooks/use-theme";
import Layout from "@/components/layout/layout";

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/video/:id" component={VideoPage} />
      <Route path="/popular" component={PopularPage} />
      <Route path="/recent" component={RecentPage} />
      <Route path="/premium" component={PremiumPage} />
      <Route path="/quickies" component={QuickiesPage} />
      <Route path="/category/:category" component={CategoryPage} />
      <ProtectedRoute path="/history" component={HistoryPage} />
      <ProtectedRoute path="/upload" component={UploadPage} />
      <ProtectedRoute path="/dashboard" component={DashboardPage} />
      <ProtectedRoute path="/channel-dashboard" component={ChannelDashboardPage} />
      <Route path="/channel/:id" component={ChannelPage} />
      <Route path="/moderation" component={ModerationDashboard} />
      <Route path="/admin" component={AdminPanel} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthProvider>
          <TooltipProvider>
            <Layout>
              <Router />
            </Layout>
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
