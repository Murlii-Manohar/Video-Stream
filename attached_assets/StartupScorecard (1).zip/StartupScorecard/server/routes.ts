import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";
import {
  insertChannelSchema,
  insertVideoSchema,
  insertCommentSchema,
  insertLikeSchema,
  insertSubscriptionSchema,
  ModerationStatus,
  ContentType,
  ReportStatus
} from "@shared/schema";

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for video uploads
const storage_config = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});

// Add file type filter function
const fileFilter = (req: any, file: any, cb: any) => {
  if (file.fieldname === "video") {
    // Allow video formats
    const filetypes = /mp4|mov|avi|wmv|webm|mkv/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      return cb(new Error("Only video files are allowed"));
    }
  } else if (file.fieldname === "thumbnail") {
    // Allow image formats for thumbnails
    const filetypes = /jpeg|jpg|png|gif|webp/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = /image\//.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      return cb(new Error("Only image files are allowed for thumbnails"));
    }
  } else if (file.fieldname === "banner") {
    // Allow image formats for channel banners
    const filetypes = /jpeg|jpg|png|gif|webp/;
    const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = /image\//.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      return cb(new Error("Only image files are allowed for channel banners"));
    }
  }
  
  // Default case - reject
  return cb(new Error("Unexpected field"));
};

const upload = multer({
  storage: storage_config,
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB max
  fileFilter: fileFilter
});

// Helper function to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "You must be logged in" });
}

// Middleware to check if the user is an admin
function isAdminUser(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated() && req.user.isAdmin) {
    return next();
  }
  res.status(403).json({ message: "Access denied: Admin privileges required" });
}

// Helper function to check if user is age verified
function isAgeVerified(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated() && req.user.isVerified) {
    return next();
  }
  res.status(403).json({ message: "Age verification required" });
}

// Email verification session check
function isEmailVerified(req: Request, res: Response, next: Function) {
  // If there's no email in the request body, we can't check verification
  if (!req.body.email) {
    return res.status(400).json({ message: "Email is required" });
  }
  
  // Check if the email is in the verified list
  const isVerified = req.session.verifiedEmails && 
                    req.session.verifiedEmails.includes(req.body.email);
  
  if (isVerified) {
    next();
  } else {
    res.status(403).json({ 
      message: "Email verification required",
      needVerification: true
    });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // Serve static files from uploads directory
  app.use("/uploads", express.static(uploadsDir));

  // Channel routes
  app.post("/api/channels", isAuthenticated, async (req, res) => {
    try {
      const channelData = insertChannelSchema.parse({
        ...req.body,
        userId: req.user.id,
      });
      
      // Check if user already has a channel
      const existingChannel = await storage.getChannelByUserId(req.user.id);
      if (existingChannel) {
        return res.status(400).json({ message: "You already have a channel" });
      }
      
      const channel = await storage.createChannel(channelData);
      res.status(201).json(channel);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      } else {
        res.status(500).json({ message: "Failed to create channel" });
      }
    }
  });

  app.get("/api/channels", async (req, res) => {
    try {
      const channels = await storage.getChannels();
      res.json(channels);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch channels" });
    }
  });

  app.get("/api/channels/:id", async (req, res) => {
    try {
      const channelId = parseInt(req.params.id);
      const channel = await storage.getChannel(channelId);
      
      if (!channel) {
        return res.status(404).json({ message: "Channel not found" });
      }
      
      res.json(channel);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch channel" });
    }
  });

  app.get("/api/channels/:id/videos", async (req, res) => {
    try {
      const channelId = parseInt(req.params.id);
      const videos = await storage.getVideosByChannel(channelId);
      res.json(videos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch channel videos" });
    }
  });

  // Configure upload for channel banners
  const channelUpload = upload.fields([
    { name: 'banner', maxCount: 1 }
  ]);

  app.patch("/api/channels/:id", isAuthenticated, channelUpload, async (req, res) => {
    try {
      const channelId = parseInt(req.params.id);
      const channel = await storage.getChannel(channelId);
      
      if (!channel) {
        return res.status(404).json({ message: "Channel not found" });
      }
      
      if (channel.userId !== req.user.id) {
        return res.status(403).json({ message: "You don't have permission to update this channel" });
      }
      
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      let bannerPath = channel.banner; // Keep existing by default
      
      // If a new banner was uploaded
      if (files && files.banner && files.banner[0]) {
        bannerPath = `/uploads/${files.banner[0].filename}`;
      }
      
      const updatedChannelData = {
        ...req.body,
        banner: bannerPath
      };
      
      const updatedChannel = await storage.updateChannel(channelId, updatedChannelData);
      res.json(updatedChannel);
    } catch (error) {
      console.error('Channel update error:', error);
      res.status(500).json({ message: error instanceof Error ? error.message : "Failed to update channel" });
    }
  });

  // Video routes
  // Configure multer for thumbnail uploads
  const thumbnailUpload = multer({
    storage: storage_config,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max for thumbnails
    fileFilter: (req, file, cb) => {
      // Allow image formats
      const filetypes = /jpeg|jpg|png|gif|webp/;
      const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
      const mimetype = filetypes.test(file.mimetype);
      
      if (mimetype && extname) {
        return cb(null, true);
      } else {
        cb(new Error("Only image files are allowed for thumbnails!"));
      }
    }
  });

  // Process video uploads with both video file and thumbnail file
  const uploadFiles = upload.fields([
    { name: 'video', maxCount: 1 },
    { name: 'thumbnail', maxCount: 1 }
  ]);

  app.post("/api/videos", isAuthenticated, isAgeVerified, uploadFiles, async (req, res) => {
    try {
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      if (!files || !files.video || !files.video[0]) {
        return res.status(400).json({ message: "No video file uploaded" });
      }
      
      const videoFile = files.video[0];
      let thumbnailPath = null;
      
      if (files.thumbnail && files.thumbnail[0]) {
        thumbnailPath = `/uploads/${files.thumbnail[0].filename}`;
      }
      
      // Get user's channel
      const channel = await storage.getChannelByUserId(req.user.id);
      if (!channel) {
        return res.status(400).json({ message: "You need to create a channel first" });
      }
      
      const isQuickie = req.body.isQuickie === 'true';
      const duration = parseInt(req.body.duration) || 0;
      
      // Validate Quickie length (max 2 minutes = 120 seconds)
      if (isQuickie && duration > 120) {
        return res.status(400).json({ 
          message: "Quickie videos must be 2 minutes or shorter. Please trim your video or upload it as a regular video." 
        });
      }
      
      // Log the received data for debugging
      console.log("Received video data:", {
        title: req.body.title,
        isQuickie,
        duration: `${Math.floor(duration / 60)}:${Math.floor(duration % 60).toString().padStart(2, '0')}`,
        hasThumbnail: !!thumbnailPath,
        isPremium: req.body.isPremium === 'true',
        filetype: videoFile.mimetype
      });
      
      const videoData = {
        ...req.body,
        videoPath: `/uploads/${videoFile.filename}`,
        thumbnail: thumbnailPath,
        channelId: channel.id,
        tags: req.body.tags ? req.body.tags.split(',') : [],
        isQuickie: isQuickie,
        isPremium: req.body.isPremium === 'true',
        duration: duration,
        views: 0, // Initialize with zero views
        likes: 0, // Initialize with zero likes
        createdAt: new Date().toISOString() // Set creation date
      };
      
      const parsedData = insertVideoSchema.parse(videoData);
      const video = await storage.createVideo(parsedData);
      
      res.status(201).json(video);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      } else {
        console.error('Video upload error:', error);
        res.status(500).json({ message: error instanceof Error ? error.message : "Failed to upload video" });
      }
    }
  });

  app.get("/api/videos", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const videos = await storage.getVideos(limit);
      res.json(videos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch videos" });
    }
  });

  app.get("/api/videos/trending", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const videos = await storage.getTrendingVideos(limit);
      res.json(videos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trending videos" });
    }
  });

  app.get("/api/videos/quickies", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const quickies = await storage.getQuickies(limit);
      res.json(quickies);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quickies" });
    }
  });
  
  // API route for videos by category
  app.get("/api/videos/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const videos = await storage.getVideosByCategory(category, limit);
      res.json(videos);
    } catch (error) {
      console.error(`Error fetching videos for category ${req.params.category}:`, error);
      res.status(500).json({ message: "Failed to fetch videos for this category" });
    }
  });

  app.get("/api/videos/popular", async (req, res) => {
    try {
      // Get videos sorted by views/likes
      const videos = await storage.getVideos();
      const popularVideos = videos
        .sort((a, b) => (b.views || 0) - (a.views || 0)) // Sort by views
        .slice(0, 20); // Limit to 20 videos
      res.json(popularVideos);
    } catch (error) {
      console.error("Error fetching popular videos:", error);
      res.status(500).json({ message: "Failed to fetch popular videos" });
    }
  });

  app.get("/api/videos/recent", async (req, res) => {
    try {
      // Get videos sorted by creation date
      const videos = await storage.getVideos();
      const recentVideos = videos
        .sort((a, b) => {
          const dateA = new Date(a.createdAt || 0);
          const dateB = new Date(b.createdAt || 0);
          return dateB.getTime() - dateA.getTime();
        })
        .slice(0, 20); // Limit to 20 videos
      res.json(recentVideos);
    } catch (error) {
      console.error("Error fetching recent videos:", error);
      res.status(500).json({ message: "Failed to fetch recent videos" });
    }
  });

  app.get("/api/videos/premium", isAuthenticated, isAgeVerified, async (req, res) => {
    // Check if user is premium
    const user = await storage.getUser(req.user!.id);
    if (!user?.isPremium) {
      return res.status(403).json({ message: "Premium subscription required" });
    }

    try {
      // Get premium videos
      const videos = await storage.getVideos();
      const premiumVideos = videos
        .filter(video => video.isPremium) // Filter premium videos
        .slice(0, 20); // Limit to 20 videos
      res.json(premiumVideos);
    } catch (error) {
      console.error("Error fetching premium videos:", error);
      res.status(500).json({ message: "Failed to fetch premium videos" });
    }
  });

  app.get("/api/videos/:id", async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const video = await storage.getVideo(videoId);
      
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      
      // Increment view count
      await storage.incrementVideoViews(videoId);
      
      res.json(video);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch video" });
    }
  });

  // Comment routes
  app.post("/api/videos/:id/comments", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      
      const commentData = insertCommentSchema.parse({
        ...req.body,
        videoId,
        userId: req.user.id
      });
      
      const comment = await storage.createComment(commentData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      } else {
        res.status(500).json({ message: "Failed to add comment" });
      }
    }
  });

  app.get("/api/videos/:id/comments", async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const comments = await storage.getCommentsByVideo(videoId);
      
      // For each comment, get the user info
      const commentsWithUser = await Promise.all(
        comments.map(async (comment) => {
          const user = await storage.getUser(comment.userId);
          return {
            ...comment,
            user: user ? {
              id: user.id,
              username: user.username,
              avatar: user.avatar
            } : null
          };
        })
      );
      
      res.json(commentsWithUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch comments" });
    }
  });

  // Like routes
  app.post("/api/videos/:id/like", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const { isLike } = req.body;
      
      const likeData = insertLikeSchema.parse({
        videoId,
        userId: req.user.id,
        isLike: isLike !== undefined ? isLike : true
      });
      
      const like = await storage.createLike(likeData);
      
      // Get updated video like counts
      const video = await storage.getVideo(videoId);
      
      res.status(201).json({
        like,
        videoLikes: video?.likes || 0,
        videoDislikes: video?.dislikes || 0
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      } else {
        res.status(500).json({ message: "Failed to like video" });
      }
    }
  });

  app.delete("/api/videos/:id/like", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      
      await storage.deleteLike(req.user.id, videoId);
      
      // Get updated video like counts
      const video = await storage.getVideo(videoId);
      
      res.json({
        success: true,
        videoLikes: video?.likes || 0,
        videoDislikes: video?.dislikes || 0
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove like" });
    }
  });
  
  app.get("/api/videos/:id/like/status", isAuthenticated, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const like = await storage.getLike(req.user.id, videoId);
      
      if (!like) {
        res.json({ exists: false, isLike: null });
      } else {
        res.json({ exists: true, isLike: like.isLike });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to check like status" });
    }
  });

  // Subscription routes
  app.post("/api/channels/:id/subscribe", isAuthenticated, async (req, res) => {
    try {
      const channelId = parseInt(req.params.id);
      
      const subscriptionData = insertSubscriptionSchema.parse({
        channelId,
        userId: req.user.id
      });
      
      const subscription = await storage.createSubscription(subscriptionData);
      
      // Get updated channel subscriber count
      const channel = await storage.getChannel(channelId);
      
      res.status(201).json({
        subscription,
        subscriberCount: channel?.subscriberCount || 0
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      } else {
        res.status(500).json({ message: "Failed to subscribe to channel" });
      }
    }
  });

  app.delete("/api/channels/:id/subscribe", isAuthenticated, async (req, res) => {
    try {
      const channelId = parseInt(req.params.id);
      
      await storage.deleteSubscription(req.user.id, channelId);
      
      // Get updated channel subscriber count
      const channel = await storage.getChannel(channelId);
      
      res.json({
        success: true,
        subscriberCount: channel?.subscriberCount || 0
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to unsubscribe from channel" });
    }
  });

  app.get("/api/user/subscriptions", isAuthenticated, async (req, res) => {
    try {
      const subscriptions = await storage.getSubscriptionsByUser(req.user.id);
      
      // Get the channel details for each subscription
      const channels = await Promise.all(
        subscriptions.map(async (sub) => storage.getChannel(sub.channelId))
      );
      
      res.json(channels.filter(Boolean));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subscriptions" });
    }
  });
  
  // User watch history routes
  app.get("/api/user/history", isAuthenticated, async (req, res) => {
    try {
      // In a real implementation, we would fetch the user's watch history
      // For now, just return a subset of videos
      const videos = await storage.getVideos();
      // In production, this would be based on actual user watch history
      const historyVideos = videos.slice(0, 10); // For demo purposes
      res.json(historyVideos);
    } catch (error) {
      console.error("Error fetching watch history:", error);
      res.status(500).json({ message: "Failed to fetch watch history" });
    }
  });

  app.post("/api/user/history/clear", isAuthenticated, async (req, res) => {
    try {
      // In a real implementation, we would clear the user's watch history
      // For now, just return success
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing watch history:", error);
      res.status(500).json({ message: "Failed to clear watch history" });
    }
  });
  
  // Helper function to check if user is an admin or moderator
  function isModeratorOrAdmin(req: Request, res: Response, next: Function) {
    if (req.isAuthenticated() && (req.user.isAdmin || req.user.isModerator)) {
      return next();
    }
    res.status(403).json({ message: "Admin or moderator permissions required" });
  }
  
  // Moderation routes for content review
  
  // Get videos pending moderation
  app.get("/api/moderation/videos", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      const status = req.query.status as string || ModerationStatus.PENDING;
      
      let videos = [];
      if (status === "all") {
        videos = await storage.getVideos();
      } else if (status === ModerationStatus.PENDING) {
        videos = await storage.getVideosForModeration(limit, offset);
      } else {
        videos = await storage.getVideosByModerationStatus(status, limit);
      }
      
      res.json(videos);
    } catch (error) {
      console.error("Error fetching videos for moderation:", error);
      res.status(500).json({ message: "Failed to fetch videos for moderation" });
    }
  });
  
  // Approve or reject a video
  app.post("/api/moderation/videos/:id", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const videoId = parseInt(req.params.id);
      const { status, reason } = req.body;
      
      if (!status || !Object.values(ModerationStatus).includes(status)) {
        return res.status(400).json({ message: "Invalid moderation status" });
      }
      
      const result = await storage.moderateVideo(videoId, req.user.id, status, reason);
      
      if (result) {
        res.json({ success: true, message: `Video ${status}` });
      } else {
        res.status(404).json({ message: "Video not found" });
      }
    } catch (error) {
      console.error("Error moderating video:", error);
      res.status(500).json({ message: "Failed to moderate video" });
    }
  });
  
  // Get flagged comments
  app.get("/api/moderation/comments", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const comments = await storage.getFlaggedComments(limit);
      
      res.json(comments);
    } catch (error) {
      console.error("Error fetching flagged comments:", error);
      res.status(500).json({ message: "Failed to fetch flagged comments" });
    }
  });
  
  // Hide or unhide a comment
  app.post("/api/moderation/comments/:id", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const { action, reason } = req.body;
      
      if (!action || !["hide", "unhide"].includes(action)) {
        return res.status(400).json({ message: "Invalid action. Use 'hide' or 'unhide'" });
      }
      
      let result = false;
      if (action === "hide") {
        if (!reason) {
          return res.status(400).json({ message: "Reason is required when hiding a comment" });
        }
        result = await storage.hideComment(commentId, req.user.id, reason);
      } else {
        result = await storage.unhideComment(commentId, req.user.id);
      }
      
      if (result) {
        res.json({ success: true, message: `Comment ${action === 'hide' ? 'hidden' : 'unhidden'}` });
      } else {
        res.status(404).json({ message: "Comment not found" });
      }
    } catch (error) {
      console.error("Error moderating comment:", error);
      res.status(500).json({ message: "Failed to moderate comment" });
    }
  });
  
  // Get moderation reports
  app.get("/api/moderation/reports", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      const status = req.query.status as string;
      const contentType = req.query.contentType as string;
      
      let reports = [];
      if (contentType) {
        reports = await storage.getReportsByContentType(contentType, status);
      } else {
        reports = await storage.getReports(status, limit, offset);
      }
      
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Failed to fetch reports" });
    }
  });
  
  // Update report status
  app.post("/api/moderation/reports/:id", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const reportId = parseInt(req.params.id);
      const { status, actionTaken } = req.body;
      
      if (!status || !Object.values(ReportStatus).includes(status)) {
        return res.status(400).json({ message: "Invalid report status" });
      }
      
      const result = await storage.updateReportStatus(reportId, req.user.id, status, actionTaken);
      
      if (result) {
        res.json({ success: true, message: `Report status updated to ${status}` });
      } else {
        res.status(404).json({ message: "Report not found" });
      }
    } catch (error) {
      console.error("Error updating report status:", error);
      res.status(500).json({ message: "Failed to update report status" });
    }
  });
  
  // User management endpoints for admins
  app.get("/api/moderation/users", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      // In a full implementation, this would have filtering options
      // This is a simplified version that returns all users
      const allUsers = []; // We would implement a getAllUsers method
      res.json(allUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Ban or unban a user
  app.post("/api/moderation/users/:id", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { action, reason } = req.body;
      
      if (!action || !["ban", "unban"].includes(action)) {
        return res.status(400).json({ message: "Invalid action. Use 'ban' or 'unban'" });
      }
      
      let result = false;
      if (action === "ban") {
        if (!reason) {
          return res.status(400).json({ message: "Reason is required when banning a user" });
        }
        result = await storage.banUser(userId, req.user.id, reason);
      } else {
        result = await storage.unbanUser(userId, req.user.id);
      }
      
      if (result) {
        res.json({ success: true, message: `User ${action === 'ban' ? 'banned' : 'unbanned'}` });
      } else {
        res.status(404).json({ message: "User not found" });
      }
    } catch (error) {
      console.error("Error moderating user:", error);
      res.status(500).json({ message: "Failed to moderate user" });
    }
  });
  
  // Channel verification endpoints
  app.post("/api/moderation/channels/:id", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const channelId = parseInt(req.params.id);
      const { action, reason } = req.body;
      
      if (!action || !["verify", "unverify", "disable", "enable"].includes(action)) {
        return res.status(400).json({ 
          message: "Invalid action. Use 'verify', 'unverify', 'disable', or 'enable'" 
        });
      }
      
      let result = false;
      
      switch (action) {
        case "verify":
          result = await storage.verifyChannel(channelId, req.user.id);
          break;
        case "unverify":
          result = await storage.unverifyChannel(channelId, req.user.id);
          break;
        case "disable":
          if (!reason) {
            return res.status(400).json({ message: "Reason is required when disabling a channel" });
          }
          result = await storage.disableChannel(channelId, req.user.id, reason);
          break;
        case "enable":
          result = await storage.enableChannel(channelId, req.user.id);
          break;
      }
      
      if (result) {
        res.json({ 
          success: true, 
          message: `Channel ${action === 'verify' ? 'verified' : action === 'unverify' ? 'unverified' : action === 'disable' ? 'disabled' : 'enabled'}` 
        });
      } else {
        res.status(404).json({ message: "Channel not found" });
      }
    } catch (error) {
      console.error("Error moderating channel:", error);
      res.status(500).json({ message: "Failed to moderate channel" });
    }
  });
  
  // Get moderation logs
  app.get("/api/moderation/logs", isAuthenticated, isModeratorOrAdmin, async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      const moderatorId = req.query.moderatorId ? parseInt(req.query.moderatorId as string) : undefined;
      const contentType = req.query.contentType as string;
      const contentId = req.query.contentId ? parseInt(req.query.contentId as string) : undefined;
      
      let logs = [];
      
      if (moderatorId) {
        logs = await storage.getModerationLogsByModerator(moderatorId);
      } else if (contentType) {
        logs = await storage.getModerationLogsByContentType(contentType, contentId);
      } else {
        logs = await storage.getModerationLogs(limit, offset);
      }
      
      res.json(logs);
    } catch (error) {
      console.error("Error fetching moderation logs:", error);
      res.status(500).json({ message: "Failed to fetch moderation logs" });
    }
  });
  
  // Report content (for users)
  app.post("/api/report", isAuthenticated, isAgeVerified, async (req, res) => {
    try {
      const { contentType, contentId, reason } = req.body;
      
      if (!contentType || !contentId || !reason) {
        return res.status(400).json({ message: "Content type, content ID, and reason are required" });
      }
      
      if (!Object.values(ContentType).includes(contentType)) {
        return res.status(400).json({ message: "Invalid content type" });
      }
      
      const report = await storage.createReport({
        reporterId: req.user.id,
        contentType,
        contentId,
        reason,
        status: ReportStatus.PENDING
      });
      
      res.status(201).json({ 
        success: true, 
        message: "Report submitted successfully", 
        reportId: report.id 
      });
    } catch (error) {
      console.error("Error creating report:", error);
      res.status(500).json({ message: "Failed to submit report" });
    }
  });
  
  // Admin routes
  app.get("/api/admin/stats", isAuthenticated, isAdminUser, async (req, res) => {
    try {
      // Get users stats
      const users = await storage.getUsers();
      const totalUsers = users.length;
      const premiumUsers = users.filter(user => user.isPremium).length;
      const newUsersToday = users.filter(user => {
        const createdDate = new Date(user.createdAt || new Date());
        const today = new Date();
        return createdDate.getDate() === today.getDate() &&
               createdDate.getMonth() === today.getMonth() &&
               createdDate.getFullYear() === today.getFullYear();
      }).length;
      
      // Get active users (simplified)
      const activeUsersWeek = Math.round(totalUsers * 0.7); // Simplified stats
      
      // Get videos stats
      const videos = await storage.getVideos(1000); // Get up to 1000 videos
      const totalVideos = videos.length;
      const videosUploadedToday = videos.filter(video => {
        const uploadDate = new Date(video.createdAt || new Date());
        const today = new Date();
        return uploadDate.getDate() === today.getDate() &&
               uploadDate.getMonth() === today.getMonth() &&
               uploadDate.getFullYear() === today.getFullYear();
      }).length;
      
      // Total views
      const totalViews = videos.reduce((sum, video) => sum + (video.views || 0), 0);
      
      // Channels stats
      const channels = await storage.getChannels();
      const totalChannels = channels.length;
      const verifiedChannels = channels.filter(channel => channel.isVerified).length;
      
      // Comments stats (simplified - would need getComments method with date filter)
      const commentsToday = 0; 
      
      // Reports stats
      const reports = await storage.getReportsByStatus(ReportStatus.PENDING);
      const pendingReports = reports.length;
      
      res.json({
        totalUsers,
        premiumUsers,
        newUsersToday,
        activeUsersWeek,
        totalVideos,
        videosUploadedToday,
        totalViews,
        totalChannels,
        verifiedChannels,
        commentsToday,
        pendingReports
      });
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin statistics" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
