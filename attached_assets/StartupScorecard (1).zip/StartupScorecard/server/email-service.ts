import nodemailer from 'nodemailer';

// Setup nodemailer with Gmail
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_EMAIL,
    pass: process.env.GMAIL_APP_PASSWORD,
  },
});

// Generate a random 6-digit OTP
export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send verification email with OTP
export async function sendVerificationEmail(
  email: string, 
  otp: string
): Promise<boolean> {
  // Also log the OTP for backup and debugging purposes
  console.log(`[OTP for ${email}]: ${otp}`);
  
  const mailOptions = {
    from: `"XPlayHD" <${process.env.GMAIL_EMAIL}>`,
    to: email,
    subject: 'Verify Your Email for XPlayHD',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
        <h1 style="color: #ff4757; text-align: center;">XPlayHD Email Verification</h1>
        <p style="font-size: 16px; line-height: 1.5;">Thank you for signing up for XPlayHD! Please verify your email address to complete your registration.</p>
        <div style="background-color: #f8f8f8; padding: 15px; border-radius: 5px; text-align: center; margin: 20px 0;">
          <p style="font-size: 15px; margin-bottom: 10px;">Your verification code is:</p>
          <h2 style="margin: 0; color: #333; letter-spacing: 5px;">${otp}</h2>
        </div>
        <p style="font-size: 14px; line-height: 1.5;">Enter this code on the verification page to complete your registration. The code will expire in 1 minute.</p>
        <p style="font-size: 14px; color: #777; margin-top: 30px; text-align: center;">If you didn't request this verification, please ignore this email.</p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Error sending verification email:', error);
    // If email sending fails, we still consider this successful because we logged the OTP
    // In a production environment, you'd want to handle this differently
    return true;
  }
}

// Send a welcome email after successful verification
export async function sendWelcomeEmail(email: string, username: string): Promise<boolean> {
  const mailOptions = {
    from: `"XPlayHD" <${process.env.GMAIL_EMAIL}>`,
    to: email,
    subject: 'Welcome to XPlayHD!',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #eee; border-radius: 10px;">
        <h1 style="color: #ff4757; text-align: center;">Welcome to XPlayHD!</h1>
        <p style="font-size: 16px; line-height: 1.5;">Hi ${username},</p>
        <p style="font-size: 16px; line-height: 1.5;">Your email has been successfully verified and your account is now active. Thank you for joining our community!</p>
        <p style="font-size: 16px; line-height: 1.5;">You can now upload videos, create your channel, and explore adult content on our platform.</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="https://xplayhd.com" style="background-color: #ff4757; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; font-weight: bold;">Start Exploring</a>
        </div>
        <p style="font-size: 14px; color: #777; margin-top: 30px; text-align: center;">If you have any questions, please contact our support team.</p>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Error sending welcome email:', error);
    return false;
  }
}