import { and, eq, desc, count, sql, isNull, isNotNull, ne, like, or } from 'drizzle-orm';
import connectPg from "connect-pg-simple";
import session from 'express-session';
import { db } from './db';
import { 
  User, InsertUser, 
  Channel, InsertChannel, 
  Video, InsertVideo, 
  Comment, InsertComment,
  Like, InsertLike,
  Subscription, InsertSubscription,
  Report, InsertReport,
  ModerationLog, InsertModerationLog,
  users, channels, videos, comments, likes, subscriptions, reports, moderationLogs
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  getModerators(): Promise<User[]>;
  banUser(userId: number, moderatorId: number, reason: string): Promise<boolean>;
  unbanUser(userId: number, moderatorId: number): Promise<boolean>;
  
  // Email verification methods
  storeEmailVerificationCode(email: string, code: string): Promise<boolean>;
  verifyEmailCode(email: string, code: string): Promise<boolean>;
  markEmailAsVerified(userId: number): Promise<boolean>;
  
  // Channel methods
  getChannel(id: number): Promise<Channel | undefined>;
  getChannelByUserId(userId: number): Promise<Channel | undefined>;
  getChannels(): Promise<Channel[]>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  updateChannel(id: number, channel: Partial<Channel>): Promise<Channel | undefined>;
  verifyChannel(channelId: number, moderatorId: number): Promise<boolean>;
  unverifyChannel(channelId: number, moderatorId: number): Promise<boolean>;
  disableChannel(channelId: number, moderatorId: number, reason: string): Promise<boolean>;
  enableChannel(channelId: number, moderatorId: number): Promise<boolean>;
  
  // Video methods
  getVideo(id: number): Promise<Video | undefined>;
  getVideos(limit?: number): Promise<Video[]>;
  getVideosByChannel(channelId: number): Promise<Video[]>;
  getVideosByCategory(category: string, limit?: number): Promise<Video[]>;
  getQuickies(limit?: number): Promise<Video[]>;
  getTrendingVideos(limit?: number): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, video: Partial<Video>): Promise<Video | undefined>;
  incrementVideoViews(id: number): Promise<void>;
  moderateVideo(videoId: number, moderatorId: number, status: string, reason?: string): Promise<boolean>;
  getVideosForModeration(limit?: number, offset?: number): Promise<Video[]>;
  getVideosByModerationStatus(status: string, limit?: number): Promise<Video[]>;
  
  // Comment methods
  getComment(id: number): Promise<Comment | undefined>;
  getCommentsByVideo(videoId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  hideComment(commentId: number, moderatorId: number, reason: string): Promise<boolean>;
  unhideComment(commentId: number, moderatorId: number): Promise<boolean>;
  getFlaggedComments(limit?: number): Promise<Comment[]>;
  
  // Like methods
  getLike(userId: number, videoId: number): Promise<Like | undefined>;
  createLike(like: InsertLike): Promise<Like>;
  deleteLike(userId: number, videoId: number): Promise<void>;
  
  // Subscription methods
  getSubscription(userId: number, channelId: number): Promise<Subscription | undefined>;
  getSubscriptionsByUser(userId: number): Promise<Subscription[]>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  deleteSubscription(userId: number, channelId: number): Promise<void>;
  
  // Reporting methods
  createReport(report: InsertReport): Promise<Report>;
  getReport(id: number): Promise<Report | undefined>;
  getReports(status?: string, limit?: number, offset?: number): Promise<Report[]>;
  getReportsByContentType(contentType: string, status?: string): Promise<Report[]>;
  updateReportStatus(reportId: number, moderatorId: number, status: string, actionTaken?: string): Promise<boolean>;
  
  // Moderation logs
  createModerationLog(log: InsertModerationLog): Promise<ModerationLog>;
  getModerationLogs(limit?: number, offset?: number): Promise<ModerationLog[]>;
  getModerationLogsByModerator(moderatorId: number): Promise<ModerationLog[]>;
  getModerationLogsByContentType(contentType: string, contentId?: number): Promise<ModerationLog[]>;
  
  // Session store
  sessionStore: session.SessionStore;
}

const PostgresSessionStore = connectPg(session);

export class PostgresStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool: (db as any).config.client, 
      createTableIfMissing: true 
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  async getModerators(): Promise<User[]> {
    return db
      .select()
      .from(users)
      .where(eq(users.isAdmin, true));
  }

  async banUser(userId: number, moderatorId: number, reason: string): Promise<boolean> {
    const [user] = await db
      .update(users)
      .set({ isBanned: true })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'user',
      contentId: userId,
      action: 'ban',
      reason,
      timestamp: new Date()
    });
    
    return true;
  }

  async unbanUser(userId: number, moderatorId: number): Promise<boolean> {
    const [user] = await db
      .update(users)
      .set({ isBanned: false })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'user',
      contentId: userId,
      action: 'unban',
      reason: 'Ban removed',
      timestamp: new Date()
    });
    
    return true;
  }

  // Email verification methods
  async storeEmailVerificationCode(email: string, code: string): Promise<boolean> {
    // Store in user record temporarily - in production would use a separate table
    const [user] = await db
      .update(users)
      .set({
        tempVerificationData: JSON.stringify({
          code,
          expires: new Date(Date.now() + 10 * 60 * 1000) // 10 minutes
        })
      })
      .where(eq(users.email, email))
      .returning();
    
    return !!user;
  }

  async verifyEmailCode(email: string, code: string): Promise<boolean> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    
    if (!user || !user.tempVerificationData) return false;
    
    try {
      const verificationData = JSON.parse(user.tempVerificationData);
      const isValid = 
        verificationData.code === code && 
        new Date(verificationData.expires) > new Date();
      
      if (isValid) {
        // Clear the verification data after successful verification
        await db
          .update(users)
          .set({ tempVerificationData: null })
          .where(eq(users.id, user.id));
      }
      
      return isValid;
    } catch (error) {
      console.error('Error parsing verification data:', error);
      return false;
    }
  }

  async markEmailAsVerified(userId: number): Promise<boolean> {
    const [user] = await db
      .update(users)
      .set({ isEmailVerified: true })
      .where(eq(users.id, userId))
      .returning();
    
    return !!user;
  }

  // Channel methods
  async getChannel(id: number): Promise<Channel | undefined> {
    const [channel] = await db.select().from(channels).where(eq(channels.id, id));
    return channel;
  }

  async getChannelByUserId(userId: number): Promise<Channel | undefined> {
    const [channel] = await db.select().from(channels).where(eq(channels.userId, userId));
    return channel;
  }

  async getChannels(): Promise<Channel[]> {
    return db.select().from(channels).where(eq(channels.isDisabled, false));
  }

  async createChannel(insertChannel: InsertChannel): Promise<Channel> {
    const [channel] = await db.insert(channels).values(insertChannel).returning();
    return channel;
  }

  async updateChannel(id: number, channelData: Partial<Channel>): Promise<Channel | undefined> {
    const [updatedChannel] = await db
      .update(channels)
      .set(channelData)
      .where(eq(channels.id, id))
      .returning();
    return updatedChannel;
  }

  async verifyChannel(channelId: number, moderatorId: number): Promise<boolean> {
    const [channel] = await db
      .update(channels)
      .set({ isVerified: true })
      .where(eq(channels.id, channelId))
      .returning();
    
    if (!channel) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'channel',
      contentId: channelId,
      action: 'verify',
      reason: 'Channel verified by moderator',
      timestamp: new Date()
    });
    
    return true;
  }

  async unverifyChannel(channelId: number, moderatorId: number): Promise<boolean> {
    const [channel] = await db
      .update(channels)
      .set({ isVerified: false })
      .where(eq(channels.id, channelId))
      .returning();
    
    if (!channel) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'channel',
      contentId: channelId,
      action: 'unverify',
      reason: 'Channel verification removed by moderator',
      timestamp: new Date()
    });
    
    return true;
  }

  async disableChannel(channelId: number, moderatorId: number, reason: string): Promise<boolean> {
    const [channel] = await db
      .update(channels)
      .set({ isDisabled: true })
      .where(eq(channels.id, channelId))
      .returning();
    
    if (!channel) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'channel',
      contentId: channelId,
      action: 'disable',
      reason,
      timestamp: new Date()
    });
    
    return true;
  }

  async enableChannel(channelId: number, moderatorId: number): Promise<boolean> {
    const [channel] = await db
      .update(channels)
      .set({ isDisabled: false })
      .where(eq(channels.id, channelId))
      .returning();
    
    if (!channel) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'channel',
      contentId: channelId,
      action: 'enable',
      reason: 'Channel re-enabled by moderator',
      timestamp: new Date()
    });
    
    return true;
  }

  // Video methods
  async getVideo(id: number): Promise<Video | undefined> {
    const [video] = await db.select().from(videos).where(eq(videos.id, id));
    return video;
  }

  async getVideos(limit = 20): Promise<Video[]> {
    return db
      .select()
      .from(videos)
      .where(and(
        eq(videos.moderationStatus, 'approved'),
        eq(videos.isDisabled, false)
      ))
      .limit(limit);
  }

  async getVideosByChannel(channelId: number): Promise<Video[]> {
    return db
      .select()
      .from(videos)
      .where(and(
        eq(videos.channelId, channelId),
        eq(videos.moderationStatus, 'approved'),
        eq(videos.isDisabled, false)
      ));
  }

  async getVideosByCategory(category: string, limit = 20): Promise<Video[]> {
    return db
      .select()
      .from(videos)
      .where(and(
        eq(videos.category, category),
        eq(videos.moderationStatus, 'approved'),
        eq(videos.isDisabled, false)
      ))
      .limit(limit);
  }

  async getQuickies(limit = 20): Promise<Video[]> {
    return db
      .select()
      .from(videos)
      .where(and(
        eq(videos.isQuickie, true),
        eq(videos.moderationStatus, 'approved'),
        eq(videos.isDisabled, false)
      ))
      .limit(limit);
  }

  async getTrendingVideos(limit = 20): Promise<Video[]> {
    return db
      .select()
      .from(videos)
      .where(and(
        eq(videos.moderationStatus, 'approved'),
        eq(videos.isDisabled, false)
      ))
      .orderBy(desc(videos.views))
      .limit(limit);
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values(insertVideo).returning();
    return video;
  }

  async updateVideo(id: number, videoData: Partial<Video>): Promise<Video | undefined> {
    const [updatedVideo] = await db
      .update(videos)
      .set(videoData)
      .where(eq(videos.id, id))
      .returning();
    return updatedVideo;
  }

  async incrementVideoViews(id: number): Promise<void> {
    await db
      .update(videos)
      .set({ 
        views: sql`${videos.views} + 1` 
      })
      .where(eq(videos.id, id));
  }

  async moderateVideo(videoId: number, moderatorId: number, status: string, reason?: string): Promise<boolean> {
    const [video] = await db
      .update(videos)
      .set({ 
        moderationStatus: status,
        moderatedAt: new Date(),
        moderatorId
      })
      .where(eq(videos.id, videoId))
      .returning();
    
    if (!video) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'video',
      contentId: videoId,
      action: `set_status_${status}`,
      reason: reason || `Video status set to ${status}`,
      timestamp: new Date()
    });
    
    return true;
  }

  async getVideosForModeration(limit = 20, offset = 0): Promise<Video[]> {
    return db
      .select()
      .from(videos)
      .where(or(
        eq(videos.moderationStatus, 'pending'),
        eq(videos.moderationStatus, 'flagged')
      ))
      .limit(limit)
      .offset(offset);
  }

  async getVideosByModerationStatus(status: string, limit = 20): Promise<Video[]> {
    return db
      .select()
      .from(videos)
      .where(eq(videos.moderationStatus, status))
      .limit(limit);
  }

  // Comment methods
  async getComment(id: number): Promise<Comment | undefined> {
    const [comment] = await db.select().from(comments).where(eq(comments.id, id));
    return comment;
  }

  async getCommentsByVideo(videoId: number): Promise<Comment[]> {
    return db
      .select()
      .from(comments)
      .where(and(
        eq(comments.videoId, videoId),
        eq(comments.isHidden, false)
      ))
      .orderBy(desc(comments.createdAt));
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const [comment] = await db.insert(comments).values(insertComment).returning();
    return comment;
  }

  async hideComment(commentId: number, moderatorId: number, reason: string): Promise<boolean> {
    const [comment] = await db
      .update(comments)
      .set({ isHidden: true })
      .where(eq(comments.id, commentId))
      .returning();
    
    if (!comment) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'comment',
      contentId: commentId,
      action: 'hide',
      reason,
      timestamp: new Date()
    });
    
    return true;
  }

  async unhideComment(commentId: number, moderatorId: number): Promise<boolean> {
    const [comment] = await db
      .update(comments)
      .set({ isHidden: false })
      .where(eq(comments.id, commentId))
      .returning();
    
    if (!comment) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'comment',
      contentId: commentId,
      action: 'unhide',
      reason: 'Comment unhidden by moderator',
      timestamp: new Date()
    });
    
    return true;
  }

  async getFlaggedComments(limit = 20): Promise<Comment[]> {
    // Get comments that have been reported
    const commentReports = await db
      .select()
      .from(reports)
      .where(eq(reports.contentType, 'comment'))
      .limit(limit);
    
    if (commentReports.length === 0) return [];
    
    const commentIds = commentReports.map(report => report.contentId);
    
    return db
      .select()
      .from(comments)
      .where(sql`${comments.id} IN (${commentIds.join(',')})`);
  }

  // Like methods
  async getLike(userId: number, videoId: number): Promise<Like | undefined> {
    const [like] = await db
      .select()
      .from(likes)
      .where(and(
        eq(likes.userId, userId),
        eq(likes.videoId, videoId)
      ));
    return like;
  }

  async createLike(insertLike: InsertLike): Promise<Like> {
    // First check if the like already exists
    const existingLike = await this.getLike(insertLike.userId, insertLike.videoId);
    
    if (existingLike) {
      // If the like exists and the type is the same, just return it
      if (existingLike.type === insertLike.type) {
        return existingLike;
      }
      
      // If the type is different, update it
      const [updatedLike] = await db
        .update(likes)
        .set({ type: insertLike.type })
        .where(and(
          eq(likes.userId, insertLike.userId),
          eq(likes.videoId, insertLike.videoId)
        ))
        .returning();
        
      return updatedLike;
    }
    
    // Otherwise create a new like
    const [like] = await db.insert(likes).values(insertLike).returning();
    return like;
  }

  async deleteLike(userId: number, videoId: number): Promise<void> {
    await db
      .delete(likes)
      .where(and(
        eq(likes.userId, userId),
        eq(likes.videoId, videoId)
      ));
  }

  // Subscription methods
  async getSubscription(userId: number, channelId: number): Promise<Subscription | undefined> {
    const [subscription] = await db
      .select()
      .from(subscriptions)
      .where(and(
        eq(subscriptions.userId, userId),
        eq(subscriptions.channelId, channelId)
      ));
    return subscription;
  }

  async getSubscriptionsByUser(userId: number): Promise<Subscription[]> {
    return db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, userId));
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const [subscription] = await db.insert(subscriptions).values(insertSubscription).returning();
    return subscription;
  }

  async deleteSubscription(userId: number, channelId: number): Promise<void> {
    await db
      .delete(subscriptions)
      .where(and(
        eq(subscriptions.userId, userId),
        eq(subscriptions.channelId, channelId)
      ));
  }

  // Reporting methods
  async createReport(reportData: InsertReport): Promise<Report> {
    const [report] = await db.insert(reports).values(reportData).returning();
    return report;
  }

  async getReport(id: number): Promise<Report | undefined> {
    const [report] = await db.select().from(reports).where(eq(reports.id, id));
    return report;
  }

  async getReports(status?: string, limit = 20, offset = 0): Promise<Report[]> {
    let query = db.select().from(reports);
    
    if (status) {
      query = query.where(eq(reports.status, status));
    }
    
    return query.limit(limit).offset(offset);
  }

  async getReportsByContentType(contentType: string, status?: string): Promise<Report[]> {
    let query = db
      .select()
      .from(reports)
      .where(eq(reports.contentType, contentType));
    
    if (status) {
      query = query.where(eq(reports.status, status));
    }
    
    return query;
  }

  async updateReportStatus(reportId: number, moderatorId: number, status: string, actionTaken?: string): Promise<boolean> {
    const [report] = await db
      .update(reports)
      .set({ 
        status,
        resolvedAt: new Date(),
        moderatorId,
        actionTaken: actionTaken || null
      })
      .where(eq(reports.id, reportId))
      .returning();
    
    if (!report) return false;
    
    await this.createModerationLog({
      moderatorId,
      contentType: 'report',
      contentId: reportId,
      action: `resolve_report`,
      reason: `Report marked as ${status}` + (actionTaken ? ` - Action: ${actionTaken}` : ''),
      timestamp: new Date()
    });
    
    return true;
  }

  // Moderation logs
  async createModerationLog(log: InsertModerationLog): Promise<ModerationLog> {
    const [moderationLog] = await db.insert(moderationLogs).values(log).returning();
    return moderationLog;
  }

  async getModerationLogs(limit = 20, offset = 0): Promise<ModerationLog[]> {
    return db
      .select()
      .from(moderationLogs)
      .orderBy(desc(moderationLogs.timestamp))
      .limit(limit)
      .offset(offset);
  }

  async getModerationLogsByModerator(moderatorId: number): Promise<ModerationLog[]> {
    return db
      .select()
      .from(moderationLogs)
      .where(eq(moderationLogs.moderatorId, moderatorId))
      .orderBy(desc(moderationLogs.timestamp));
  }

  async getModerationLogsByContentType(contentType: string, contentId?: number): Promise<ModerationLog[]> {
    let query = db
      .select()
      .from(moderationLogs)
      .where(eq(moderationLogs.contentType, contentType));
    
    if (contentId !== undefined) {
      query = query.where(eq(moderationLogs.contentId, contentId));
    }
    
    return query.orderBy(desc(moderationLogs.timestamp));
  }
}

export const storage = new PostgresStorage();