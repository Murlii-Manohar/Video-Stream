import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express, Request } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User, InsertUser, emailVerificationSchema } from "@shared/schema";
import { z } from "zod";
import { generateOTP, sendVerificationEmail, sendWelcomeEmail } from "./email-service";

// Extend Session types
declare module 'express-session' {
  interface Session {
    pendingVerification?: {
      [email: string]: {
        otp: string;
        expires: Date;
      }
    };
    verifiedEmails?: string[];
  }
}

declare global {
  namespace Express {
    // Explicitly include the properties we need instead of extending User to avoid circular reference
    interface User {
      id: number;
      username: string;
      email: string;
      avatar?: string;
      isVerified: boolean;
      isEmailVerified: boolean;
      isAdmin: boolean;
      isPremium: boolean;
    }
  }
}

const scryptAsync = promisify(scrypt);

// Email validation schema
const emailSchema = z.string().email("Please enter a valid email");

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const secret = process.env.SESSION_SECRET || randomBytes(32).toString("hex");
  const sessionSettings: session.SessionOptions = {
    secret,
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: process.env.NODE_ENV === "production", 
      maxAge: 1000 * 60 * 60 * 24 * 7 // 1 week
    },
    store: storage.sessionStore,
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        // Try to find by username first
        let user = await storage.getUserByUsername(username);
        
        // If not found, try to find by email
        if (!user && username.includes('@')) {
          user = await storage.getUserByEmail(username);
        }
        
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "Invalid username or password" });
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Send Email Verification Code
  app.post("/api/send-verification-code", async (req: Request, res) => {
    try {
      const { email } = req.body;
      
      // Validate email
      try {
        emailSchema.parse(email);
      } catch (error) {
        return res.status(400).json({ message: "Please enter a valid email address" });
      }
      
      // Check if email already exists
      const existingUserByEmail = await storage.getUserByEmail(email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      // Generate and store OTP
      const otp = generateOTP();
      
      // Store in temporary session data for verification later
      if (!req.session.pendingVerification) {
        req.session.pendingVerification = {};
      }
      
      // Store the OTP with 30 minute expiry time
      req.session.pendingVerification[email] = {
        otp,
        expires: new Date(Date.now() + 30 * 60 * 1000)
      };
      
      // Send verification email
      const emailSent = await sendVerificationEmail(email, otp);
      
      if (emailSent) {
        res.status(200).json({ 
          message: "Verification code sent to your email",
          email 
        });
      } else {
        res.status(500).json({ message: "Failed to send verification email" });
      }
    } catch (error) {
      console.error("Error sending verification code:", error);
      res.status(500).json({ message: "An error occurred while sending verification code" });
    }
  });
  
  // Verify Email Code
  app.post("/api/verify-email-code", async (req: Request, res) => {
    try {
      const { email, code } = req.body;
      
      // Validate verification data
      try {
        emailVerificationSchema.parse({ email, code });
      } catch (error: any) {
        return res.status(400).json({ 
          message: "Invalid verification data",
          errors: error.errors
        });
      }
      
      // Check if we have a pending verification for this email
      if (!req.session.pendingVerification || !req.session.pendingVerification[email]) {
        return res.status(400).json({ 
          message: "No verification pending for this email or code expired. Please request a new code." 
        });
      }
      
      const verification = req.session.pendingVerification[email];
      
      // Check if the code has expired
      if (new Date() > new Date(verification.expires)) {
        delete req.session.pendingVerification[email];
        return res.status(400).json({ 
          message: "Verification code has expired. Please request a new code." 
        });
      }
      
      // Check if the code matches
      if (verification.otp !== code) {
        return res.status(400).json({ 
          message: "Invalid verification code. Please try again." 
        });
      }
      
      // Verification successful, store the verified email for registration
      if (!req.session.verifiedEmails) {
        req.session.verifiedEmails = [];
      }
      
      // Add to verified emails if not already there
      if (!req.session.verifiedEmails.includes(email)) {
        req.session.verifiedEmails.push(email);
      }
      
      // Remove from pending verifications
      delete req.session.pendingVerification[email];
      
      res.status(200).json({ 
        message: "Email verified successfully",
        email
      });
    } catch (error) {
      console.error("Error verifying email code:", error);
      res.status(500).json({ message: "An error occurred while verifying email" });
    }
  });

  // Register endpoint
  app.post("/api/register", async (req: Request, res, next) => {
    try {
      const { email, username, password, avatar } = req.body;
      
      // Validate email
      try {
        emailSchema.parse(email);
      } catch (error) {
        return res.status(400).json({ message: "Please enter a valid email address" });
      }
      
      // Check if the email has been verified
      if (!req.session.verifiedEmails || !req.session.verifiedEmails.includes(email)) {
        return res.status(403).json({ 
          message: "Email verification required",
          needVerification: true
        });
      }
      
      // Check if username already exists
      const existingUserByUsername = await storage.getUserByUsername(username);
      if (existingUserByUsername) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Check if email already exists (double check)
      const existingUserByEmail = await storage.getUserByEmail(email);
      if (existingUserByEmail) {
        return res.status(400).json({ message: "Email already in use" });
      }

      // Create new user with hashed password
      // Check if this is the admin email
      const isAdmin = email === "m.manohar2003@gmail.com";
      
      const userData: InsertUser = {
        username,
        email,
        password: await hashPassword(password),
        avatar: avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=random`,
        isAdmin: isAdmin // Set admin flag based on the email
      };
      
      const user = await storage.createUser(userData);
      
      // Mark email as verified in the database
      await storage.updateUser(user.id, { 
        isEmailVerified: true 
      });
      
      // Remove the email from the session's verified emails
      if (req.session.verifiedEmails) {
        req.session.verifiedEmails = req.session.verifiedEmails.filter((e: string) => e !== email);
      }
      
      // Send welcome email
      sendWelcomeEmail(email, username).catch((err: any) => 
        console.error("Failed to send welcome email:", err)
      );

      // Log in the user
      req.login(user, (err: any) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });

  // Login endpoint
  app.post("/api/login", (req: Request, res, next) => {
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }
      
      req.login(user, (loginErr: any) => {
        if (loginErr) return next(loginErr);
        return res.status(200).json(user);
      });
    })(req, res, next);
  });

  // Logout endpoint
  app.post("/api/logout", (req: Request, res, next) => {
    req.logout((err: any) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  // Get current user endpoint
  app.get("/api/user", (req: Request, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
  
  // Verify user age (simplified for demo)
  app.post("/api/verify-age", (req: Request, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "You must be logged in" });
    
    storage.updateUser(req.user.id, { isVerified: true })
      .then(user => {
        if (user) {
          req.user.isVerified = true;
          res.json({ success: true });
        } else {
          res.status(404).json({ message: "User not found" });
        }
      })
      .catch((err: any) => {
        res.status(500).json({ message: "Failed to verify age" });
      });
  });
}
