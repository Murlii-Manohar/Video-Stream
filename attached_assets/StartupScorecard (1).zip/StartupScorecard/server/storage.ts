import {
  DynamoDBClient,
  CreateTableCommand
} from '@aws-sdk/client-dynamodb';
import {
  DynamoDBDocumentClient,
  GetCommand,
  PutCommand,
  UpdateCommand,
  QueryCommand,
  ScanCommand,
  DeleteCommand
} from '@aws-sdk/lib-dynamodb';
import { marshall, unmarshall } from '@aws-sdk/util-dynamodb';
import createMemoryStore from 'memorystore';
import session from 'express-session';
import { 
  User, InsertUser, 
  Channel, InsertChannel, 
  Video, InsertVideo, 
  Comment, InsertComment, 
  Like, InsertLike,
  Subscription, InsertSubscription,
  Report, InsertReport,
  ModerationLog, InsertModerationLog,
  ModerationStatus, ContentType, ReportStatus, ModerationAction
} from '@shared/schema';

const MemoryStore = createMemoryStore(session);

// Storage Interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  getModerators(): Promise<User[]>;
  banUser(userId: number, moderatorId: number, reason: string): Promise<boolean>;
  unbanUser(userId: number, moderatorId: number): Promise<boolean>;
  
  // Email verification methods
  storeEmailVerificationCode(email: string, code: string): Promise<boolean>;
  verifyEmailCode(email: string, code: string): Promise<boolean>;
  markEmailAsVerified(userId: number): Promise<boolean>;
  
  // Channel methods
  getChannel(id: number): Promise<Channel | undefined>;
  getChannelByUserId(userId: number): Promise<Channel | undefined>;
  getChannels(): Promise<Channel[]>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  updateChannel(id: number, channel: Partial<Channel>): Promise<Channel | undefined>;
  verifyChannel(channelId: number, moderatorId: number): Promise<boolean>;
  unverifyChannel(channelId: number, moderatorId: number): Promise<boolean>;
  disableChannel(channelId: number, moderatorId: number, reason: string): Promise<boolean>;
  enableChannel(channelId: number, moderatorId: number): Promise<boolean>;
  
  // Video methods
  getVideo(id: number): Promise<Video | undefined>;
  getVideos(limit?: number): Promise<Video[]>;
  getVideosByChannel(channelId: number): Promise<Video[]>;
  getVideosByCategory(category: string, limit?: number): Promise<Video[]>;
  getQuickies(limit?: number): Promise<Video[]>;
  getTrendingVideos(limit?: number): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, video: Partial<Video>): Promise<Video | undefined>;
  incrementVideoViews(id: number): Promise<void>;
  moderateVideo(videoId: number, moderatorId: number, status: string, reason?: string): Promise<boolean>;
  getVideosForModeration(limit?: number, offset?: number): Promise<Video[]>;
  getVideosByModerationStatus(status: string, limit?: number): Promise<Video[]>;
  
  // Comment methods
  getComment(id: number): Promise<Comment | undefined>;
  getCommentsByVideo(videoId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  hideComment(commentId: number, moderatorId: number, reason: string): Promise<boolean>;
  unhideComment(commentId: number, moderatorId: number): Promise<boolean>;
  getFlaggedComments(limit?: number): Promise<Comment[]>;
  
  // Like methods
  getLike(userId: number, videoId: number): Promise<Like | undefined>;
  createLike(like: InsertLike): Promise<Like>;
  deleteLike(userId: number, videoId: number): Promise<void>;
  
  // Subscription methods
  getSubscription(userId: number, channelId: number): Promise<Subscription | undefined>;
  getSubscriptionsByUser(userId: number): Promise<Subscription[]>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  deleteSubscription(userId: number, channelId: number): Promise<void>;
  
  // Reporting methods
  createReport(report: InsertReport): Promise<Report>;
  getReport(id: number): Promise<Report | undefined>;
  getReports(status?: string, limit?: number, offset?: number): Promise<Report[]>;
  getReportsByStatus(status: string): Promise<Report[]>;
  getReportsByContentType(contentType: string, status?: string): Promise<Report[]>;
  updateReportStatus(reportId: number, moderatorId: number, status: string, actionTaken?: string): Promise<boolean>;
  
  // Moderation logs
  createModerationLog(log: InsertModerationLog): Promise<ModerationLog>;
  getModerationLogs(limit?: number, offset?: number): Promise<ModerationLog[]>;
  getModerationLogsByModerator(moderatorId: number): Promise<ModerationLog[]>;
  getModerationLogsByContentType(contentType: string, contentId?: number): Promise<ModerationLog[]>;
  
  // Session store
  sessionStore: any; // Using 'any' to avoid session type issues
}

// DynamoDB Storage implementation
export class DynamoStorage implements IStorage {
  sessionStore: any; // Using 'any' to avoid session type issues
  
  private client: DynamoDBClient;
  private docClient: DynamoDBDocumentClient;
  private counterTable = 'XPlayHD_Counters';
  private userTable = 'XPlayHD_Users';
  private channelTable = 'XPlayHD_Channels';
  private videoTable = 'XPlayHD_Videos';
  private commentTable = 'XPlayHD_Comments';
  private likeTable = 'XPlayHD_Likes';
  private subscriptionTable = 'XPlayHD_Subscriptions';
  private reportTable = 'XPlayHD_Reports';
  private moderationLogTable = 'XPlayHD_ModerationLogs';
  private initialized = false;

  constructor() {
    this.client = new DynamoDBClient({
      region: process.env.AWS_REGION || 'us-east-1',
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID || '',
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || ''
      }
    });

    this.docClient = DynamoDBDocumentClient.from(this.client);
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // Prune expired entries every 24h
    });

    // Initialize tables
    this.init().catch(err => {
      console.error('Failed to initialize DynamoDB tables:', err);
    });
  }

  // Initialize DynamoDB tables
  private async init() {
    if (this.initialized) return;
    
    try {
      // Check if tables already exist before creating them
      try {
        // Ensure all necessary tables exist
        await this.createTableIfNotExists(this.counterTable, 'entityType', 'S');
        await this.createTableIfNotExists(this.userTable, 'id', 'N');
        await this.createTableIfNotExists(this.channelTable, 'id', 'N');
        await this.createTableIfNotExists(this.videoTable, 'id', 'N');
        await this.createTableIfNotExists(this.commentTable, 'id', 'N');
        await this.createTableIfNotExists(this.likeTable, 'id', 'N');
        await this.createTableIfNotExists(this.subscriptionTable, 'id', 'N');
        await this.createTableIfNotExists(this.reportTable, 'id', 'N');
        await this.createTableIfNotExists(this.moderationLogTable, 'id', 'N');
      } catch (tableError) {
        console.warn('Some tables may already exist:', tableError);
        // Continue execution even if table creation fails
      }
      
      // Initialize counters
      await this.initializeCounter('user');
      await this.initializeCounter('channel');
      await this.initializeCounter('video');
      await this.initializeCounter('comment');
      await this.initializeCounter('like');
      await this.initializeCounter('subscription');
      await this.initializeCounter('report');
      await this.initializeCounter('moderationLog');
      
      this.initialized = true;
      console.log('DynamoDB tables initialized successfully.');
    } catch (error) {
      console.error('Error initializing DynamoDB tables:', error);
      throw error;
    }
  }

  private async createTableIfNotExists(
    tableName: string,
    hashKey: string,
    hashKeyType: string
  ) {
    try {
      // Check if table exists
      const tableData = await this.client.send(
        new CreateTableCommand({
          TableName: tableName,
          KeySchema: [
            { AttributeName: hashKey, KeyType: 'HASH' }
          ],
          AttributeDefinitions: [
            { AttributeName: hashKey, AttributeType: hashKeyType === 'S' ? 'S' : 'N' }
          ],
          ProvisionedThroughput: {
            ReadCapacityUnits: 5,
            WriteCapacityUnits: 5,
          },
        })
      );
      
      console.log(`Table ${tableName} created successfully.`);
      return tableData;
    } catch (error: any) {
      // Table already exists, skip creation
      if (error.name === 'ResourceInUseException') {
        console.log(`Table ${tableName} already exists.`);
        return;
      }
      
      console.error(`Error creating table ${tableName}:`, error);
      throw error;
    }
  }

  private async initializeCounter(entityType: string) {
    try {
      // Make sure we're using the correct attribute name that matches the schema
      const result = await this.docClient.send(
        new GetCommand({
          TableName: this.counterTable,
          Key: { "entityType": entityType },
        })
      );
      
      // If counter doesn't exist, initialize it
      if (!result.Item) {
        await this.docClient.send(
          new PutCommand({
            TableName: this.counterTable,
            Item: {
              "entityType": entityType,
              "nextId": 1,
            },
          })
        );
        console.log(`Counter for ${entityType} initialized.`);
      }
    } catch (error) {
      console.error(`Error initializing counter for ${entityType}:`, error);
      throw error;
    }
  }

  private async getNextId(entityType: string): Promise<number> {
    try {
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.counterTable,
          Key: { "entityType": entityType },
          UpdateExpression: 'SET nextId = nextId + :incr',
          ExpressionAttributeValues: {
            ':incr': 1,
          },
          ReturnValues: 'UPDATED_NEW',
        })
      );
      
      return result.Attributes?.nextId as number;
    } catch (error) {
      console.error(`Error getting next ID for ${entityType}:`, error);
      throw error;
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    try {
      const result = await this.docClient.send(
        new GetCommand({
          TableName: this.userTable,
          Key: { id },
        })
      );
      
      return result.Item as User;
    } catch (error) {
      console.error(`Error getting user ${id}:`, error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.userTable,
          FilterExpression: 'username = :username',
          ExpressionAttributeValues: {
            ':username': username,
          },
        })
      );
      
      return result.Items && result.Items.length > 0 
        ? result.Items[0] as User 
        : undefined;
    } catch (error) {
      console.error(`Error getting user by username ${username}:`, error);
      return undefined;
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.userTable,
          FilterExpression: 'email = :email',
          ExpressionAttributeValues: {
            ':email': email,
          },
        })
      );
      
      return result.Items && result.Items.length > 0 
        ? result.Items[0] as User 
        : undefined;
    } catch (error) {
      console.error(`Error getting user by email ${email}:`, error);
      return undefined;
    }
  }

  async getUsers(): Promise<User[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.userTable
        })
      );
      
      return (result.Items || []) as User[];
    } catch (error) {
      console.error('Error getting all users:', error);
      return [];
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const id = await this.getNextId('user');
      const timestamp = new Date();
      
      // Ensure all fields are properly defined with null for undefined values
      // Convert Date to ISO string for DynamoDB storage
      const user: User = { 
        ...insertUser, 
        id, 
        avatar: insertUser.avatar || null, 
        isVerified: false, 
        isEmailVerified: false,
        isAdmin: false,
        isModerator: false,
        isPremium: false,
        isBanned: false,
        emailVerificationCode: null,
        emailVerificationExpires: null,
        createdAt: timestamp.toISOString() // Store as ISO string for DynamoDB
      };
      
      await this.docClient.send(
        new PutCommand({
          TableName: this.userTable,
          Item: user,
        })
      );
      
      return user;
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    try {
      const user = await this.getUser(id);
      if (!user) return undefined;
      
      const updateExpression = Object.keys(userData)
        .map((key) => `#${key} = :${key}`)
        .join(', ');
      
      const expressionAttributeNames = Object.keys(userData).reduce(
        (acc, key) => ({ ...acc, [`#${key}`]: key }),
        {}
      );
      
      const expressionAttributeValues = Object.entries(userData).reduce(
        (acc, [key, value]) => ({ ...acc, [`:${key}`]: value }),
        {}
      );
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.userTable,
          Key: { id },
          UpdateExpression: `SET ${updateExpression}`,
          ExpressionAttributeNames: expressionAttributeNames,
          ExpressionAttributeValues: expressionAttributeValues,
          ReturnValues: 'ALL_NEW',
        })
      );
      
      return result.Attributes as User;
    } catch (error) {
      console.error(`Error updating user ${id}:`, error);
      return undefined;
    }
  }

  // Get all moderators and admins
  async getModerators(): Promise<User[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.userTable,
          FilterExpression: '#isAdmin = :isAdmin OR #isModerator = :isModerator',
          ExpressionAttributeNames: {
            '#isAdmin': 'isAdmin',
            '#isModerator': 'isModerator'
          },
          ExpressionAttributeValues: {
            ':isAdmin': true,
            ':isModerator': true
          }
        })
      );
      
      return (result.Items || []) as User[];
    } catch (error) {
      console.error('Error getting moderators:', error);
      return [];
    }
  }

  // Ban a user
  async banUser(userId: number, moderatorId: number, reason: string): Promise<boolean> {
    try {
      const timestamp = new Date().toISOString();
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.userTable,
          Key: { id: userId },
          UpdateExpression: 'SET isBanned = :isBanned, banReason = :reason, bannedAt = :timestamp, bannedBy = :moderatorId',
          ExpressionAttributeValues: {
            ':isBanned': true,
            ':reason': reason,
            ':timestamp': timestamp,
            ':moderatorId': moderatorId
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.USER,
          contentId: userId,
          action: ModerationAction.BAN,
          reason,
          previousStatus: 'active',
          newStatus: 'banned'
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error banning user ${userId}:`, error);
      return false;
    }
  }

  // Unban a user
  async unbanUser(userId: number, moderatorId: number): Promise<boolean> {
    try {
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.userTable,
          Key: { id: userId },
          UpdateExpression: 'SET isBanned = :isBanned, banReason = :reason, bannedAt = :timestamp, bannedBy = :moderatorId',
          ExpressionAttributeValues: {
            ':isBanned': false,
            ':reason': null,
            ':timestamp': null,
            ':moderatorId': null
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.USER,
          contentId: userId,
          action: ModerationAction.UNBAN,
          previousStatus: 'banned',
          newStatus: 'active'
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error unbanning user ${userId}:`, error);
      return false;
    }
  }
  
  // Email verification methods
  async storeEmailVerificationCode(email: string, code: string): Promise<boolean> {
    try {
      // Find the user by email
      const user = await this.getUserByEmail(email);
      if (!user) return false;
      
      // Set the verification code and expiration time (30 minutes from now)
      const expiresAt = new Date(Date.now() + 30 * 60 * 1000).toISOString();
      
      await this.docClient.send(
        new UpdateCommand({
          TableName: this.userTable,
          Key: { id: user.id },
          UpdateExpression: 'SET emailVerificationCode = :code, emailVerificationExpires = :expires',
          ExpressionAttributeValues: {
            ':code': code,
            ':expires': expiresAt
          }
        })
      );
      
      return true;
    } catch (error) {
      console.error(`Error storing verification code for ${email}:`, error);
      return false;
    }
  }
  
  async verifyEmailCode(email: string, code: string): Promise<boolean> {
    try {
      // Find the user by email
      const user = await this.getUserByEmail(email);
      if (!user) return false;
      
      // Check if code exists and is not expired
      if (!user.emailVerificationCode || user.emailVerificationCode !== code) {
        return false;
      }
      
      // Check if code is expired
      if (user.emailVerificationExpires) {
        const expiresAt = new Date(user.emailVerificationExpires);
        if (expiresAt < new Date()) {
          return false; // Code expired
        }
      }
      
      // Mark email as verified and clear verification code
      await this.docClient.send(
        new UpdateCommand({
          TableName: this.userTable,
          Key: { id: user.id },
          UpdateExpression: 'SET isEmailVerified = :verified, emailVerificationCode = :code',
          ExpressionAttributeValues: {
            ':verified': true,
            ':code': null
          }
        })
      );
      
      return true;
    } catch (error) {
      console.error(`Error verifying code for ${email}:`, error);
      return false;
    }
  }
  
  async markEmailAsVerified(userId: number): Promise<boolean> {
    try {
      const user = await this.getUser(userId);
      if (!user) return false;
      
      await this.docClient.send(
        new UpdateCommand({
          TableName: this.userTable,
          Key: { id: userId },
          UpdateExpression: 'SET isEmailVerified = :verified',
          ExpressionAttributeValues: {
            ':verified': true
          }
        })
      );
      
      return true;
    } catch (error) {
      console.error(`Error marking email as verified for user ${userId}:`, error);
      return false;
    }
  }

  // Channel methods
  async getChannel(id: number): Promise<Channel | undefined> {
    try {
      const result = await this.docClient.send(
        new GetCommand({
          TableName: this.channelTable,
          Key: { id },
        })
      );
      
      return result.Item as Channel;
    } catch (error) {
      console.error(`Error getting channel ${id}:`, error);
      return undefined;
    }
  }

  async getChannelByUserId(userId: number): Promise<Channel | undefined> {
    try {
      const result = await this.docClient.send(
        new QueryCommand({
          TableName: this.channelTable,
          IndexName: 'userId-index',
          KeyConditionExpression: 'userId = :userId',
          ExpressionAttributeValues: {
            ':userId': userId,
          },
        })
      );
      
      return result.Items && result.Items.length > 0 
        ? result.Items[0] as Channel 
        : undefined;
    } catch (error) {
      console.error(`Error getting channel by userId ${userId}:`, error);
      return undefined;
    }
  }

  async getChannels(): Promise<Channel[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.channelTable,
        })
      );
      
      return (result.Items || []) as Channel[];
    } catch (error) {
      console.error('Error getting all channels:', error);
      return [];
    }
  }

  async createChannel(insertChannel: InsertChannel): Promise<Channel> {
    try {
      const id = await this.getNextId('channel');
      const timestamp = new Date();
      
      // Ensure all fields are properly defined with null for undefined values
      // Convert Date to ISO string for DynamoDB storage
      const channel: Channel = { 
        ...insertChannel, 
        id, 
        subscriberCount: 0, 
        createdAt: timestamp.toISOString(), // Store as ISO string for DynamoDB
        description: insertChannel.description || null, // Explicitly set null for undefined values
        banner: insertChannel.banner || null
      };
      
      await this.docClient.send(
        new PutCommand({
          TableName: this.channelTable,
          Item: channel,
        })
      );
      
      return channel;
    } catch (error) {
      console.error('Error creating channel:', error);
      throw error;
    }
  }

  async updateChannel(id: number, channelData: Partial<Channel>): Promise<Channel | undefined> {
    try {
      const channel = await this.getChannel(id);
      if (!channel) return undefined;
      
      const updateExpression = Object.keys(channelData)
        .map((key) => `#${key} = :${key}`)
        .join(', ');
      
      const expressionAttributeNames = Object.keys(channelData).reduce(
        (acc, key) => ({ ...acc, [`#${key}`]: key }),
        {}
      );
      
      const expressionAttributeValues = Object.entries(channelData).reduce(
        (acc, [key, value]) => ({ ...acc, [`:${key}`]: value }),
        {}
      );
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.channelTable,
          Key: { id },
          UpdateExpression: `SET ${updateExpression}`,
          ExpressionAttributeNames: expressionAttributeNames,
          ExpressionAttributeValues: expressionAttributeValues,
          ReturnValues: 'ALL_NEW',
        })
      );
      
      return result.Attributes as Channel;
    } catch (error) {
      console.error(`Error updating channel ${id}:`, error);
      return undefined;
    }
  }

  // Verify a channel (mark as official)
  async verifyChannel(channelId: number, moderatorId: number): Promise<boolean> {
    try {
      const channel = await this.getChannel(channelId);
      if (!channel) return false;
      
      const timestamp = new Date().toISOString();
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.channelTable,
          Key: { id: channelId },
          UpdateExpression: 'SET isVerified = :isVerified, verifiedAt = :timestamp, verifiedBy = :moderatorId',
          ExpressionAttributeValues: {
            ':isVerified': true,
            ':timestamp': timestamp,
            ':moderatorId': moderatorId
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.CHANNEL,
          contentId: channelId,
          action: ModerationAction.VERIFY,
          previousStatus: 'unverified',
          newStatus: 'verified'
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error verifying channel ${channelId}:`, error);
      return false;
    }
  }

  // Unverify a channel (remove official status)
  async unverifyChannel(channelId: number, moderatorId: number): Promise<boolean> {
    try {
      const channel = await this.getChannel(channelId);
      if (!channel) return false;
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.channelTable,
          Key: { id: channelId },
          UpdateExpression: 'SET isVerified = :isVerified, verifiedAt = :timestamp, verifiedBy = :moderatorId',
          ExpressionAttributeValues: {
            ':isVerified': false,
            ':timestamp': null,
            ':moderatorId': null
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.CHANNEL,
          contentId: channelId,
          action: ModerationAction.UNVERIFY,
          previousStatus: 'verified',
          newStatus: 'unverified'
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error unverifying channel ${channelId}:`, error);
      return false;
    }
  }

  // Disable a channel (for moderation purposes)
  async disableChannel(channelId: number, moderatorId: number, reason: string): Promise<boolean> {
    try {
      const channel = await this.getChannel(channelId);
      if (!channel) return false;
      
      const timestamp = new Date().toISOString();
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.channelTable,
          Key: { id: channelId },
          UpdateExpression: 'SET isDisabled = :isDisabled, disabledReason = :reason, disabledAt = :timestamp, disabledBy = :moderatorId',
          ExpressionAttributeValues: {
            ':isDisabled': true,
            ':reason': reason,
            ':timestamp': timestamp,
            ':moderatorId': moderatorId
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.CHANNEL,
          contentId: channelId,
          action: ModerationAction.DISABLE,
          reason,
          previousStatus: 'active',
          newStatus: 'disabled'
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error disabling channel ${channelId}:`, error);
      return false;
    }
  }

  // Enable a channel (remove disabled status)
  async enableChannel(channelId: number, moderatorId: number): Promise<boolean> {
    try {
      const channel = await this.getChannel(channelId);
      if (!channel) return false;
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.channelTable,
          Key: { id: channelId },
          UpdateExpression: 'SET isDisabled = :isDisabled, disabledReason = :reason, disabledAt = :timestamp, disabledBy = :moderatorId',
          ExpressionAttributeValues: {
            ':isDisabled': false,
            ':reason': null,
            ':timestamp': null,
            ':moderatorId': null
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.CHANNEL,
          contentId: channelId,
          action: ModerationAction.ENABLE,
          previousStatus: 'disabled',
          newStatus: 'active'
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error enabling channel ${channelId}:`, error);
      return false;
    }
  }

  // Video methods
  async getVideo(id: number): Promise<Video | undefined> {
    try {
      const result = await this.docClient.send(
        new GetCommand({
          TableName: this.videoTable,
          Key: { id },
        })
      );
      
      return result.Item as Video;
    } catch (error) {
      console.error(`Error getting video ${id}:`, error);
      return undefined;
    }
  }

  async getVideos(limit = 20): Promise<Video[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.videoTable,
          FilterExpression: 'privacy = :privacy',
          ExpressionAttributeValues: {
            ':privacy': 'public',
          },
        })
      );
      
      const videos = (result.Items || []) as Video[];
      
      // Sort by createdAt
      return videos
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, limit);
    } catch (error) {
      console.error('Error getting videos:', error);
      return [];
    }
  }

  async getVideosByChannel(channelId: number): Promise<Video[]> {
    try {
      const result = await this.docClient.send(
        new QueryCommand({
          TableName: this.videoTable,
          IndexName: 'channelId-index',
          KeyConditionExpression: 'channelId = :channelId',
          ExpressionAttributeValues: {
            ':channelId': channelId,
          },
        })
      );
      
      const videos = (result.Items || []) as Video[];
      
      // Sort by createdAt
      return videos.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (error) {
      console.error(`Error getting videos by channelId ${channelId}:`, error);
      return [];
    }
  }

  async getQuickies(limit = 20): Promise<Video[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.videoTable,
          FilterExpression: 'isQuickie = :isQuickie AND privacy = :privacy',
          ExpressionAttributeValues: {
            ':isQuickie': true,
            ':privacy': 'public',
          },
        })
      );
      
      const videos = (result.Items || []) as Video[];
      
      // Sort by createdAt
      return videos
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, limit);
    } catch (error) {
      console.error('Error getting quickies:', error);
      return [];
    }
  }
  
  async getVideosByCategory(category: string, limit = 20): Promise<Video[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.videoTable,
          FilterExpression: 'category = :category AND privacy = :privacy',
          ExpressionAttributeValues: {
            ':category': category,
            ':privacy': 'public',
          },
        })
      );
      
      const videos = (result.Items || []) as Video[];
      
      // Sort by createdAt
      return videos
        .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
        .slice(0, limit);
    } catch (error) {
      console.error(`Error getting videos for category ${category}:`, error);
      return [];
    }
  }

  async getTrendingVideos(limit = 20): Promise<Video[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.videoTable,
          FilterExpression: 'privacy = :privacy',
          ExpressionAttributeValues: {
            ':privacy': 'public',
          },
        })
      );
      
      const videos = (result.Items || []) as Video[];
      
      // Sort by a combination of views and recency
      return videos
        .sort((a, b) => {
          const aScore = a.views * 2 + new Date(a.createdAt).getTime() / 86400000;
          const bScore = b.views * 2 + new Date(b.createdAt).getTime() / 86400000;
          return bScore - aScore;
        })
        .slice(0, limit);
    } catch (error) {
      console.error('Error getting trending videos:', error);
      return [];
    }
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    try {
      const id = await this.getNextId('video');
      const timestamp = new Date();
      
      // Ensure all fields are properly defined with null for undefined values
      // Convert Date to ISO string for DynamoDB storage
      const video: Video = { 
        ...insertVideo, 
        id, 
        views: 0, 
        likes: 0, 
        dislikes: 0, 
        createdAt: timestamp.toISOString(), // Store as ISO string for DynamoDB
        privacy: insertVideo.privacy || 'public',
        description: insertVideo.description || null,
        thumbnail: insertVideo.thumbnail || null,
        duration: insertVideo.duration || null,
        isQuickie: insertVideo.isQuickie || false,
        isPremium: insertVideo.isPremium || false, // Add isPremium with default false
        category: insertVideo.category || null
      };
      
      await this.docClient.send(
        new PutCommand({
          TableName: this.videoTable,
          Item: video,
        })
      );
      
      return video;
    } catch (error) {
      console.error('Error creating video:', error);
      throw error;
    }
  }

  async updateVideo(id: number, videoData: Partial<Video>): Promise<Video | undefined> {
    try {
      const video = await this.getVideo(id);
      if (!video) return undefined;
      
      const updateExpression = Object.keys(videoData)
        .map((key) => `#${key} = :${key}`)
        .join(', ');
      
      const expressionAttributeNames = Object.keys(videoData).reduce(
        (acc, key) => ({ ...acc, [`#${key}`]: key }),
        {}
      );
      
      const expressionAttributeValues = Object.entries(videoData).reduce(
        (acc, [key, value]) => ({ ...acc, [`:${key}`]: value }),
        {}
      );
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.videoTable,
          Key: { id },
          UpdateExpression: `SET ${updateExpression}`,
          ExpressionAttributeNames: expressionAttributeNames,
          ExpressionAttributeValues: expressionAttributeValues,
          ReturnValues: 'ALL_NEW',
        })
      );
      
      return result.Attributes as Video;
    } catch (error) {
      console.error(`Error updating video ${id}:`, error);
      return undefined;
    }
  }

  async incrementVideoViews(id: number): Promise<void> {
    try {
      await this.docClient.send(
        new UpdateCommand({
          TableName: this.videoTable,
          Key: { id },
          UpdateExpression: 'ADD views :inc',
          ExpressionAttributeValues: {
            ':inc': 1,
          },
        })
      );
    } catch (error) {
      console.error(`Error incrementing views for video ${id}:`, error);
    }
  }
  
  // Moderate a video (approve, reject)
  async moderateVideo(videoId: number, moderatorId: number, status: string, reason?: string): Promise<boolean> {
    try {
      const video = await this.getVideo(videoId);
      if (!video) return false;
      
      const timestamp = new Date().toISOString();
      const previousStatus = video.moderationStatus || ModerationStatus.PENDING;
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.videoTable,
          Key: { id: videoId },
          UpdateExpression: 'SET moderationStatus = :status, moderationReason = :reason, moderatedAt = :timestamp, moderatedBy = :moderatorId',
          ExpressionAttributeValues: {
            ':status': status,
            ':reason': reason || null,
            ':timestamp': timestamp,
            ':moderatorId': moderatorId
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.VIDEO,
          contentId: videoId,
          action: status === ModerationStatus.APPROVED ? ModerationAction.APPROVE : ModerationAction.REJECT,
          reason,
          previousStatus,
          newStatus: status
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error moderating video ${videoId}:`, error);
      return false;
    }
  }
  
  // Get videos pending moderation
  async getVideosForModeration(limit = 20, offset = 0): Promise<Video[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.videoTable,
          FilterExpression: 'moderationStatus = :status OR attribute_not_exists(moderationStatus)',
          ExpressionAttributeValues: {
            ':status': ModerationStatus.PENDING
          }
        })
      );
      
      const videos = (result.Items || []) as Video[];
      
      // Sort by creation date (oldest first)
      return videos
        .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime())
        .slice(offset, offset + limit);
    } catch (error) {
      console.error('Error getting videos for moderation:', error);
      return [];
    }
  }
  
  // Get videos by moderation status
  async getVideosByModerationStatus(status: string, limit = 20): Promise<Video[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.videoTable,
          FilterExpression: 'moderationStatus = :status',
          ExpressionAttributeValues: {
            ':status': status
          }
        })
      );
      
      const videos = (result.Items || []) as Video[];
      
      // Sort by moderated date
      return videos
        .sort((a, b) => {
          const aDate = a.moderatedAt ? new Date(a.moderatedAt).getTime() : 0;
          const bDate = b.moderatedAt ? new Date(b.moderatedAt).getTime() : 0;
          return bDate - aDate;
        })
        .slice(0, limit);
    } catch (error) {
      console.error(`Error getting videos by moderation status ${status}:`, error);
      return [];
    }
  }

  // Comment methods
  async getComment(id: number): Promise<Comment | undefined> {
    try {
      const result = await this.docClient.send(
        new GetCommand({
          TableName: this.commentTable,
          Key: { id },
        })
      );
      
      return result.Item as Comment;
    } catch (error) {
      console.error(`Error getting comment ${id}:`, error);
      return undefined;
    }
  }

  async getCommentsByVideo(videoId: number): Promise<Comment[]> {
    try {
      const result = await this.docClient.send(
        new QueryCommand({
          TableName: this.commentTable,
          IndexName: 'videoId-index',
          KeyConditionExpression: 'videoId = :videoId',
          ExpressionAttributeValues: {
            ':videoId': videoId,
          },
        })
      );
      
      const comments = (result.Items || []) as Comment[];
      
      // Sort by createdAt
      return comments.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (error) {
      console.error(`Error getting comments by videoId ${videoId}:`, error);
      return [];
    }
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    try {
      const id = await this.getNextId('comment');
      const timestamp = new Date();
      const comment: Comment = { 
        ...insertComment, 
        id, 
        createdAt: timestamp.toISOString(), // Store as ISO string for DynamoDB
        isHidden: false
      };
      
      await this.docClient.send(
        new PutCommand({
          TableName: this.commentTable,
          Item: comment,
        })
      );
      
      return comment;
    } catch (error) {
      console.error('Error creating comment:', error);
      throw error;
    }
  }
  
  // Hide a comment (for moderation purposes)
  async hideComment(commentId: number, moderatorId: number, reason: string): Promise<boolean> {
    try {
      const comment = await this.getComment(commentId);
      if (!comment) return false;
      
      const timestamp = new Date().toISOString();
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.commentTable,
          Key: { id: commentId },
          UpdateExpression: 'SET isHidden = :isHidden, hiddenReason = :reason, hiddenAt = :timestamp, hiddenBy = :moderatorId',
          ExpressionAttributeValues: {
            ':isHidden': true,
            ':reason': reason,
            ':timestamp': timestamp,
            ':moderatorId': moderatorId
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.COMMENT,
          contentId: commentId,
          action: ModerationAction.HIDE,
          reason,
          previousStatus: 'visible',
          newStatus: 'hidden'
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error hiding comment ${commentId}:`, error);
      return false;
    }
  }
  
  // Unhide a comment
  async unhideComment(commentId: number, moderatorId: number): Promise<boolean> {
    try {
      const comment = await this.getComment(commentId);
      if (!comment) return false;
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.commentTable,
          Key: { id: commentId },
          UpdateExpression: 'SET isHidden = :isHidden, hiddenReason = :reason, hiddenAt = :timestamp, hiddenBy = :moderatorId',
          ExpressionAttributeValues: {
            ':isHidden': false,
            ':reason': null,
            ':timestamp': null,
            ':moderatorId': null
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: ContentType.COMMENT,
          contentId: commentId,
          action: ModerationAction.UNHIDE,
          previousStatus: 'hidden',
          newStatus: 'visible'
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error unhiding comment ${commentId}:`, error);
      return false;
    }
  }
  
  // Get flagged comments
  async getFlaggedComments(limit = 20): Promise<Comment[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.commentTable,
          FilterExpression: 'isFlagged = :isFlagged',
          ExpressionAttributeValues: {
            ':isFlagged': true
          }
        })
      );
      
      const comments = (result.Items || []) as Comment[];
      
      // Sort by flag count (highest first)
      return comments
        .sort((a, b) => (b.flagCount || 0) - (a.flagCount || 0))
        .slice(0, limit);
    } catch (error) {
      console.error('Error getting flagged comments:', error);
      return [];
    }
  }

  // Like methods
  async getLike(userId: number, videoId: number): Promise<Like | undefined> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.likeTable,
          FilterExpression: 'userId = :userId AND videoId = :videoId',
          ExpressionAttributeValues: {
            ':userId': userId,
            ':videoId': videoId,
          },
        })
      );
      
      return result.Items && result.Items.length > 0 
        ? result.Items[0] as Like 
        : undefined;
    } catch (error) {
      console.error(`Error getting like for userId ${userId} and videoId ${videoId}:`, error);
      return undefined;
    }
  }

  async createLike(insertLike: InsertLike): Promise<Like> {
    try {
      // First check if a like already exists
      const existingLike = await this.getLike(insertLike.userId, insertLike.videoId);
      
      if (existingLike) {
        // Update existing like
        if (existingLike.isLike !== insertLike.isLike) {
          const video = await this.getVideo(insertLike.videoId);
          
          if (video) {
            // Update video like/dislike counts
            const updatedCounts = {
              likes: insertLike.isLike 
                ? video.likes + 1 
                : Math.max(0, video.likes - 1),
              dislikes: !insertLike.isLike 
                ? video.dislikes + 1 
                : Math.max(0, video.dislikes - 1),
            };
            
            await this.updateVideo(video.id, updatedCounts);
          }
          
          // Update the like
          const result = await this.docClient.send(
            new UpdateCommand({
              TableName: this.likeTable,
              Key: { id: existingLike.id },
              UpdateExpression: 'SET isLike = :isLike',
              ExpressionAttributeValues: {
                ':isLike': insertLike.isLike,
              },
              ReturnValues: 'ALL_NEW',
            })
          );
          
          return result.Attributes as Like;
        }
        
        return existingLike;
      }
      
      // Create new like
      const id = await this.getNextId('like');
      const timestamp = new Date();
      const like: Like = { 
        ...insertLike, 
        id, 
        createdAt: timestamp.toISOString() // Store as ISO string for DynamoDB
      };
      
      await this.docClient.send(
        new PutCommand({
          TableName: this.likeTable,
          Item: like,
        })
      );
      
      // Update video like/dislike counts
      const video = await this.getVideo(insertLike.videoId);
      if (video) {
        const updatedCounts = {
          likes: insertLike.isLike ? video.likes + 1 : video.likes,
          dislikes: !insertLike.isLike ? video.dislikes + 1 : video.dislikes,
        };
        
        await this.updateVideo(video.id, updatedCounts);
      }
      
      return like;
    } catch (error) {
      console.error('Error creating like:', error);
      throw error;
    }
  }

  async deleteLike(userId: number, videoId: number): Promise<void> {
    try {
      const like = await this.getLike(userId, videoId);
      if (!like) return;
      
      await this.docClient.send(
        new DeleteCommand({
          TableName: this.likeTable,
          Key: { id: like.id },
        })
      );
      
      // Update video like/dislike counts
      const video = await this.getVideo(videoId);
      if (video) {
        const updatedCounts = {
          likes: like.isLike ? Math.max(0, video.likes - 1) : video.likes,
          dislikes: !like.isLike ? Math.max(0, video.dislikes - 1) : video.dislikes,
        };
        
        await this.updateVideo(video.id, updatedCounts);
      }
    } catch (error) {
      console.error(`Error deleting like for userId ${userId} and videoId ${videoId}:`, error);
    }
  }

  // Subscription methods
  async getSubscription(userId: number, channelId: number): Promise<Subscription | undefined> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.subscriptionTable,
          FilterExpression: 'userId = :userId AND channelId = :channelId',
          ExpressionAttributeValues: {
            ':userId': userId,
            ':channelId': channelId,
          },
        })
      );
      
      return result.Items && result.Items.length > 0 
        ? result.Items[0] as Subscription 
        : undefined;
    } catch (error) {
      console.error(`Error getting subscription for userId ${userId} and channelId ${channelId}:`, error);
      return undefined;
    }
  }

  async getSubscriptionsByUser(userId: number): Promise<Subscription[]> {
    try {
      const result = await this.docClient.send(
        new QueryCommand({
          TableName: this.subscriptionTable,
          IndexName: 'userId-index',
          KeyConditionExpression: 'userId = :userId',
          ExpressionAttributeValues: {
            ':userId': userId,
          },
        })
      );
      
      return (result.Items || []) as Subscription[];
    } catch (error) {
      console.error(`Error getting subscriptions for userId ${userId}:`, error);
      return [];
    }
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    try {
      // Check if subscription already exists
      const existingSubscription = await this.getSubscription(
        insertSubscription.userId, 
        insertSubscription.channelId
      );
      
      if (existingSubscription) {
        return existingSubscription;
      }
      
      const id = await this.getNextId('subscription');
      const timestamp = new Date();
      const subscription: Subscription = { 
        ...insertSubscription, 
        id, 
        createdAt: timestamp.toISOString() // Store as ISO string for DynamoDB
      };
      
      await this.docClient.send(
        new PutCommand({
          TableName: this.subscriptionTable,
          Item: subscription,
        })
      );
      
      // Update channel subscriber count
      const channel = await this.getChannel(insertSubscription.channelId);
      if (channel) {
        await this.updateChannel(channel.id, {
          subscriberCount: channel.subscriberCount + 1,
        });
      }
      
      return subscription;
    } catch (error) {
      console.error('Error creating subscription:', error);
      throw error;
    }
  }

  async deleteSubscription(userId: number, channelId: number): Promise<void> {
    try {
      const subscription = await this.getSubscription(userId, channelId);
      if (!subscription) return;
      
      await this.docClient.send(
        new DeleteCommand({
          TableName: this.subscriptionTable,
          Key: { id: subscription.id },
        })
      );
      
      // Update channel subscriber count
      const channel = await this.getChannel(channelId);
      if (channel) {
        await this.updateChannel(channel.id, {
          subscriberCount: Math.max(0, channel.subscriberCount - 1),
        });
      }
    } catch (error) {
      console.error(`Error deleting subscription for userId ${userId} and channelId ${channelId}:`, error);
    }
  }

  // Report methods
  async createReport(report: InsertReport): Promise<Report> {
    try {
      const id = await this.getNextId('report');
      const timestamp = new Date();
      
      // Create report object
      const reportObj: Report = { 
        ...report, 
        id, 
        status: ReportStatus.PENDING,
        createdAt: timestamp.toISOString()
      };
      
      await this.docClient.send(
        new PutCommand({
          TableName: this.reportTable,
          Item: reportObj,
        })
      );
      
      return reportObj;
    } catch (error) {
      console.error('Error creating report:', error);
      throw error;
    }
  }
  
  async getReport(id: number): Promise<Report | undefined> {
    try {
      const result = await this.docClient.send(
        new GetCommand({
          TableName: this.reportTable,
          Key: { id },
        })
      );
      
      return result.Item as Report;
    } catch (error) {
      console.error(`Error getting report ${id}:`, error);
      return undefined;
    }
  }
  
  async getReports(status?: string, limit = 20, offset = 0): Promise<Report[]> {
    try {
      let filterExpression = '';
      let expressionAttributeValues: Record<string, any> = {};
      
      if (status) {
        filterExpression = 'status = :status';
        expressionAttributeValues = { ':status': status };
      }
      
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.reportTable,
          ...(filterExpression && {
            FilterExpression: filterExpression,
            ExpressionAttributeValues: expressionAttributeValues,
          }),
        })
      );
      
      const reports = (result.Items || []) as Report[];
      
      // Sort by creation date (newest first)
      return reports
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(offset, offset + limit);
    } catch (error) {
      console.error('Error getting reports:', error);
      return [];
    }
  }
  
  async getReportsByContentType(contentType: string, status?: string): Promise<Report[]> {
    try {
      let filterExpression = 'contentType = :contentType';
      let expressionAttributeValues: Record<string, any> = { ':contentType': contentType };
      
      if (status) {
        filterExpression += ' AND status = :status';
        expressionAttributeValues[':status'] = status;
      }
      
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.reportTable,
          FilterExpression: filterExpression,
          ExpressionAttributeValues: expressionAttributeValues,
        })
      );
      
      const reports = (result.Items || []) as Report[];
      
      // Sort by creation date (newest first)
      return reports.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (error) {
      console.error(`Error getting reports by content type ${contentType}:`, error);
      return [];
    }
  }

  async getReportsByStatus(status: string): Promise<Report[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.reportTable,
          FilterExpression: '#status = :status',
          ExpressionAttributeNames: {
            '#status': 'status'
          },
          ExpressionAttributeValues: {
            ':status': status
          }
        })
      );
      
      const reports = (result.Items || []) as Report[];
      
      // Sort by creation date (newest first)
      return reports.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (error) {
      console.error(`Error getting reports by status ${status}:`, error);
      return [];
    }
  }
  
  async updateReportStatus(reportId: number, moderatorId: number, status: string, actionTaken?: string): Promise<boolean> {
    try {
      const report = await this.getReport(reportId);
      if (!report) return false;
      
      const timestamp = new Date().toISOString();
      
      const result = await this.docClient.send(
        new UpdateCommand({
          TableName: this.reportTable,
          Key: { id: reportId },
          UpdateExpression: 'SET status = :status, resolvedAt = :timestamp, resolvedBy = :moderatorId, actionTaken = :actionTaken',
          ExpressionAttributeValues: {
            ':status': status,
            ':timestamp': timestamp,
            ':moderatorId': moderatorId,
            ':actionTaken': actionTaken || null
          },
          ReturnValues: 'ALL_NEW'
        })
      );
      
      if (result.Attributes) {
        // Create moderation log
        await this.createModerationLog({
          moderatorId,
          contentType: report.contentType,
          contentId: report.contentId,
          action: ModerationAction.RESOLVE_REPORT,
          reason: report.reason,
          previousStatus: report.status,
          newStatus: status
        });
        
        return true;
      }
      
      return false;
    } catch (error) {
      console.error(`Error updating report status ${reportId}:`, error);
      return false;
    }
  }
  
  // Moderation log methods
  async createModerationLog(log: InsertModerationLog): Promise<ModerationLog> {
    try {
      const id = await this.getNextId('moderationLog');
      const timestamp = new Date();
      
      // Create log object
      const moderationLog: ModerationLog = { 
        ...log, 
        id, 
        createdAt: timestamp.toISOString()
      };
      
      await this.docClient.send(
        new PutCommand({
          TableName: this.moderationLogTable,
          Item: moderationLog,
        })
      );
      
      return moderationLog;
    } catch (error) {
      console.error('Error creating moderation log:', error);
      throw error;
    }
  }
  
  async getModerationLogs(limit = 20, offset = 0): Promise<ModerationLog[]> {
    try {
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.moderationLogTable,
        })
      );
      
      const logs = (result.Items || []) as ModerationLog[];
      
      // Sort by creation date (newest first)
      return logs
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(offset, offset + limit);
    } catch (error) {
      console.error('Error getting moderation logs:', error);
      return [];
    }
  }
  
  async getModerationLogsByModerator(moderatorId: number): Promise<ModerationLog[]> {
    try {
      const result = await this.docClient.send(
        new QueryCommand({
          TableName: this.moderationLogTable,
          IndexName: 'moderatorId-index',
          KeyConditionExpression: 'moderatorId = :moderatorId',
          ExpressionAttributeValues: {
            ':moderatorId': moderatorId,
          },
        })
      );
      
      const logs = (result.Items || []) as ModerationLog[];
      
      // Sort by creation date (newest first)
      return logs.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (error) {
      console.error(`Error getting moderation logs by moderator ${moderatorId}:`, error);
      return [];
    }
  }
  
  async getModerationLogsByContentType(contentType: string, contentId?: number): Promise<ModerationLog[]> {
    try {
      let filterExpression = 'contentType = :contentType';
      let expressionAttributeValues: Record<string, any> = { ':contentType': contentType };
      
      if (contentId !== undefined) {
        filterExpression += ' AND contentId = :contentId';
        expressionAttributeValues[':contentId'] = contentId;
      }
      
      const result = await this.docClient.send(
        new ScanCommand({
          TableName: this.moderationLogTable,
          FilterExpression: filterExpression,
          ExpressionAttributeValues: expressionAttributeValues,
        })
      );
      
      const logs = (result.Items || []) as ModerationLog[];
      
      // Sort by creation date (newest first)
      return logs.sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
    } catch (error) {
      console.error(`Error getting moderation logs by content type ${contentType}:`, error);
      return [];
    }
  }
}

// Create and export DynamoDB storage instance
export const storage = new DynamoStorage();